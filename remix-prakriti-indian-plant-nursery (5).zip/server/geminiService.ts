import { GoogleGenAI } from '@google/genai';

/**
 * Lazy-initialized GoogleGenAI client to avoid crash when key is missing at module load
 */
let aiClient: GoogleGenAI | null = null;

export function getGenAI(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key && key.trim()) {
      try {
        aiClient = new GoogleGenAI({ apiKey: key.trim() });
      } catch (err) {
        console.warn('[GeminiService] Failed to initialize GoogleGenAI client:', err);
      }
    }
  }
  return aiClient;
}

export interface PlantDoctorConsultRequest {
  query?: string;
  plantName?: string;
  category?: string;
  problem?: string;
  symptoms?: string;
  language?: 'en' | 'hi' | 'mr' | string;
}

export interface PlantDiagnosisRequest {
  plantName: string;
  symptoms: string;
  leafCondition?: string;
  wateringHabit?: string;
  sunlightExposure?: string;
  language?: 'en' | 'hi' | 'mr' | string;
}

export interface PlantDiagnosisResponse {
  plantName: string;
  diagnosis: string;
  severity: 'low' | 'medium' | 'high';
  possibleCauses: string[];
  remedies: string[];
  preventativeMeasures: string[];
  recommendedOrganicProducts: string[];
  wateringAdvice: string;
  sunlightAdvice: string;
  rawAdvice: string;
}

/**
 * Fallback botanical database for Indian plants in case Gemini key is pending
 */
const INDIAN_PLANT_CARE_KB: Record<string, {
  watering: string;
  sunlight: string;
  fertilizer: string;
  remedy: string;
}> = {
  tulsi: {
    watering: 'Water only when the top 1-2 inches of soil feel dry. Tulsi dislikes soggy roots. Water in the morning hours.',
    sunlight: 'Needs 4 to 6 hours of direct morning sunlight. East or North-East balcony orientation is ideal.',
    fertilizer: 'Add 2 handfuls of well-rotted vermicompost once a month. Sprinkle 1/2 tsp turmeric (haldi) around the soil to repel ants and fungal spores.',
    remedy: 'Pinch off seed spikes (manjari) regularly to encourage lush green branching. For black bugs/aphids, spray mild neem oil solution (5ml/L water).',
  },
  money_plant: {
    watering: 'Allow topsoil to dry slightly between waterings. In monsoons, water once every 5-7 days; in peak summer, water every 2-3 days.',
    sunlight: 'Thrives in bright indirect sunlight. Avoid scorching direct mid-day sun which bleaches leaves yellow.',
    fertilizer: 'Feed with diluted seaweed liquid extract or compost tea once every 4 weeks during spring and monsoon.',
    remedy: 'Yellow leaves usually indicate overwatering or poor pot drainage. Wipe leaves with a damp cotton cloth to remove urban dust.',
  },
  sansevieria: {
    watering: 'Extremely drought tolerant. Water only once every 2-3 weeks. Overwatering is the #1 killer of Snake Plants in Indian homes.',
    sunlight: 'Adapts to low indoor light as well as bright filtered light. Avoid prolonged damp darkness.',
    fertilizer: 'Very light feeder. Organic vermicompost twice a year (February and August) is sufficient.',
    remedy: 'If leaves become soft or mushy at the base, stop watering immediately and repot in fast-draining porous cactus/succulent soil.',
  },
  hibiscus: {
    watering: 'Requires regular moisture while flowering. Keep soil evenly moist but never stagnant.',
    sunlight: 'Needs full sun (at least 5-6 hours) to bloom profusely.',
    fertilizer: 'Heavy feeder. Feed with banana peel fertilizer, mustard cake tea (sarson ki khali), or organic bone meal every 3 weeks.',
    remedy: 'Vulnerable to white cottony mealybugs. Spray organic cold-pressed neem oil (5ml/L) with 2 drops of baby shampoo every 4 days until cleared.',
  },
  mogra: {
    watering: 'Moderate watering. Water generously before blooming season; avoid over-saturation during heavy rains.',
    sunlight: 'Requires 5+ hours of direct sunlight for intense fragrance and bud formation.',
    fertilizer: 'Prune branches lightly in February/March and feed with cow dung manure (gobar ki khaad) and Epsom salt (1/2 tsp in 1L water).',
    remedy: 'If buds fall before blooming, increase morning sunlight exposure and check for spider mites under leaves.',
  },
  peace_lily: {
    watering: 'Peace Lilies droop noticeably when thirsty. Water thoroughly when the leaves begin to bow, letting excess drain completely.',
    sunlight: 'Medium to bright indirect light. Direct sun causes immediate brown leaf burn.',
    fertilizer: 'Mild organic houseplant fertilizer once a month. Sensitive to excessive chemical salts.',
    remedy: 'Brown tips usually signify dry air or chlorine in tap water. Mist the foliage twice a week or use rested/filtered water.',
  },
  areca_palm: {
    watering: 'Water when top 1 inch of soil is dry. Needs good drainage holes.',
    sunlight: 'Bright filtered sunlight. Keep near east-facing window.',
    fertilizer: 'Slow-release organic pellets or vermicompost once a month in growing season.',
    remedy: 'Brown leaf tips indicate low humidity or dry AC air. Mist weekly.',
  },
  rose: {
    watering: 'Deep watering 2-3 times a week depending on weather. Never wet foliage in evenings.',
    sunlight: 'Requires at least 6 hours of full direct sun for vibrant blooms.',
    fertilizer: 'Rose food, composted cow manure, and steamed bone meal every 20 days.',
    remedy: 'Prune dead stems (die-back) at a 45-degree angle. Dust cut stems with cinnamon powder or turmeric.',
  },
};

/**
 * Get plant-specific fallback advice
 */
function getFallbackConsultation(req: PlantDoctorConsultRequest): string {
  const lang = req.language || 'en';
  const queryLower = (req.query || req.problem || req.plantName || '').toLowerCase();

  let matchedKey = Object.keys(INDIAN_PLANT_CARE_KB).find(k => queryLower.includes(k.replace('_', ' ')) || queryLower.includes(k));
  if (!matchedKey) {
    matchedKey = 'money_plant';
  }

  const kb = INDIAN_PLANT_CARE_KB[matchedKey];
  const plantTitle = matchedKey.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');

  if (lang === 'hi') {
    return `🌿 **प्रकृति नर्सरी प्लांट डॉक्टर परामर्श (${plantTitle})**:

1. **पानी देने का नियम**: ${kb.watering}
2. **धूप एवं वातावरण**: ${kb.sunlight}
3. **जैविक खाद एवं पोषण**: ${kb.fertilizer}
4. **घरेलू एवं जैविक समाधान**: ${kb.remedy}

*सुझाव: भारतीय जलवायु में गमले की मिट्टी में 20% कोकोपीट और 20% वर्मीकम्पोस्ट मिलाने से जड़ें हमेशा स्वस्थ रहती हैं।*`;
  }

  if (lang === 'mr') {
    return `🌿 **प्रकृती रोपवाटिका वनस्पती तज्ज्ञ सल्ला (${plantTitle})**:

1. **पाण्याचे नियोजन**: ${kb.watering}
2. **सूर्यप्रकाश आणि जागा**: ${kb.sunlight}
3. **सेंद्रिय खत व पोषण**: ${kb.fertilizer}
4. **रोग निवारण व सेंद्रिय उपाय**: ${kb.remedy}

*टीप: कुंडीच्या तळाशी पाण्याचा निचरा योग्य असल्याची नेहमी खात्री करा.*`;
  }

  return `🌿 **Prakriti Nursery Botanical Advisory (${plantTitle})**:

• **Watering Regimen**: ${kb.watering}
• **Sunlight & Climate**: ${kb.sunlight}
• **Organic Fertilization**: ${kb.fertilizer}
• **Doctor's Organic Remedy**: ${kb.remedy}

💡 *Pro Nursery Tip: Always ensure nursery pots have unobstructed drainage holes to prevent root rot during Indian monsoons.*`;
}

/**
 * Ask the AI Plant Doctor using Gemini 2.5 Flash
 */
export async function askPlantDoctor(req: PlantDoctorConsultRequest): Promise<string> {
  const genAI = getGenAI();

  if (!genAI) {
    console.info('[GeminiService] GEMINI_API_KEY not set, using botanical expert knowledge engine.');
    return getFallbackConsultation(req);
  }

  try {
    const langInstructions: Record<string, string> = {
      hi: 'उत्तर शुद्ध और सरल हिंदी में दें। पौधों की देसी देखभाल, जैसे नीम का तेल, वर्मीकम्पोस्ट, हल्दी के उपयोग का सुझाव दें।',
      mr: 'उत्तर सोप्या आणि सुस्पष्ट मराठीत द्या. भारतीय हवामानानुसार रोपांची सेंद्रिय काळजी सांगा.',
      en: 'Answer in concise, encouraging English with clear bullet points. Mention organic Indian nursery remedies like cold-pressed neem oil, vermicompost, cow dung manure, and watering practices tailored for Indian climates.',
    };

    const selectedLangInstruction = langInstructions[req.language || 'en'] || langInstructions.en;

    const prompt = `You are the Master Horticulturist & Plant Doctor at "Prakriti Indian Plant Nursery" (प्रकृति नर्सरी), India's premier botanical nursery.
You specialize in Indian tropical, subtropical, and arid houseplants, balcony greens, sacred plants (Tulsi, Bel Patra, Parijat), flowering varieties (Mogra, Hibiscus, Desi Rose), and organic garden care.

User Query: "${req.query || req.problem || 'General plant care advice'}"
Target Plant: "${req.plantName || 'Indian houseplant/garden plant'}"
Category: "${req.category || 'General'}"
Problem Symptoms: "${req.problem || req.symptoms || 'None specified'}"

Instructions:
1. ${selectedLangInstruction}
2. Provide a practical diagnosis with 3-4 structured bullet points:
   - Root Cause / Diagnostic assessment
   - Immediate Corrective Action
   - Watering & Sunlight Adjustment for Indian weather
   - Recommended Organic Care (e.g. Neem oil spray, vermicompost top dressing, turmeric soil treatment)
3. Keep the tone warm, welcoming, and knowledgeable like an authentic Indian nursery horticulturist.
4. Avoid ungrounded chemical pesticides; emphasize safe organic Indian nursery practices.`;

    const response = await genAI.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    const answer = response.text;
    if (answer && answer.trim().length > 0) {
      return answer.trim();
    }

    return getFallbackConsultation(req);
  } catch (error) {
    console.error('[GeminiService] Gemini API call error:', error);
    return getFallbackConsultation(req);
  }
}

/**
 * Diagnose specific plant symptoms with structured output
 */
export async function diagnosePlantHealth(req: PlantDiagnosisRequest): Promise<PlantDiagnosisResponse> {
  const genAI = getGenAI();

  const fallbackText = getFallbackConsultation({
    plantName: req.plantName,
    problem: req.symptoms,
    language: req.language,
  });

  const defaultResponse: PlantDiagnosisResponse = {
    plantName: req.plantName || 'Plant',
    diagnosis: req.symptoms ? `Identified issue related to: ${req.symptoms}` : 'General plant health consultation',
    severity: (req.symptoms.toLowerCase().includes('rot') || req.symptoms.toLowerCase().includes('dying')) ? 'high' : 'medium',
    possibleCauses: [
      'Moisture imbalance (under- or over-watering)',
      'Sub-optimal light conditions for Indian tropical foliage',
      'Nutrient depletion in container potting soil',
    ],
    remedies: [
      'Loosen top 2 inches of soil to aerate root zone',
      'Apply organic cold-pressed neem oil spray (5ml/liter water)',
      'Top-dress with two handfuls of aged vermicompost',
    ],
    preventativeMeasures: [
      'Inspect drainage holes monthly to avoid root waterlogging',
      'Rotate pot weekly for even sunlight absorption',
      'Clean dust off leaves with gentle water mist',
    ],
    recommendedOrganicProducts: ['Organic Neem Oil 100ml', 'Enriched Vermicompost 2kg', 'Cocopeat Brick'],
    wateringAdvice: 'Water only when the top 1-2 inches of potting mix feel dry to touch.',
    sunlightAdvice: 'Provide bright, indirect sunlight away from harsh mid-day heat.',
    rawAdvice: fallbackText,
  };

  if (!genAI) {
    return defaultResponse;
  }

  try {
    const prompt = `You are a certified botanical diagnostic specialist at Prakriti Indian Plant Nursery.
Analyze the following plant symptoms:
- Plant Name: ${req.plantName}
- Observed Symptoms: ${req.symptoms}
- Leaf Condition: ${req.leafCondition || 'Not specified'}
- Current Watering: ${req.wateringHabit || 'Not specified'}
- Sunlight: ${req.sunlightExposure || 'Not specified'}
- Preferred Output Language: ${req.language || 'en'}

Respond ONLY with a valid JSON object matching this schema (do not wrap in markdown or backticks, just raw JSON):
{
  "diagnosis": "concise 1-2 sentence diagnostic conclusion",
  "severity": "low" or "medium" or "high",
  "possibleCauses": ["cause 1", "cause 2", "cause 3"],
  "remedies": ["step 1", "step 2", "step 3"],
  "preventativeMeasures": ["preventative tip 1", "preventative tip 2"],
  "recommendedOrganicProducts": ["product 1", "product 2"],
  "wateringAdvice": "specific watering guidance",
  "sunlightAdvice": "specific sunlight guidance",
  "rawAdvice": "a comprehensive friendly summary from the plant doctor"
}`;

    const response = await genAI.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    const text = response.text || '';
    // Clean potential markdown fencing
    const cleanedText = text.replace(/```json/gi, '').replace(/```/g, '').trim();
    const parsed = JSON.parse(cleanedText);

    return {
      plantName: req.plantName,
      diagnosis: parsed.diagnosis || defaultResponse.diagnosis,
      severity: ['low', 'medium', 'high'].includes(parsed.severity) ? parsed.severity : defaultResponse.severity,
      possibleCauses: Array.isArray(parsed.possibleCauses) ? parsed.possibleCauses : defaultResponse.possibleCauses,
      remedies: Array.isArray(parsed.remedies) ? parsed.remedies : defaultResponse.remedies,
      preventativeMeasures: Array.isArray(parsed.preventativeMeasures) ? parsed.preventativeMeasures : defaultResponse.preventativeMeasures,
      recommendedOrganicProducts: Array.isArray(parsed.recommendedOrganicProducts) ? parsed.recommendedOrganicProducts : defaultResponse.recommendedOrganicProducts,
      wateringAdvice: parsed.wateringAdvice || defaultResponse.wateringAdvice,
      sunlightAdvice: parsed.sunlightAdvice || defaultResponse.sunlightAdvice,
      rawAdvice: parsed.rawAdvice || defaultResponse.rawAdvice,
    };
  } catch (err) {
    console.warn('[GeminiService] Failed to parse structured diagnosis, using fallback:', err);
    return defaultResponse;
  }
}
