# Security Specification: Remix Prakriti Indian Plant Nursery

## 1. Authentication & Role-Based Access Control (RBAC)
- **Roles:**
  - `admin`: Full administrative access to inventory, orders, discount coupons, store settings, and review moderation. Admin emails: `sweetypatilb@gmail.com`, `geetabhutavale311@gmail.com`, `admin@prakritinursery.in`.
  - `customer`: Authenticated users who can manage their own profile, cart, wishlist, and view their placed orders.
  - `guest`: Can browse products, reviews, active coupons, and place orders via guest checkout.
- **Master Gate:** Default-deny applied across all Firestore and Storage collections unless explicitly permitted.

## 2. Firestore Security Architecture
- **`/admins/{adminId}`**:
  - Read/Write: Strictly `isAdmin()`.
- **`/users/{userId}`**:
  - Read: Owner (`isOwner(userId)`) or `isAdmin()`.
  - Create: Owner when registering; cannot assign `admin` role unless already an authorized admin.
  - Update: Owner cannot elevate their own role (`diff.affectedKeys().hasAny(['role', 'uid', 'email'])` guarded) or `isAdmin()`.
  - Delete: Strictly `isAdmin()`.
- **`/products/{productId}`**:
  - Read: Public (`allow read: if true`).
  - Write: Strictly `isAdmin()`.
- **`/carts/{userId}`**:
  - Read/Write: Strictly owner or `isAdmin()`.
- **`/wishlists/{userId}`**:
  - Read/Write: Strictly owner or `isAdmin()`.
- **`/orders/{orderId}`**:
  - Read: Owner (`resource.data.userId == request.auth.uid || resource.data.customerEmail == request.auth.token.email`) or `isAdmin()`.
  - Create: Authenticated owner, verified email match, guest, or `isAdmin()`.
  - Update/Delete: Strictly `isAdmin()`.
- **`/coupons/{couponId}`**:
  - Read: Public.
  - Write: Strictly `isAdmin()`.
- **`/settings/{settingId}`**:
  - Read: Public.
  - Write: Strictly `isAdmin()`.
- **`/reviews/{reviewId}`**:
  - Read: Public.
  - Create: Authenticated users.
  - Update/Delete: Strictly `isAdmin()`.

## 3. Firebase Storage Architecture
- **`/products/{fileName}`**:
  - Read: Public (`allow read: if true`).
  - Write: Authenticated admin only (`isAdmin()`), file size <= 10MB, image MIME type only (`image/*`).
- **`/users/{userId}/{fileName}`**:
  - Read: Public avatar image.
  - Write: Authenticated owner or admin, file size <= 5MB, image MIME type only.
- **Global deny**: All other paths blocked.

## 4. Payment & Secret Key Protection
- **Razorpay Secrets**: `RAZORPAY_KEY_SECRET` and `RAZORPAY_WEBHOOK_SECRET` are kept strictly server-side in `server.ts`.
- **Signature Verification**: HMAC-SHA256 signature verification executes on the Express backend (`/api/verify-payment`) before marking orders paid or decreasing inventory.
- **Webhook Handlers**: Webhook events verified against `X-Razorpay-Signature` with constant-time cryptographic comparison (`crypto.timingSafeEqual`).
- **Gemini API**: `@google/genai` calls handled strictly server-side in `server/geminiService.ts` via `process.env.GEMINI_API_KEY`.
