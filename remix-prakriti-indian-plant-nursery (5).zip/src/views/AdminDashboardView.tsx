import React, { useState, useRef } from 'react';
import {
  LayoutDashboard,
  Package,
  ShoppingBag,
  Tag,
  Settings,
  Plus,
  Edit,
  Trash2,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  FileText,
  DollarSign,
  Users,
  Search,
  X,
  Eye,
  ArrowUpRight,
  Truck,
  Upload,
  ShieldCheck,
  Loader2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Product, Order, Coupon } from '../types';
import { InvoiceModal } from '../components/InvoiceModal';
import { SafeImage } from '../components/SafeImage';

export const AdminDashboardView: React.FC = () => {
  const {
    products,
    categories,
    orders,
    allOrders,
    allUsers,
    coupons,
    settings,
    addProduct,
    updateProduct,
    deleteProduct,
    uploadImage,
    updateOrderStatus,
    addCoupon,
    updateSettings,
    navigateTo,
    currentUser,
    openAuthModal,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders' | 'users' | 'coupons' | 'settings'>('overview');
  const [selectedInvoiceOrder, setSelectedInvoiceOrder] = useState<Order | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  // Search in products and orders
  const [productSearch, setProductSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState('all');

  // Product Add / Edit Modal State
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [pName, setPName] = useState('');
  const [pNameHi, setPNameHi] = useState('');
  const [pNameMr, setPNameMr] = useState('');
  const [pCategory, setPCategory] = useState('Indoor Plants');
  const [pPrice, setPPrice] = useState(299);
  const [pMrp, setPMrp] = useState(499);
  const [pStock, setPStock] = useState(25);
  const [pImage, setPImage] = useState('');
  const [pDesc, setPDesc] = useState('');

  // Coupon Add Modal State
  const [couponModalOpen, setCouponModalOpen] = useState(false);
  const [cCode, setCCode] = useState('');
  const [cType, setCType] = useState<'percentage' | 'flat'>('percentage');
  const [cValue, setCValue] = useState(15);
  const [cMin, setCMin] = useState(499);
  const [cDesc, setCDesc] = useState('');

  // Settings form state
  const [storeName, setStoreName] = useState(settings.name);
  const [storePhone, setStorePhone] = useState(settings.phone);
  const [storeWhatsapp, setStoreWhatsapp] = useState(settings.whatsappNumber);
  const [storeGstin, setStoreGstin] = useState(settings.gstin);
  const [storeFreeThreshold, setStoreFreeThreshold] = useState(settings.freeDeliveryThreshold);
  const [storeFestivalTitle, setStoreFestivalTitle] = useState(settings.festivalBannerTitle);
  const [storeFestivalSubtext, setStoreFestivalSubtext] = useState(settings.festivalBannerSubtext);
  const [storeFestivalDiscount, setStoreFestivalDiscount] = useState(settings.festivalBannerDiscount);
  const [settingsSaved, setSettingsSaved] = useState(false);

  // Statistics
  const totalRevenue = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const totalPlantsSold = orders.reduce(
    (sum, o) => sum + o.items.reduce((iSum, item) => iSum + item.quantity, 0),
    0
  );
  const lowStockCount = products.filter((p) => p.stock <= 15).length;

  const handleOpenAddProduct = () => {
    setEditingProduct(null);
    setPName('');
    setPNameHi('');
    setPNameMr('');
    setPCategory('Indoor Plants');
    setPPrice(299);
    setPMrp(499);
    setPStock(25);
    setPImage('https://images.unsplash.com/photo-1545241047-6083a3684587?auto=format&fit=crop&w=600&q=80');
    setPDesc('');
    setProductModalOpen(true);
  };

  const handleOpenEditProduct = (p: Product) => {
    setEditingProduct(p);
    setPName(p.name);
    setPNameHi(p.nameHi || '');
    setPNameMr(p.nameMr || '');
    setPCategory(p.category);
    setPPrice(p.price);
    setPMrp(p.mrp);
    setPStock(p.stock);
    setPImage(p.images[0] || '');
    setPDesc(p.description);
    setProductModalOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pName.trim()) return;

    if (editingProduct) {
      updateProduct({
        ...editingProduct,
        name: pName.trim(),
        nameHi: pNameHi.trim(),
        nameMr: pNameMr.trim(),
        category: pCategory,
        price: Number(pPrice),
        mrp: Number(pMrp),
        stock: Number(pStock),
        images: [pImage.trim()],
        description: pDesc.trim(),
      });
    } else {
      const slug = pName.toLowerCase().replace(/[^a-z0-9]+/g, '-');
      addProduct({
        id: 'prod_' + Date.now(),
        name: pName.trim(),
        nameHi: pNameHi.trim(),
        nameMr: pNameMr.trim(),
        slug,
        category: pCategory,
        price: Number(pPrice),
        mrp: Number(pMrp),
        stock: Number(pStock),
        rating: 4.8,
        reviewCount: 1,
        images: [pImage.trim()],
        description: pDesc.trim(),
        specs: {
          height: '10 - 15 Inches',
          potSize: '5 Inch Nursery Pot',
          light: 'Bright Indirect',
          water: 'Moderate',
          soil: 'Rich Cocopeat & Perlite',
          temperature: '18°C - 35°C',
          benefits: ['Air purifying', 'Vastu positive', 'Low maintenance'],
          petFriendly: true,
          beginnerFriendly: true,
          location: 'Indoor & Living Room',
        },
        careGuide: {
          watering: 'Water twice a week or when topsoil feels dry.',
          sunlight: 'Bright indirect natural light.',
          fertilizer: 'Organic vermicompost once a month.',
          repotting: 'Repot after 12 months.',
          pruning: 'Prune dry leaves periodically.',
          commonProblems: 'Yellow leaves indicate overwatering.',
        },
        tags: ['popular', 'indoor'],
      });
    }

    setProductModalOpen(false);
  };

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cCode.trim()) return;

    addCoupon({
      code: cCode.trim().toUpperCase(),
      discountType: cType,
      discountValue: Number(cValue),
      minOrderValue: Number(cMin),
      description: cDesc.trim() || `Save ₹${cValue} on live plants`,
      isActive: true,
      expiryDate: '2027-12-31',
    });

    setCouponModalOpen(false);
    setCCode('');
    setCDesc('');
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      name: storeName,
      phone: storePhone,
      whatsappNumber: storeWhatsapp,
      gstin: storeGstin,
      freeDeliveryThreshold: Number(storeFreeThreshold),
      festivalBannerTitle: storeFestivalTitle,
      festivalBannerSubtext: storeFestivalSubtext,
      festivalBannerDiscount: storeFestivalDiscount,
    });
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 2000);
  };

  const filteredProducts = products.filter((p) =>
    p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.category.toLowerCase().includes(productSearch.toLowerCase())
  );

  const filteredOrders = orders.filter((o) =>
    orderStatusFilter === 'all' ? true : o.orderStatus === orderStatusFilter
  );

  if (currentUser?.role !== 'admin') {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-800 mx-auto flex items-center justify-center">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <h2 className="font-serif text-2xl font-bold text-stone-900">Admin Privileges Required</h2>
        <p className="text-xs text-stone-600 leading-relaxed">
          The Nursery Management Portal is restricted to authorized nursery administrators.
          Please sign in with your administrator account (e.g. <strong>geetabhutavale311@gmail.com</strong>).
        </p>
        <div className="pt-2 flex flex-col gap-2">
          <button
            onClick={() => openAuthModal('login')}
            className="w-full py-2.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
          >
            Sign in as Administrator
          </button>
          <button
            onClick={() => navigateTo('home')}
            className="w-full py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold transition-colors"
          >
            Return to Nursery Storefront
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner */}
      <div className="bg-[#154D34] text-white rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="font-serif font-bold text-2xl">प्रकृति</span>
            <span className="px-2 py-0.5 rounded bg-emerald-800 text-emerald-200 text-xs font-bold uppercase tracking-wider">
              Nursery Management Portal
            </span>
          </div>
          <p className="text-xs text-emerald-200">
            Real-time catalog, live plant inventory, dispatch updates and GST invoicing.
          </p>
        </div>

        <button
          onClick={() => navigateTo('home')}
          className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
        >
          <span>Return to Storefront</span>
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-stone-200 gap-2 sm:gap-6 text-xs sm:text-sm font-bold overflow-x-auto pb-1">
        {[
          { id: 'overview', label: 'Dashboard Overview', icon: LayoutDashboard },
          { id: 'products', label: `Plant Catalog (${products.length})`, icon: ShoppingBag },
          { id: 'orders', label: `Customer Orders (${orders.length})`, icon: Package },
          { id: 'users', label: `Registered Users (${allUsers.length})`, icon: Users },
          { id: 'coupons', label: `Coupons & Offers (${coupons.length})`, icon: Tag },
          { id: 'settings', label: 'Store & Festival Settings', icon: Settings },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`pb-3 border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? 'border-[#154D34] text-[#154D34]'
                  : 'border-transparent text-stone-500 hover:text-stone-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-xs font-bold uppercase text-stone-400">Total Revenue (INR)</span>
              <h3 className="text-2xl font-extrabold text-[#154D34] mt-1">₹{totalRevenue}</h3>
              <p className="text-[11px] text-emerald-700 mt-2 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                <span>GST Invoiced across India</span>
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-xs font-bold uppercase text-stone-400">Live Orders</span>
              <h3 className="text-2xl font-extrabold text-stone-900 mt-1">{orders.length}</h3>
              <p className="text-[11px] text-stone-500 mt-2">
                Across Mumbai, Pune, Bengaluru & Delhi NCR
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-xs font-bold uppercase text-stone-400">Plants Dispatched</span>
              <h3 className="text-2xl font-extrabold text-stone-900 mt-1">{totalPlantsSold} units</h3>
              <p className="text-[11px] text-emerald-700 mt-2">Acclimatized live greens</p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-xs font-bold uppercase text-stone-400">Low Stock Alert</span>
              <h3 className={`text-2xl font-extrabold mt-1 ${lowStockCount > 0 ? 'text-amber-600' : 'text-stone-900'}`}>
                {lowStockCount} varieties
              </h3>
              <p className="text-[11px] text-stone-500 mt-2">Under 15 pots in greenhouse</p>
            </div>
          </div>

          {/* Recent Orders in Overview */}
          <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden">
            <div className="p-5 border-b border-stone-100 flex items-center justify-between">
              <h3 className="font-bold text-stone-900 text-base">Recent Plant Orders</h3>
              <button
                onClick={() => setActiveTab('orders')}
                className="text-xs text-[#154D34] font-bold hover:underline"
              >
                View All Orders
              </button>
            </div>

            <div className="divide-y divide-stone-100 overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-stone-50 text-stone-500 font-bold uppercase">
                    <th className="p-3.5">Order ID</th>
                    <th className="p-3.5">Customer</th>
                    <th className="p-3.5">City & State</th>
                    <th className="p-3.5">Items</th>
                    <th className="p-3.5">Amount</th>
                    <th className="p-3.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {orders.slice(0, 4).map((ord) => (
                    <tr key={ord.id} className="hover:bg-stone-50">
                      <td className="p-3.5 font-bold font-mono text-[#154D34]">{ord.id}</td>
                      <td className="p-3.5 font-semibold text-stone-800">{ord.customerName}</td>
                      <td className="p-3.5 text-stone-600">{ord.shippingAddress.city}, {ord.shippingAddress.state}</td>
                      <td className="p-3.5 text-stone-500">{ord.items.length} items</td>
                      <td className="p-3.5 font-bold text-stone-900">₹{ord.totalAmount}</td>
                      <td className="p-3.5">
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[11px]">
                          {ord.orderStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: PRODUCT MANAGEMENT */}
      {activeTab === 'products' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-sm">
              <input
                type="text"
                value={productSearch}
                onChange={(e) => setProductSearch(e.target.value)}
                placeholder="Search plants by name or category..."
                className="w-full pl-9 pr-3 py-2 bg-white border border-stone-300 rounded-xl text-xs focus:outline-none focus:border-[#154D34]"
              />
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>

            <button
              onClick={handleOpenAddProduct}
              className="px-5 py-2.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Nursery Plant</span>
            </button>
          </div>

          <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-stone-50 text-stone-500 font-bold uppercase border-b border-stone-200">
                  <th className="p-3.5">Plant</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Price / MRP</th>
                  <th className="p-3.5">Stock</th>
                  <th className="p-3.5">Rating</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredProducts.map((p) => (
                  <tr key={p.id} className="hover:bg-stone-50">
                    <td className="p-3.5 flex items-center gap-3">
                      <SafeImage
                        src={p.images[0]}
                        alt={p.name}
                        className="w-12 h-12 rounded-xl object-cover bg-stone-100 border border-stone-200 shrink-0"
                      />
                      <div>
                        <span className="font-bold text-stone-900 block">{p.name}</span>
                        {p.nameHi && <span className="text-[11px] text-stone-500">{p.nameHi}</span>}
                      </div>
                    </td>
                    <td className="p-3.5 font-semibold text-emerald-800">{p.category}</td>
                    <td className="p-3.5">
                      <span className="font-bold text-stone-900">₹{p.price}</span>
                      <span className="text-stone-400 line-through ml-1.5">₹{p.mrp}</span>
                    </td>
                    <td className="p-3.5">
                      <div className="flex items-center gap-1.5">
                        <span className={`font-bold px-2 py-0.5 rounded text-xs ${p.stock <= 15 ? 'bg-amber-100 text-amber-900' : 'bg-stone-100 text-stone-700'}`}>
                          {p.stock} pots
                        </span>
                        <div className="flex flex-col gap-0.5">
                          <button
                            type="button"
                            onClick={() => updateProduct({ ...p, stock: p.stock + 1 })}
                            className="w-4 h-4 rounded bg-stone-100 hover:bg-emerald-100 hover:text-[#154D34] text-stone-600 flex items-center justify-center text-[10px] font-bold transition-colors"
                            title="Add 1 pot"
                          >
                            +
                          </button>
                          <button
                            type="button"
                            onClick={() => updateProduct({ ...p, stock: Math.max(0, p.stock - 1) })}
                            className="w-4 h-4 rounded bg-stone-100 hover:bg-rose-100 hover:text-rose-700 text-stone-600 flex items-center justify-center text-[10px] font-bold transition-colors"
                            title="Deduct 1 pot"
                          >
                            -
                          </button>
                        </div>
                      </div>
                    </td>
                    <td className="p-3.5 text-amber-600 font-bold">
                      ★ {p.rating} ({p.reviewCount})
                    </td>
                    <td className="p-3.5 text-right space-x-1">
                      <button
                        onClick={() => handleOpenEditProduct(p)}
                        className="p-1.5 text-stone-500 hover:text-stone-900 rounded-lg hover:bg-stone-200"
                        title="Edit Plant"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Delete ${p.name}?`)) deleteProduct(p.id);
                        }}
                        className="p-1.5 text-rose-500 hover:text-rose-700 rounded-lg hover:bg-rose-50"
                        title="Delete Plant"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: ORDER MANAGEMENT */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center gap-2">
            {['all', 'Placed', 'Confirmed', 'Packed', 'Dispatched', 'Delivered'].map((st) => (
              <button
                key={st}
                onClick={() => setOrderStatusFilter(st)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                  orderStatusFilter === st
                    ? 'bg-[#154D34] text-white shadow-xs'
                    : 'bg-white border border-stone-300 text-stone-700 hover:bg-stone-100'
                }`}
              >
                {st === 'all' ? 'All Orders' : st}
              </button>
            ))}
          </div>

          <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-stone-50 text-stone-500 font-bold uppercase border-b border-stone-200">
                  <th className="p-3.5">Order</th>
                  <th className="p-3.5">Customer & Mobile</th>
                  <th className="p-3.5">Shipping Destination</th>
                  <th className="p-3.5">Payment</th>
                  <th className="p-3.5">Amount</th>
                  <th className="p-3.5">Current Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-stone-50">
                    <td className="p-3.5 font-bold font-mono text-[#154D34]">
                      {ord.id}
                      <span className="block text-[11px] text-stone-400 font-normal">{ord.date}</span>
                    </td>
                    <td className="p-3.5">
                      <p className="font-bold text-stone-900">{ord.customerName}</p>
                      <p className="text-stone-500">+91 {ord.customerMobile}</p>
                    </td>
                    <td className="p-3.5 text-stone-700">
                      {ord.shippingAddress.city}, {ord.shippingAddress.state} ({ord.shippingAddress.pincode})
                    </td>
                    <td className="p-3.5">
                      <span className="font-semibold text-stone-800">{ord.paymentMethod}</span>
                      <span className="block text-[10px] text-emerald-700">{ord.paymentStatus}</span>
                    </td>
                    <td className="p-3.5 font-bold text-stone-900">₹{ord.totalAmount}</td>
                    <td className="p-3.5">
                      <select
                        value={ord.orderStatus}
                        onChange={(e) => updateOrderStatus(ord.id, e.target.value as any)}
                        className="p-1.5 bg-stone-100 border border-stone-300 rounded-lg text-xs font-semibold text-stone-800"
                      >
                        <option value="Pending">Pending</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Packed">Packed</option>
                        <option value="Shipped">Shipped</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => setSelectedInvoiceOrder(ord)}
                        className="px-2.5 py-1 bg-white border border-stone-300 rounded-lg text-[11px] font-semibold text-stone-700 hover:bg-stone-100 inline-flex items-center gap-1"
                      >
                        <FileText className="w-3 h-3 text-[#154D34]" />
                        <span>Invoice</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: USERS MANAGEMENT (FIRESTORE) */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-bold text-stone-900 text-base">Registered Plant Parents ({allUsers.length})</h3>
              <p className="text-xs text-stone-500">Live Firebase Authentication & Cloud Firestore customer accounts</p>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-stone-50 text-stone-500 font-bold uppercase border-b border-stone-200">
                  <th className="p-3.5">User Profile</th>
                  <th className="p-3.5">Email Address</th>
                  <th className="p-3.5">Mobile</th>
                  <th className="p-3.5">Account Role</th>
                  <th className="p-3.5">Registered Date</th>
                  <th className="p-3.5 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {allUsers.map((u) => (
                  <tr key={u.id} className="hover:bg-stone-50">
                    <td className="p-3.5 flex items-center gap-3">
                      <img
                        src={u.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                        alt={u.name}
                        className="w-9 h-9 rounded-full object-cover border border-emerald-100 shrink-0"
                      />
                      <div>
                        <span className="font-bold text-stone-900 block">{u.name}</span>
                        <span className="text-[10px] text-stone-400 font-mono">UID: {u.id.slice(0, 10)}...</span>
                      </div>
                    </td>
                    <td className="p-3.5 font-medium text-stone-800">{u.email}</td>
                    <td className="p-3.5 text-stone-600">{u.mobile ? `+91 ${u.mobile}` : '—'}</td>
                    <td className="p-3.5">
                      <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                        u.role === 'admin'
                          ? 'bg-amber-100 text-amber-900 border border-amber-300'
                          : 'bg-emerald-50 text-[#154D34] border border-emerald-200'
                      }`}>
                        {u.role === 'admin' ? '🛡️ Nursery Admin' : '🌱 Customer'}
                      </span>
                    </td>
                    <td className="p-3.5 text-stone-500">
                      {u.createdAt ? new Date(u.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : 'Active'}
                    </td>
                    <td className="p-3.5 text-right">
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold text-[11px]">
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Active</span>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: COUPONS & PROMOTIONS */}
      {activeTab === 'coupons' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-stone-900 text-base">Active Discount Coupons</h3>
            <button
              onClick={() => setCouponModalOpen(true)}
              className="px-4 py-2 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs font-bold flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Create Coupon</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {coupons.map((c) => (
              <div
                key={c.code}
                className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-2 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-base text-[#154D34]">{c.code}</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${c.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-100 text-stone-500'}`}>
                    {c.isActive ? 'Active' : 'Disabled'}
                  </span>
                </div>
                <p className="font-semibold text-stone-800">{c.description}</p>
                <p className="text-stone-500">
                  Value: {c.discountType === 'percentage' ? `${c.discountValue}% Off` : `₹${c.discountValue} Off`}
                </p>
                <p className="text-stone-500">Min spend: ₹{c.minOrderValue}</p>
                <p className="text-[11px] text-stone-400">Valid till {c.expiryDate}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: STORE & FESTIVAL SETTINGS */}
      {activeTab === 'settings' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-xs max-w-2xl space-y-6">
          <h3 className="font-bold text-stone-900 text-base">Indian Nursery Store Configuration</h3>

          {settingsSaved && (
            <div className="p-3 bg-emerald-100 border border-emerald-300 text-emerald-900 text-xs font-bold rounded-xl flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-700" />
              <span>Settings updated successfully!</span>
            </div>
          )}

          <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold mb-1">Nursery Brand Name</label>
                <input
                  type="text"
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Customer Support Phone (+91)</label>
                <input
                  type="text"
                  value={storePhone}
                  onChange={(e) => setStorePhone(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">WhatsApp Support Number</label>
                <input
                  type="text"
                  value={storeWhatsapp}
                  onChange={(e) => setStoreWhatsapp(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">GSTIN</label>
                <input
                  type="text"
                  value={storeGstin}
                  onChange={(e) => setStoreGstin(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border rounded-xl font-mono"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Free Delivery Threshold (₹)</label>
                <input
                  type="number"
                  value={storeFreeThreshold}
                  onChange={(e) => setStoreFreeThreshold(Number(e.target.value))}
                  className="w-full p-2.5 bg-stone-50 border rounded-xl"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-stone-200 space-y-3">
              <h4 className="font-bold text-stone-900 text-sm">Active Seasonal / Festival Banner</h4>
              <div>
                <label className="block font-semibold mb-1">Banner Headline</label>
                <input
                  type="text"
                  value={storeFestivalTitle}
                  onChange={(e) => setStoreFestivalTitle(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Banner Subtext</label>
                <input
                  type="text"
                  value={storeFestivalSubtext}
                  onChange={(e) => setStoreFestivalSubtext(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Discount Tag Text</label>
                <input
                  type="text"
                  value={storeFestivalDiscount}
                  onChange={(e) => setStoreFestivalDiscount(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border rounded-xl"
                />
              </div>
            </div>

            <button
              type="submit"
              className="px-6 py-2.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
            >
              Save Nursery Settings
            </button>
          </form>
        </div>
      )}

      {/* Product Add / Edit Modal */}
      {productModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl my-8 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-stone-200">
              <h4 className="font-bold text-stone-900 text-base">
                {editingProduct ? 'Edit Nursery Plant' : 'Add New Plant to Greenhouse'}
              </h4>
              <button onClick={() => setProductModalOpen(false)}>
                <X className="w-5 h-5 text-stone-400" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Product Name (English) *</label>
                <input
                  type="text"
                  required
                  value={pName}
                  onChange={(e) => setPName(e.target.value)}
                  className="w-full p-2 border rounded-xl"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold mb-1">Hindi Name (हिंदी)</label>
                  <input
                    type="text"
                    value={pNameHi}
                    onChange={(e) => setPNameHi(e.target.value)}
                    placeholder="e.g. तुलसी का पौधा"
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Marathi Name (मराठी)</label>
                  <input
                    type="text"
                    value={pNameMr}
                    onChange={(e) => setPNameMr(e.target.value)}
                    placeholder="e.g. तुळस रोप"
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Category</label>
                <select
                  value={pCategory}
                  onChange={(e) => setPCategory(e.target.value)}
                  className="w-full p-2 border rounded-xl"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-semibold mb-1">Price (₹) *</label>
                  <input
                    type="number"
                    required
                    value={pPrice}
                    onChange={(e) => setPPrice(Number(e.target.value))}
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">MRP (₹) *</label>
                  <input
                    type="number"
                    required
                    value={pMrp}
                    onChange={(e) => setPMrp(Number(e.target.value))}
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Stock (Pots)</label>
                  <input
                    type="number"
                    required
                    value={pStock}
                    onChange={(e) => setPStock(Number(e.target.value))}
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Plant Photo (Firebase Storage or URL)</label>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-[#154D34] border border-emerald-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors">
                      {uploadingImage ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                      <span>{uploadingImage ? 'Uploading to Firebase...' : 'Upload Image File'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        disabled={uploadingImage}
                        className="hidden"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          setUploadingImage(true);
                          try {
                            const url = await uploadImage(file);
                            setPImage(url);
                          } catch (err) {
                            console.warn('Image upload notice:', err);
                          } finally {
                            setUploadingImage(false);
                          }
                        }}
                      />
                    </label>
                    <span className="text-[11px] text-stone-400">or paste URL below</span>
                  </div>
                  <input
                    type="text"
                    value={pImage}
                    onChange={(e) => setPImage(e.target.value)}
                    placeholder="https://..."
                    className="w-full p-2 border rounded-xl"
                  />
                  {pImage && (
                    <div className="flex items-center gap-3 p-2 bg-stone-50 rounded-xl border border-stone-200">
                      <img
                        src={pImage}
                        alt="Preview"
                        className="w-12 h-12 rounded-lg object-cover bg-white border border-stone-200"
                      />
                      <span className="text-[11px] text-stone-500 font-medium">Image Preview Ready</span>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Description</label>
                <textarea
                  rows={3}
                  value={pDesc}
                  onChange={(e) => setPDesc(e.target.value)}
                  className="w-full p-2 border rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setProductModalOpen(false)}
                  className="px-4 py-2 font-semibold text-stone-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#154D34] text-white rounded-xl font-bold"
                >
                  Save Plant
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Coupon Modal */}
      {couponModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl space-y-4">
            <h4 className="font-bold text-stone-900 text-base">Create Discount Coupon</h4>
            <form onSubmit={handleCreateCoupon} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Coupon Code (e.g. MONSOON25)</label>
                <input
                  type="text"
                  required
                  value={cCode}
                  onChange={(e) => setCCode(e.target.value.toUpperCase())}
                  className="w-full p-2 border rounded-xl font-mono uppercase"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold mb-1">Discount Type</label>
                  <select
                    value={cType}
                    onChange={(e) => setCType(e.target.value as any)}
                    className="w-full p-2 border rounded-xl"
                  >
                    <option value="percentage">Percentage (%)</option>
                    <option value="flat">Flat Amount (₹)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold mb-1">Discount Value</label>
                  <input
                    type="number"
                    required
                    value={cValue}
                    onChange={(e) => setCValue(Number(e.target.value))}
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
              </div>
              <div>
                <label className="block font-semibold mb-1">Minimum Order Value (₹)</label>
                <input
                  type="number"
                  value={cMin}
                  onChange={(e) => setCMin(Number(e.target.value))}
                  className="w-full p-2 border rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Description</label>
                <input
                  type="text"
                  value={cDesc}
                  onChange={(e) => setCDesc(e.target.value)}
                  placeholder="e.g. 15% off on all live indoor plants"
                  className="w-full p-2 border rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setCouponModalOpen(false)}
                  className="px-4 py-2 font-semibold text-stone-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#154D34] text-white rounded-xl font-bold"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Invoice Modal for selected order */}
      {selectedInvoiceOrder && (
        <InvoiceModal
          order={selectedInvoiceOrder}
          onClose={() => setSelectedInvoiceOrder(null)}
        />
      )}
    </div>
  );
};
