import React, { useState } from 'react';
import { X, Lock, Mail, Phone, User as UserIcon, CheckCircle2, ArrowRight, ShieldCheck, KeyRound, Loader2, LogIn, UserPlus } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const AuthModal: React.FC = () => {
  const {
    authModalOpen,
    authModalMode,
    closeAuthModal,
    openAuthModal,
    loginWithEmail,
    registerWithEmail,
    resetPasswordEmail,
    loginUser,
    navigateTo,
    t,
  } = useApp();

  const [emailOrMobile, setEmailOrMobile] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerMobile, setRegisterMobile] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetSent, setResetSent] = useState(false);
  const [otpValue, setOtpValue] = useState('');
  const [simulatedOtp, setSimulatedOtp] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!authModalOpen) return null;

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!emailOrMobile.trim() || !password) {
      setErrorMsg('Please enter your email and password.');
      return;
    }

    const email = emailOrMobile.includes('@')
      ? emailOrMobile.trim()
      : `${emailOrMobile.trim()}@prakritinursery.in`;

    setIsSubmitting(true);
    const res = await loginWithEmail(email, password);
    setIsSubmitting(false);

    if (!res.success) {
      setErrorMsg(res.error || 'Failed to sign in. Please verify your credentials.');
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!fullName.trim() || !registerMobile.trim() || !registerEmail.trim() || !password) {
      setErrorMsg('Please fill in all mandatory fields.');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('Password must be at least 6 characters.');
      return;
    }
    if (confirmPassword && password !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    setIsSubmitting(true);
    const res = await registerWithEmail(
      fullName.trim(),
      registerEmail.trim(),
      password,
      registerMobile.trim()
    );
    setIsSubmitting(false);

    if (!res.success) {
      setErrorMsg(res.error || 'Could not complete registration.');
    }
  };

  const handleSendResetEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!forgotEmail.trim()) {
      setErrorMsg('Please enter your registered email address.');
      return;
    }
    setIsSubmitting(true);
    const res = await resetPasswordEmail(forgotEmail.trim());
    setIsSubmitting(false);

    if (res.success) {
      setResetSent(true);
    } else {
      setErrorMsg(res.error || 'Failed to send password reset email.');
    }
  };

  const handleSendOtp = () => {
    if (!emailOrMobile.trim()) {
      setErrorMsg('Please enter your mobile number first.');
      return;
    }
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setSimulatedOtp(code);
    openAuthModal('otp');
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpValue || otpValue !== simulatedOtp) {
      setErrorMsg('Invalid OTP. Please check the code.');
      return;
    }
    const email = emailOrMobile.includes('@')
      ? emailOrMobile.trim()
      : `${emailOrMobile.trim()}@prakritinursery.in`;
    loginUser(email, 'customer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden border border-stone-100 animate-in fade-in zoom-in-95 duration-150">
        {/* Top Header */}
        <div className="bg-[#154D34] text-white p-6 relative">
          <button
            onClick={closeAuthModal}
            className="absolute top-4 right-4 p-1.5 rounded-full text-white/70 hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-1">
            <span className="font-serif font-bold text-xl">प्रकृति</span>
            <span className="text-xs bg-emerald-800 px-2 py-0.5 rounded text-emerald-200">
              Prakriti Plant Nursery
            </span>
          </div>

          <h2 className="text-lg font-bold">
            {authModalMode === 'login' && 'Welcome Back Plant Lover!'}
            {authModalMode === 'register' && 'Create Your Green Account'}
            {authModalMode === 'otp' && 'Verify Mobile OTP'}
            {authModalMode === 'forgot' && 'Reset Password'}
          </h2>
          <p className="text-xs text-emerald-200 mt-0.5">
            {authModalMode === 'login' && 'Sign in to access your wishlist, plant orders and care history.'}
            {authModalMode === 'register' && 'Join thousands of plant parents across India.'}
            {authModalMode === 'otp' && `Enter the 6-digit code sent to ${emailOrMobile}`}
            {authModalMode === 'forgot' && 'Enter your registered email address to receive a secure reset link.'}
          </p>
        </div>

        {/* Tab Toggle: Sign In vs Sign Up */}
        <div className="flex border-b border-stone-200 bg-stone-50 px-6 pt-2">
          <button
            type="button"
            onClick={() => {
              setErrorMsg('');
              openAuthModal('login');
            }}
            className={`pb-2.5 px-4 text-xs font-bold border-b-2 flex items-center gap-1.5 transition-colors ${
              authModalMode === 'login' || authModalMode === 'otp'
                ? 'border-[#154D34] text-[#154D34]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Sign In</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setErrorMsg('');
              openAuthModal('register');
            }}
            className={`pb-2.5 px-4 text-xs font-bold border-b-2 flex items-center gap-1.5 transition-colors ${
              authModalMode === 'register'
                ? 'border-[#154D34] text-[#154D34]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Sign Up (Register)</span>
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6">
          {errorMsg && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 font-medium">
              {errorMsg}
            </div>
          )}

          {/* 1. Login Mode */}
          {authModalMode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Email Address or Mobile
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={emailOrMobile}
                    onChange={(e) => setEmailOrMobile(e.target.value)}
                    placeholder="e.g. geetabhutavale311@gmail.com"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:outline-none focus:border-[#154D34]"
                  />
                  <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs font-semibold text-stone-700">Password</label>
                  <button
                    type="button"
                    onClick={() => {
                      setForgotEmail(emailOrMobile.includes('@') ? emailOrMobile : '');
                      setResetSent(false);
                      openAuthModal('forgot');
                    }}
                    className="text-xs text-[#154D34] hover:underline font-medium"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:outline-none focus:border-[#154D34]"
                  />
                  <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs sm:text-sm font-semibold shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Signing In...</span>
                  </>
                ) : (
                  <span>Sign In with Firebase</span>
                )}
              </button>

              <div className="relative my-4 text-center">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-stone-200" />
                </div>
                <span className="relative bg-white px-2 text-[11px] text-stone-400 uppercase">
                  Or Login With
                </span>
              </div>

              <button
                type="button"
                onClick={handleSendOtp}
                className="w-full py-2.5 bg-emerald-50 hover:bg-emerald-100 text-[#154D34] border border-emerald-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <KeyRound className="w-4 h-4" />
                <span>Login via Instant Mobile OTP</span>
              </button>

              <div className="pt-2 text-center text-xs text-stone-500">
                <span>New to Prakriti Nursery? </span>
                <button
                  type="button"
                  onClick={() => openAuthModal('register')}
                  className="font-bold text-[#154D34] hover:underline"
                >
                  Create an Account
                </button>
              </div>

              {/* Demo Sign In Options */}
              <div className="mt-4 pt-3 border-t border-stone-100 space-y-2 text-center">
                <p className="text-[11px] text-stone-400 font-medium">Quick Demo Access:</p>
                <div className="flex justify-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setEmailOrMobile('geetabhutavale311@gmail.com');
                      setPassword('Prakriti@123');
                    }}
                    className="px-2.5 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-lg text-[11px] font-semibold hover:bg-amber-100 transition-colors"
                  >
                    Fill Admin (Geeta)
                  </button>
                  <button
                    type="button"
                    onClick={() => loginUser('admin@prakritinursery.in', 'admin')}
                    className="px-2.5 py-1 bg-emerald-50 text-[#154D34] border border-emerald-200 rounded-lg text-[11px] font-semibold hover:bg-emerald-100 transition-colors"
                  >
                    Direct Admin Pass
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* 2. Register Mode */}
          {authModalMode === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Full Name</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Geeta Bhutavale"
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#154D34]"
                  />
                  <UserIcon className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Mobile (+91)</label>
                <div className="relative">
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={registerMobile}
                    onChange={(e) => setRegisterMobile(e.target.value.replace(/\D/g, ''))}
                    placeholder="10-digit mobile number"
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#154D34]"
                  />
                  <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Email Address</label>
                <div className="relative">
                  <input
                    type="email"
                    required
                    value={registerEmail}
                    onChange={(e) => setRegisterEmail(e.target.value)}
                    placeholder="geeta@gmail.com"
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#154D34]"
                  />
                  <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Password</label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Min 6 chars"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs focus:outline-none focus:border-[#154D34]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Confirm</label>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repeat"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs focus:outline-none focus:border-[#154D34]"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs sm:text-sm font-semibold shadow-xs transition-colors mt-2 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Registering Account...</span>
                  </>
                ) : (
                  <span>Create Account with Firebase</span>
                )}
              </button>

              <div className="text-center text-xs text-stone-500 pt-2">
                <span>Already have an account? </span>
                <button
                  type="button"
                  onClick={() => openAuthModal('login')}
                  className="font-bold text-[#154D34] hover:underline"
                >
                  Sign In
                </button>
              </div>
            </form>
          )}

          {/* 3. OTP Verification Mode */}
          {authModalMode === 'otp' && (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              {simulatedOtp && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-center justify-between">
                  <div>
                    <span>Demo Simulator OTP: </span>
                    <strong className="font-mono text-sm tracking-widest">{simulatedOtp}</strong>
                  </div>
                  <button
                    type="button"
                    onClick={() => setOtpValue(simulatedOtp)}
                    className="px-2 py-1 bg-amber-200 text-amber-900 rounded font-semibold text-[11px]"
                  >
                    Auto-Fill
                  </button>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Enter 6-digit OTP
                </label>
                <input
                  type="text"
                  maxLength={6}
                  required
                  value={otpValue}
                  onChange={(e) => setOtpValue(e.target.value.replace(/\D/g, ''))}
                  placeholder="• • • • • •"
                  className="w-full tracking-widest text-center text-lg font-bold py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs sm:text-sm font-semibold transition-colors"
              >
                Verify & Continue
              </button>

              <button
                type="button"
                onClick={() => openAuthModal('login')}
                className="w-full text-center text-xs text-stone-500 hover:text-stone-800"
              >
                Back to Password Login
              </button>
            </form>
          )}

          {/* 4. Forgot Password Mode */}
          {authModalMode === 'forgot' && (
            <div className="space-y-4">
              {resetSent ? (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-[#154D34] mx-auto" />
                  <h3 className="text-sm font-bold text-emerald-950">Password Reset Email Sent!</h3>
                  <p className="text-xs text-stone-600">
                    We have dispatched a secure password reset link to <strong>{forgotEmail}</strong>.
                    Follow the instructions in your inbox to reset your password.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setResetSent(false);
                      openAuthModal('login');
                    }}
                    className="mt-3 w-full py-2 bg-[#154D34] text-white rounded-xl text-xs font-semibold"
                  >
                    Return to Sign In
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSendResetEmail} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Enter Registered Email
                    </label>
                    <div className="relative">
                      <input
                        type="email"
                        required
                        value={forgotEmail}
                        onChange={(e) => setForgotEmail(e.target.value)}
                        placeholder="e.g. geeta@gmail.com"
                        className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#154D34]"
                      />
                      <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-2.5 bg-[#154D34] text-white rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Sending Link...</span>
                      </>
                    ) : (
                      <span>Send Reset Link</span>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => openAuthModal('login')}
                    className="w-full text-center text-xs text-stone-500 hover:text-stone-800"
                  >
                    Return to Sign In
                  </button>
                </form>
              )}
            </div>
          )}
        </div>

        {/* Full Page Link */}
        <div className="bg-stone-50 border-t border-stone-100 px-6 py-2.5 text-center text-xs text-stone-500 flex items-center justify-center gap-2">
          <span>Prefer a dedicated full page?</span>
          <button
            type="button"
            onClick={() => {
              const target = authModalMode === 'register' ? 'register' : 'login';
              closeAuthModal();
              navigateTo(target);
            }}
            className="font-bold text-[#154D34] hover:underline"
          >
            Open {authModalMode === 'register' ? 'Sign Up' : 'Sign In'} Page →
          </button>
        </div>
      </div>
    </div>
  );
};
