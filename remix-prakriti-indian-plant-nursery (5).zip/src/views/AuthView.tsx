import React, { useState, useEffect } from 'react';
import {
  Lock,
  Mail,
  Phone,
  User as UserIcon,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  ShieldCheck,
  KeyRound,
  Loader2,
  Sprout,
  Heart,
  PackageCheck,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface AuthViewProps {
  initialMode?: 'login' | 'register';
}

export const AuthView: React.FC<AuthViewProps> = ({ initialMode = 'login' }) => {
  const {
    currentUser,
    loginWithEmail,
    registerWithEmail,
    resetPasswordEmail,
    loginUser,
    logoutUser,
    navigateTo,
    t,
  } = useApp();

  const [mode, setMode] = useState<'login' | 'register' | 'forgot' | 'otp'>(initialMode);
  const [emailOrMobile, setEmailOrMobile] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerMobile, setRegisterMobile] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetSent, setResetSent] = useState(false);
  const [otpValue, setOtpValue] = useState('');
  const [simulatedOtp, setSimulatedOtp] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    setMode(initialMode);
    setErrorMsg('');
  }, [initialMode]);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!emailOrMobile.trim() || !password) {
      setErrorMsg('Please enter your email and password.');
      return;
    }

    const email = emailOrMobile.includes('@')
      ? emailOrMobile.trim()
      : `${emailOrMobile.trim()}@prakritinursery.in`;

    setIsSubmitting(true);
    const res = await loginWithEmail(email, password);
    setIsSubmitting(false);

    if (res.success) {
      navigateTo('account');
    } else {
      setErrorMsg(res.error || 'Failed to sign in. Please verify your email and password.');
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!fullName.trim() || !registerMobile.trim() || !registerEmail.trim() || !password) {
      setErrorMsg('Please fill in all mandatory fields.');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('Password must be at least 6 characters.');
      return;
    }
    if (confirmPassword && password !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    setIsSubmitting(true);
    const res = await registerWithEmail(
      fullName.trim(),
      registerEmail.trim(),
      password,
      registerMobile.trim()
    );
    setIsSubmitting(false);

    if (res.success) {
      navigateTo('account');
    } else {
      setErrorMsg(res.error || 'Could not complete registration. Please try again.');
    }
  };

  const handleSendResetEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!forgotEmail.trim()) {
      setErrorMsg('Please enter your registered email address.');
      return;
    }
    setIsSubmitting(true);
    const res = await resetPasswordEmail(forgotEmail.trim());
    setIsSubmitting(false);

    if (res.success) {
      setResetSent(true);
    } else {
      setErrorMsg(res.error || 'Failed to send password reset email.');
    }
  };

  const handleSendOtp = () => {
    if (!emailOrMobile.trim()) {
      setErrorMsg('Please enter your mobile number or email first.');
      return;
    }
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setSimulatedOtp(code);
    setMode('otp');
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpValue || otpValue !== simulatedOtp) {
      setErrorMsg('Invalid OTP. Please check the code.');
      return;
    }
    const email = emailOrMobile.includes('@')
      ? emailOrMobile.trim()
      : `${emailOrMobile.trim()}@prakritinursery.in`;
    loginUser(email, 'customer');
    navigateTo('account');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Top Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-stone-500 mb-6">
        <button
          onClick={() => navigateTo('home')}
          className="flex items-center gap-1 hover:text-[#154D34] transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Home</span>
        </button>
        <span>/</span>
        <span className="font-semibold text-stone-800">
          {mode === 'login' ? 'Sign In' : mode === 'register' ? 'Sign Up / Register' : 'Account Access'}
        </span>
      </div>

      {/* Active Session Status Notification (Non-blocking) */}
      {currentUser && (
        <div className="max-w-5xl mx-auto mb-6 p-4 rounded-2xl bg-emerald-50/90 border border-emerald-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[#154D34] text-white flex items-center justify-center font-bold text-xs shrink-0">
              {currentUser.name?.charAt(0) || 'U'}
            </div>
            <div>
              <p className="text-xs font-bold text-stone-900">
                Currently signed in as {currentUser.name} ({currentUser.email})
              </p>
              <p className="text-[11px] text-stone-600">
                You are currently active. You can switch accounts using the form below, create a new profile, or visit your account dashboard.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 self-stretch sm:self-auto shrink-0">
            <button
              type="button"
              onClick={() => navigateTo('account')}
              className="flex-1 sm:flex-initial px-3.5 py-1.5 bg-[#154D34] hover:bg-[#0D3222] text-white text-xs font-bold rounded-xl transition-colors shadow-2xs"
            >
              Go to Account
            </button>
            <button
              type="button"
              onClick={logoutUser}
              className="flex-1 sm:flex-initial px-3.5 py-1.5 bg-white hover:bg-stone-50 text-stone-700 border border-stone-300 text-xs font-semibold rounded-xl transition-colors"
            >
              Sign Out
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start max-w-5xl mx-auto">
        {/* Left Side: Brand Benefits */}
        <div className="hidden lg:block lg:col-span-5 space-y-6 pt-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-700 flex items-center justify-center text-white shadow-md">
              <Sprout className="w-6 h-6 text-emerald-100" />
            </div>
            <div>
              <span className="font-serif text-2xl font-bold text-stone-900 tracking-tight">
                प्रकृति
              </span>
              <span className="ml-2 text-xs uppercase tracking-wider font-semibold px-2 py-0.5 rounded bg-emerald-100 text-[#154D34]">
                Plant Nursery
              </span>
            </div>
          </div>

          <h2 className="font-serif text-2xl font-bold text-stone-900 leading-tight">
            Your Personal Garden Oasis & Nursery Portal
          </h2>
          <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
            Create an account or sign in to seamlessly track orders, preserve your plant wishlist, and consult certified nursery plant doctors.
          </p>

          <div className="space-y-4 pt-2">
            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-white border border-stone-200 shadow-2xs">
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-[#154D34] flex items-center justify-center shrink-0">
                <Heart className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-stone-900">Cloud Wishlist Sync</h4>
                <p className="text-[11px] text-stone-500 mt-0.5">
                  Save your favorite tropicals, succulents, and bonsai across all your devices.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-white border border-stone-200 shadow-2xs">
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-[#154D34] flex items-center justify-center shrink-0">
                <PackageCheck className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-stone-900">Live Greenhouse Tracking</h4>
                <p className="text-[11px] text-stone-500 mt-0.5">
                  Real-time status updates from potted dispatch to doorstep delivery.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-white border border-stone-200 shadow-2xs">
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-[#154D34] flex items-center justify-center shrink-0">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-stone-900">Verified Plant Guarantee</h4>
                <p className="text-[11px] text-stone-500 mt-0.5">
                  Healthy transit guarantee & 7-day plant replacement policy with GST billing.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Auth Card Form */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-stone-200 shadow-xl overflow-hidden">
          {/* Card Header & Tabs */}
          <div className="bg-[#154D34] text-white p-6 sm:p-8">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold uppercase tracking-wider bg-emerald-800/80 px-2.5 py-1 rounded-full text-emerald-200">
                Secure Authentication
              </span>
              <span className="text-xs text-emerald-200 font-medium">Pan-India Nursery</span>
            </div>

            <h1 className="font-serif text-2xl font-bold text-white">
              {mode === 'login' && 'Sign In to Your Account'}
              {mode === 'register' && 'Create Your Plant Parent Account'}
              {mode === 'forgot' && 'Reset Your Password'}
              {mode === 'otp' && 'Verify Mobile OTP'}
            </h1>
            <p className="text-xs text-emerald-100 mt-1">
              {mode === 'login' && 'Enter your credentials to access your orders, invoices and wishlist.'}
              {mode === 'register' && 'Sign up in 30 seconds to enjoy fast checkout and member perks.'}
              {mode === 'forgot' && 'We will send a secure password reset link to your email address.'}
              {mode === 'otp' && `Enter the 6-digit confirmation code sent to ${emailOrMobile}`}
            </p>

            {/* Mode Switcher Tabs */}
            <div className="grid grid-cols-2 gap-2 mt-6 bg-emerald-950/40 p-1 rounded-2xl border border-emerald-700/50">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setErrorMsg('');
                }}
                className={`py-2 text-xs font-bold rounded-xl transition-all ${
                  mode === 'login'
                    ? 'bg-white text-[#154D34] shadow-sm'
                    : 'text-emerald-200 hover:text-white'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setErrorMsg('');
                }}
                className={`py-2 text-xs font-bold rounded-xl transition-all ${
                  mode === 'register'
                    ? 'bg-white text-[#154D34] shadow-sm'
                    : 'text-emerald-200 hover:text-white'
                }`}
              >
                Sign Up / Register
              </button>
            </div>
          </div>

          {/* Form Content */}
          <div className="p-6 sm:p-8">
            {errorMsg && (
              <div className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 font-medium">
                {errorMsg}
              </div>
            )}

            {/* 1. SIGN IN MODE */}
            {mode === 'login' && (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    Email Address or Mobile
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={emailOrMobile}
                      onChange={(e) => setEmailOrMobile(e.target.value)}
                      placeholder="e.g. geetabhutavale311@gmail.com"
                      className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:outline-none focus:border-[#154D34] transition-colors"
                    />
                    <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="text-xs font-semibold text-stone-700">Password</label>
                    <button
                      type="button"
                      onClick={() => {
                        setForgotEmail(emailOrMobile.includes('@') ? emailOrMobile : '');
                        setResetSent(false);
                        setMode('forgot');
                      }}
                      className="text-xs text-[#154D34] hover:underline font-medium"
                    >
                      Forgot Password?
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:outline-none focus:border-[#154D34] transition-colors"
                    />
                    <Lock className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs sm:text-sm font-bold shadow-sm transition-colors flex items-center justify-center gap-2 mt-2"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Signing In...</span>
                    </>
                  ) : (
                    <span>Sign In</span>
                  )}
                </button>

                <div className="relative my-5 text-center">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-stone-200" />
                  </div>
                  <span className="relative bg-white px-3 text-[11px] text-stone-400 uppercase font-medium">
                    Or Quick Login
                  </span>
                </div>

                <button
                  type="button"
                  onClick={handleSendOtp}
                  className="w-full py-2.5 bg-emerald-50 hover:bg-emerald-100 text-[#154D34] border border-emerald-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                >
                  <KeyRound className="w-4 h-4" />
                  <span>Login via Mobile OTP</span>
                </button>

                <div className="pt-3 text-center text-xs text-stone-600">
                  <span>Don't have an account yet? </span>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('register');
                      setErrorMsg('');
                    }}
                    className="font-bold text-[#154D34] hover:underline"
                  >
                    Sign Up Now
                  </button>
                </div>

                {/* Demo Quick Access */}
                <div className="mt-5 pt-4 border-t border-stone-100 space-y-2 text-center bg-stone-50/70 p-3 rounded-2xl">
                  <p className="text-[11px] text-stone-500 font-medium">Quick One-Click Demo Access:</p>
                  <div className="flex flex-wrap justify-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setEmailOrMobile('geetabhutavale311@gmail.com');
                        setPassword('Prakriti@123');
                      }}
                      className="px-3 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-lg text-[11px] font-semibold hover:bg-amber-100 transition-colors"
                    >
                      Fill Admin (Geeta)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        loginUser('admin@prakritinursery.in', 'admin');
                        navigateTo('admin');
                      }}
                      className="px-3 py-1 bg-emerald-50 text-[#154D34] border border-emerald-200 rounded-lg text-[11px] font-semibold hover:bg-emerald-100 transition-colors"
                    >
                      Direct Admin Portal
                    </button>
                  </div>
                </div>
              </form>
            )}

            {/* 2. SIGN UP / REGISTER MODE */}
            {mode === 'register' && (
              <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Full Name *
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Geeta Bhutavale"
                      className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#154D34]"
                    />
                    <UserIcon className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Mobile Number (+91) *
                  </label>
                  <div className="relative">
                    <input
                      type="tel"
                      required
                      maxLength={10}
                      value={registerMobile}
                      onChange={(e) => setRegisterMobile(e.target.value.replace(/\D/g, ''))}
                      placeholder="10-digit mobile number"
                      className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#154D34]"
                    />
                    <Phone className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Email Address *
                  </label>
                  <div className="relative">
                    <input
                      type="email"
                      required
                      value={registerEmail}
                      onChange={(e) => setRegisterEmail(e.target.value)}
                      placeholder="e.g. geeta@example.com"
                      className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#154D34]"
                    />
                    <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Password (min 6 chars) *
                    </label>
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#154D34]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Confirm Password *
                    </label>
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#154D34]"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs sm:text-sm font-bold shadow-sm transition-colors mt-3 flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Creating Account...</span>
                    </>
                  ) : (
                    <span>Complete Sign Up</span>
                  )}
                </button>

                <div className="text-center text-xs text-stone-600 pt-3">
                  <span>Already have a Prakriti account? </span>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('login');
                      setErrorMsg('');
                    }}
                    className="font-bold text-[#154D34] hover:underline"
                  >
                    Sign In
                  </button>
                </div>
              </form>
            )}

            {/* 3. FORGOT PASSWORD MODE */}
            {mode === 'forgot' && (
              <form onSubmit={handleSendResetEmail} className="space-y-4">
                {resetSent ? (
                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-2">
                    <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                    <h4 className="font-bold text-stone-900 text-sm">Reset Link Sent!</h4>
                    <p className="text-xs text-stone-600">
                      We have sent password recovery instructions to <strong>{forgotEmail}</strong>.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setResetSent(false);
                        setMode('login');
                      }}
                      className="mt-3 px-4 py-2 bg-[#154D34] text-white rounded-xl text-xs font-bold"
                    >
                      Return to Sign In
                    </button>
                  </div>
                ) : (
                  <>
                    <p className="text-xs text-stone-600 leading-relaxed">
                      Enter the email address registered with your account and we will send you a secure link to reset your password.
                    </p>
                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">
                        Registered Email
                      </label>
                      <div className="relative">
                        <input
                          type="email"
                          required
                          value={forgotEmail}
                          onChange={(e) => setForgotEmail(e.target.value)}
                          placeholder="e.g. yourname@example.com"
                          className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#154D34]"
                        />
                        <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-3 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs sm:text-sm font-bold shadow-sm transition-colors flex items-center justify-center gap-2"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Sending Link...</span>
                        </>
                      ) : (
                        <span>Send Password Reset Link</span>
                      )}
                    </button>

                    <div className="text-center pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setMode('login');
                          setErrorMsg('');
                        }}
                        className="text-xs text-[#154D34] font-bold hover:underline"
                      >
                        Back to Sign In
                      </button>
                    </div>
                  </>
                )}
              </form>
            )}

            {/* 4. OTP MODE */}
            {mode === 'otp' && (
              <form onSubmit={handleVerifyOtp} className="space-y-4">
                {simulatedOtp && (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-center justify-between">
                    <div>
                      <p className="font-semibold">Simulated SMS OTP Code:</p>
                      <p className="text-lg font-mono font-bold tracking-widest text-amber-800">
                        {simulatedOtp}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setOtpValue(simulatedOtp)}
                      className="px-2.5 py-1 bg-amber-200 hover:bg-amber-300 rounded text-[11px] font-bold text-amber-900"
                    >
                      Auto Fill
                    </button>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Enter 6-Digit OTP Code
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={otpValue}
                    onChange={(e) => setOtpValue(e.target.value.replace(/\D/g, ''))}
                    placeholder="123456"
                    className="w-full px-4 py-3 text-center text-lg font-mono font-bold tracking-widest bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-[#154D34]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs sm:text-sm font-bold shadow-sm transition-colors"
                >
                  Verify & Continue
                </button>

                <div className="text-center pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setMode('login');
                      setErrorMsg('');
                    }}
                    className="text-xs text-stone-500 hover:text-stone-800"
                  >
                    Cancel and return to Sign In
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
