import React, { useState, useMemo } from 'react';
import {
  Heart,
  Star,
  ShoppingBag,
  Zap,
  Truck,
  ShieldCheck,
  CheckCircle2,
  Droplets,
  Sun,
  Thermometer,
  Sprout,
  Dog,
  Sparkles,
  ArrowLeft,
  Share2,
  AlertCircle,
  Plus,
  Minus,
  MessageSquare,
  Bot,
  RefreshCw,
  Send,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PincodeChecker } from '../components/PincodeChecker';
import { SafeImage } from '../components/SafeImage';
import { ProductCard } from '../components/ProductCard';
import { getSimilarFlowerPlants } from '../lib/plantSearch';

export const ProductDetailView: React.FC = () => {
  const {
    products,
    selectedProductSlug,
    navigateTo,
    addToCart,
    toggleWishlist,
    isInWishlist,
    reviews,
    addReview,
    language,
    t,
  } = useApp();

  const product = products.find((p) => p.slug === selectedProductSlug) || products[0];

  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'care' | 'specs' | 'reviews'>('care');
  const [careSection, setCareSection] = useState<'watering' | 'sunlight' | 'fertilizer' | 'repotting' | 'pruning' | 'problems'>('watering');

  // AI Plant Doctor for this specific product
  const [aiProductQuestion, setAiProductQuestion] = useState('');
  const [aiProductAnswer, setAiProductAnswer] = useState<string | null>(null);
  const [aiProductLoading, setAiProductLoading] = useState(false);

  // Review submission state
  const [reviewModalOpen, setReviewModalOpen] = useState(false);
  const [newReviewName, setNewReviewName] = useState('');
  const [newReviewCity, setNewReviewCity] = useState('');
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [newReviewTitle, setNewReviewTitle] = useState('');
  const [newReviewComment, setNewReviewComment] = useState('');
  const [reviewSuccess, setReviewSuccess] = useState(false);

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 text-center">
        <h2 className="text-xl font-bold text-stone-900">Product not found</h2>
        <button
          onClick={() => navigateTo('catalog')}
          className="mt-4 px-6 py-2.5 bg-[#154D34] text-white rounded-full text-xs font-semibold"
        >
          Back to Catalogue
        </button>
      </div>
    );
  }

  const isLiked = isInWishlist(product.id);
  const safePrice = Number(product.price ?? (product as any)?.priceInINR) || 0;
  const safeMrp = Number(product.mrp) || Math.round(safePrice * 1.3);
  const discountPercent = safeMrp > safePrice ? Math.round(((safeMrp - safePrice) / safeMrp) * 100) : 0;
  const savings = Math.max(0, safeMrp - safePrice);

  const productReviews = reviews.filter((r) => r.productId === product.id);

  const subName = language === 'hi' ? product.nameHi : language === 'mr' ? product.nameMr : null;

  const similarPlants = useMemo(() => {
    if (!product) return [];
    return getSimilarFlowerPlants(product, products, 4);
  }, [product, products]);

  const handleAddToCart = () => {
    addToCart(product, quantity);
  };

  const handleBuyNow = () => {
    addToCart(product, quantity);
    navigateTo('checkout');
  };

  const handleAskProductAi = async (customPrompt?: string) => {
    const q = customPrompt || aiProductQuestion;
    if (!q.trim()) return;

    setAiProductLoading(true);
    try {
      const res = await fetch('/api/plant-ai-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: q,
          plantName: product.name,
          category: product.category,
          language,
        }),
      });
      const data = await res.json();
      if (data.success && data.advice) {
        setAiProductAnswer(data.advice);
      }
    } catch (err) {
      console.error('Error asking AI:', err);
    } finally {
      setAiProductLoading(false);
    }
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewName.trim() || !newReviewComment.trim()) return;

    addReview({
      productId: product.id,
      userName: newReviewName.trim(),
      city: newReviewCity.trim() || 'India',
      rating: newReviewRating,
      title: newReviewTitle.trim() || 'Happy Plant Parent',
      comment: newReviewComment.trim(),
      verifiedPurchase: true,
    });

    setReviewSuccess(true);
    setTimeout(() => {
      setReviewSuccess(false);
      setReviewModalOpen(false);
      setNewReviewName('');
      setNewReviewComment('');
      setNewReviewTitle('');
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Breadcrumb / Back button */}
      <div className="flex items-center gap-2 text-xs text-stone-500">
        <button
          onClick={() => navigateTo('catalog')}
          className="flex items-center gap-1 hover:text-[#154D34] font-medium"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Nursery Plants</span>
        </button>
        <span>/</span>
        <span className="text-stone-400">{product.category}</span>
        <span>/</span>
        <span className="text-stone-800 font-semibold truncate max-w-xs">{product.name}</span>
      </div>

      {/* Main Product Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
        {/* Left Column: Image Gallery */}
        <div className="lg:col-span-6 space-y-4">
          <div className="relative aspect-square w-full rounded-3xl overflow-hidden bg-stone-100 border border-stone-200 shadow-xs">
            <SafeImage
              src={product.images[activeImageIdx] || product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            {discountPercent > 0 && (
              <div className="absolute top-4 left-4 bg-rose-600 text-white text-xs font-bold px-3 py-1 rounded-lg shadow-sm">
                {discountPercent}% OFF MRP
              </div>
            )}
            <button
              onClick={() => toggleWishlist(product.id)}
              className={`absolute top-4 right-4 p-3 rounded-full backdrop-blur-md shadow-md transition-colors ${
                isLiked
                  ? 'bg-rose-50 text-rose-600'
                  : 'bg-white/80 text-stone-700 hover:text-rose-600 hover:bg-white'
              }`}
            >
              <Heart className={`w-5 h-5 ${isLiked ? 'fill-rose-600' : ''}`} />
            </button>
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex gap-3">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIdx(idx)}
                  className={`relative w-20 h-20 rounded-xl overflow-hidden border-2 transition-all ${
                    activeImageIdx === idx
                      ? 'border-[#154D34] ring-2 ring-[#154D34]/20'
                      : 'border-stone-200 hover:border-stone-400 opacity-70 hover:opacity-100'
                  }`}
                >
                  <SafeImage src={img} alt="Thumbnail" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}

          {/* Quick Features Highlight */}
          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 grid grid-cols-2 gap-3 text-xs text-stone-700">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>5-Layer Plant Packaging</span>
            </div>
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>Pan-India 2-4 Day Delivery</span>
            </div>
            <div className="flex items-center gap-2">
              <Sprout className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>Nursery Pot & Soil Included</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>Free 7-Day Replacement</span>
            </div>
          </div>
        </div>

        {/* Right Column: Product Details & Purchase Actions */}
        <div className="lg:col-span-6 space-y-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#154D34]">
              {product.category}
            </span>
            <h1 className="font-serif text-2xl sm:text-3xl font-extrabold text-stone-900 mt-1">
              {product.name}
            </h1>
            {subName && (
              <p className="text-base font-semibold text-stone-700 mt-0.5">
                {subName}
              </p>
            )}

            {/* Rating Bar */}
            <div className="flex items-center gap-3 mt-3">
              <div className="flex items-center gap-1 bg-amber-50 text-amber-900 px-2.5 py-1 rounded-lg text-xs font-bold">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span>{product.rating}</span>
              </div>
              <span className="text-xs text-stone-500">
                Based on {product.reviewCount} verified Indian customer reviews
              </span>
            </div>
          </div>

          {/* Pricing Box */}
          <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-stone-200">
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-extrabold text-[#154D34]">
                ₹{safePrice.toLocaleString('en-IN')}
              </span>
              <span className="text-sm text-stone-400 line-through">
                ₹{safeMrp.toLocaleString('en-IN')}
              </span>
              {savings > 0 && (
                <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                  Save ₹{savings.toLocaleString('en-IN')} ({discountPercent}%)
                </span>
              )}
            </div>
            <p className="text-[11px] text-stone-500 mt-1">
              Inclusive of all taxes (GST included). Free delivery on orders above ₹999.
            </p>
          </div>

          {/* Plant Key Traits (Color, Season, Light, Care, Environment) */}
          <div className="flex flex-wrap gap-2 text-xs">
            {product.flowerColor && (
              <div className="bg-rose-50 text-rose-800 border border-rose-200 px-2.5 py-1 rounded-xl font-semibold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-500 inline-block" />
                <span>Blooms: {product.flowerColor}</span>
              </div>
            )}
            {product.floweringSeason && (
              <div className="bg-amber-50 text-amber-900 border border-amber-200 px-2.5 py-1 rounded-xl font-medium">
                <span>Season: {product.floweringSeason}</span>
              </div>
            )}
            {product.environment && (
              <div className="bg-stone-100 text-stone-700 px-2.5 py-1 rounded-xl font-medium">
                <span>{product.environment}</span>
              </div>
            )}
            {product.sunlightRequirement && (
              <div className="bg-stone-100 text-stone-700 px-2.5 py-1 rounded-xl font-medium">
                <span>☀️ {product.sunlightRequirement}</span>
              </div>
            )}
            {product.maintenanceLevel && (
              <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2.5 py-1 rounded-xl font-medium">
                <span>🌿 {product.maintenanceLevel} Care</span>
              </div>
            )}
          </div>

          {/* Short description */}
          <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
            {language === 'hi' && product.descriptionHi
              ? product.descriptionHi
              : language === 'mr' && product.descriptionMr
              ? product.descriptionMr
              : product.description}
          </p>

          {/* Stock Status & Quantity Selector */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-stone-700">Availability:</span>
              <span className="font-bold text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>In Stock ({product.stock} units in greenhouse)</span>
              </span>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center border border-stone-300 rounded-xl bg-white p-1">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-2 text-stone-600 hover:text-stone-900 rounded-lg hover:bg-stone-100"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="w-10 text-center font-bold text-sm text-stone-800">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="p-2 text-stone-600 hover:text-stone-900 rounded-lg hover:bg-stone-100"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2.5 flex-1">
                <button
                  onClick={handleAddToCart}
                  className="flex-1 flex items-center justify-center gap-2 py-3 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-emerald-50 hover:bg-emerald-100 text-[#154D34] border border-[#154D34]/30 transition-colors"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>{t('addToCart')}</span>
                </button>
                <button
                  onClick={handleBuyNow}
                  className="flex-1 flex items-center justify-center gap-2 py-3 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-[#154D34] hover:bg-[#0D3222] text-white shadow-md transition-colors"
                >
                  <Zap className="w-4 h-4 fill-amber-300 text-amber-300" />
                  <span>{t('buyNow')}</span>
                </button>
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className={`p-3 rounded-xl border transition-colors flex items-center justify-center shrink-0 ${
                    isLiked
                      ? 'bg-rose-50 border-rose-200 text-rose-600'
                      : 'bg-white border-stone-300 text-stone-600 hover:text-rose-600 hover:bg-rose-50'
                  }`}
                  title={isLiked ? 'Saved in Wishlist' : 'Save to Wishlist'}
                >
                  <Heart className={`w-5 h-5 ${isLiked ? 'fill-rose-600' : ''}`} />
                </button>
              </div>
            </div>
          </div>

          {/* Delivery & Pincode Checker Component */}
          <PincodeChecker />
        </div>
      </div>

      {/* Tabs Section: Complete Plant Care Guide | Specifications | Customer Reviews */}
      <div className="border-t border-stone-200 pt-10">
        <div className="flex border-b border-stone-200 gap-6 text-sm font-bold">
          <button
            onClick={() => setActiveTab('care')}
            className={`pb-3 border-b-2 transition-colors ${
              activeTab === 'care'
                ? 'border-[#154D34] text-[#154D34]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            {t('careGuideTitle')}
          </button>
          <button
            onClick={() => setActiveTab('specs')}
            className={`pb-3 border-b-2 transition-colors ${
              activeTab === 'specs'
                ? 'border-[#154D34] text-[#154D34]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Plant Specifications & Benefits
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`pb-3 border-b-2 transition-colors ${
              activeTab === 'reviews'
                ? 'border-[#154D34] text-[#154D34]'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            {t('customerReviewsTitle')} ({productReviews.length})
          </button>
        </div>

        {/* Tab 1: Plant Care Guide */}
        {activeTab === 'care' && product.careGuide && (
          <div className="pt-6 grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Sidebar Buttons */}
            <div className="space-y-1.5 md:col-span-1">
              {[
                { id: 'watering', label: t('wateringTab'), icon: Droplets },
                { id: 'sunlight', label: t('sunlightTab'), icon: Sun },
                { id: 'fertilizer', label: t('fertilizerTab'), icon: Sprout },
                { id: 'repotting', label: t('repottingTab'), icon: Sparkles },
                { id: 'pruning', label: t('pruningTab'), icon: CheckCircle2 },
                { id: 'problems', label: t('troubleshootingTab'), icon: AlertCircle },
              ].map((item) => {
                const Icon = item.icon;
                const isSelected = careSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCareSection(item.id as any)}
                    className={`w-full flex items-center gap-2.5 p-3 rounded-xl text-xs font-semibold text-left transition-colors ${
                      isSelected
                        ? 'bg-[#154D34] text-white shadow-xs'
                        : 'bg-stone-50 text-stone-700 hover:bg-stone-100'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Content Area */}
            <div className="md:col-span-3 bg-stone-50 p-6 rounded-2xl border border-stone-200 flex flex-col justify-center">
              <h4 className="text-sm font-bold uppercase tracking-wider text-[#154D34] mb-2">
                {careSection === 'watering' && 'Watering Schedule in Indian Climate'}
                {careSection === 'sunlight' && 'Optimal Light & Sun Exposure'}
                {careSection === 'fertilizer' && 'Organic Feed & Nutritional Cycle'}
                {careSection === 'repotting' && 'When & How to Repot'}
                {careSection === 'pruning' && 'Pruning for Bushy Growth'}
                {careSection === 'problems' && 'Common Problems & Organic Solutions'}
              </h4>
              <p className="text-xs sm:text-sm text-stone-700 leading-relaxed font-normal">
                {careSection === 'watering' && product.careGuide.watering}
                {careSection === 'sunlight' && product.careGuide.sunlight}
                {careSection === 'fertilizer' && product.careGuide.fertilizer}
                {careSection === 'repotting' && product.careGuide.repotting}
                {careSection === 'pruning' && product.careGuide.pruning}
                {careSection === 'problems' && product.careGuide.commonProblems}
              </p>
            </div>

            {/* AI Plant Doctor for this specific product */}
            <div className="md:col-span-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-[#154D34]">
                  <Bot className="w-5 h-5 text-emerald-700" />
                  <span className="font-bold text-sm">Ask Prakriti AI Doctor about {product.name}</span>
                </div>
                <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full">
                  Gemini 2.5 Botanical
                </span>
              </div>

              {/* Quick suggestion chips */}
              <div className="flex flex-wrap gap-2">
                {[
                  `Can I keep ${product.name} in an air-conditioned room?`,
                  `How often should I water ${product.name} during monsoons?`,
                  `Which organic fertilizer is best for ${product.name}?`,
                  `How much direct sunlight does ${product.name} need in Indian weather?`,
                ].map((chip, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setAiProductQuestion(chip);
                      handleAskProductAi(chip);
                    }}
                    className="text-[11px] bg-white hover:bg-emerald-100/50 text-stone-700 border border-emerald-200 px-2.5 py-1 rounded-full transition-colors"
                  >
                    "{chip}"
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={aiProductQuestion}
                  onChange={(e) => setAiProductQuestion(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAskProductAi();
                    }
                  }}
                  placeholder={`Ask anything specific about caring for ${product.name}...`}
                  className="flex-1 px-3 py-2 bg-white text-stone-800 placeholder:text-stone-400 text-xs rounded-xl border border-stone-200 focus:outline-none focus:border-emerald-600"
                />
                <button
                  type="button"
                  onClick={() => handleAskProductAi()}
                  disabled={aiProductLoading || !aiProductQuestion.trim()}
                  className="px-4 py-2 bg-[#154D34] hover:bg-[#0D3222] disabled:bg-stone-300 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed shrink-0"
                >
                  {aiProductLoading ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Thinking...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Ask AI</span>
                    </>
                  )}
                </button>
              </div>

              {aiProductAnswer && (
                <div className="p-4 bg-white rounded-xl border border-emerald-200 shadow-xs text-xs text-stone-800 space-y-2 animate-in fade-in">
                  <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                    <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      Botanical Advisory for {product.name}
                    </span>
                    <button
                      type="button"
                      onClick={() => setAiProductAnswer(null)}
                      className="text-[11px] text-stone-400 hover:text-stone-600"
                    >
                      Dismiss
                    </button>
                  </div>
                  <p className="whitespace-pre-line leading-relaxed text-stone-700">
                    {aiProductAnswer}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Plant Specifications */}
        {activeTab === 'specs' && product.specs && (
          <div className="pt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-stone-50 p-6 rounded-2xl border border-stone-200 space-y-3 text-xs">
              <h4 className="font-bold text-stone-900 text-sm mb-3">Botanical & Physical Specs</h4>
              <div className="grid grid-cols-2 gap-2 border-b border-stone-200 pb-2">
                <span className="text-stone-500">{t('plantHeight')}:</span>
                <span className="font-semibold text-stone-900">{product.plantHeight || product.specs.height}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 border-b border-stone-200 pb-2">
                <span className="text-stone-500">{t('potSize')}:</span>
                <span className="font-semibold text-stone-900">{product.specs.potSize}</span>
              </div>
              {product.flowerColor && (
                <div className="grid grid-cols-2 gap-2 border-b border-stone-200 pb-2">
                  <span className="text-stone-500">Flower Color:</span>
                  <span className="font-semibold text-rose-700 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-rose-500 inline-block" />
                    <span>{product.flowerColor}</span>
                  </span>
                </div>
              )}
              {product.floweringSeason && (
                <div className="grid grid-cols-2 gap-2 border-b border-stone-200 pb-2">
                  <span className="text-stone-500">Flowering Season:</span>
                  <span className="font-semibold text-amber-800">{product.floweringSeason}</span>
                </div>
              )}
              <div className="grid grid-cols-2 gap-2 border-b border-stone-200 pb-2">
                <span className="text-stone-500">{t('lightNeeded')}:</span>
                <span className="font-semibold text-stone-900">{product.specs.light}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 border-b border-stone-200 pb-2">
                <span className="text-stone-500">{t('soilType')}:</span>
                <span className="font-semibold text-stone-900">{product.soilType || product.specs.soil}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 border-b border-stone-200 pb-2">
                <span className="text-stone-500">Ideal Temperature:</span>
                <span className="font-semibold text-stone-900">{product.specs.temperature}</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <span className="text-stone-500">{t('suitableLocation')}:</span>
                <span className="font-semibold text-stone-900">{product.specs.location}</span>
              </div>
            </div>

            <div className="bg-stone-50 p-6 rounded-2xl border border-stone-200 space-y-4">
              <h4 className="font-bold text-stone-900 text-sm">Key Benefits & Suitability</h4>
              <div className="space-y-2">
                {product.specs.benefits.map((b, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-xs text-stone-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span className="font-medium">{b}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-stone-200 grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-white rounded-xl border border-stone-200">
                  <span className="text-stone-500 block mb-1">Pet Safety</span>
                  <span className={`font-bold ${product.specs.petFriendly ? 'text-emerald-700' : 'text-amber-700'}`}>
                    {product.specs.petFriendly ? '✓ 100% Pet Friendly' : '⚠️ Keep Away From Pets'}
                  </span>
                </div>
                <div className="p-3 bg-white rounded-xl border border-stone-200">
                  <span className="text-stone-500 block mb-1">Beginner Level</span>
                  <span className="font-bold text-stone-900">
                    {product.specs.beginnerFriendly ? '🌱 Great For Beginners' : '🌿 Intermediate Care'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Customer Reviews */}
        {activeTab === 'reviews' && (
          <div className="pt-6 space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-stone-50 p-6 rounded-2xl border border-stone-200">
              <div>
                <h3 className="font-bold text-stone-900 text-base">Customer Feedback</h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Have you bought this plant? Share your experience with other plant parents!
                </p>
              </div>
              <button
                onClick={() => setReviewModalOpen(true)}
                className="px-5 py-2.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-full text-xs font-semibold shadow-xs"
              >
                {t('writeReview')}
              </button>
            </div>

            {/* Reviews List */}
            <div className="space-y-4">
              {productReviews.length > 0 ? (
                productReviews.map((rev) => (
                  <div
                    key={rev.id}
                    className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-stone-900">{rev.userName}</span>
                        {rev.city && <span className="text-xs text-stone-400">({rev.city})</span>}
                        {rev.verifiedPurchase && (
                          <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-full">
                            Verified Buyer
                          </span>
                        )}
                      </div>
                      <span className="text-xs text-stone-400">{rev.date}</span>
                    </div>

                    <div className="flex items-center gap-1 text-amber-400">
                      {[...Array(rev.rating)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      ))}
                    </div>

                    <h5 className="font-bold text-xs text-stone-900">{rev.title}</h5>
                    <p className="text-xs text-stone-600 leading-relaxed">{rev.comment}</p>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center bg-stone-50 rounded-2xl border border-stone-200 text-xs text-stone-500">
                  Be the first plant parent to review {product.name}!
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Similar & Complementary Plants Section */}
      {similarPlants.length > 0 && (
        <div className="pt-10 border-t border-stone-200 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#154D34]">
                Complementary Varieties
              </span>
              <h3 className="font-serif text-xl sm:text-2xl font-bold text-stone-900 mt-0.5">
                Similar Flower & Garden Plants
              </h3>
            </div>
            <button
              onClick={() => {
                navigateTo('catalog');
              }}
              className="text-xs font-bold text-[#154D34] hover:underline"
            >
              View All 50+ Flower Plants →
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {similarPlants.map((plant) => (
              <ProductCard key={plant.id} product={plant} />
            ))}
          </div>
        </div>
      )}

      {/* Review Submission Modal */}
      {reviewModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-stone-200">
            <h3 className="font-serif font-bold text-lg text-stone-900 mb-1">
              Write a Review for {product.name}
            </h3>
            <p className="text-xs text-stone-500 mb-4">
              Your honest feedback helps fellow gardeners choose the best plants!
            </p>

            {reviewSuccess ? (
              <div className="p-6 bg-emerald-50 rounded-2xl text-center text-emerald-800 text-sm font-bold flex flex-col items-center gap-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-600" />
                <span>Thank you! Your review has been submitted.</span>
              </div>
            ) : (
              <form onSubmit={handleReviewSubmit} className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Rating</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setNewReviewRating(star)}
                        className="p-1"
                      >
                        <Star
                          className={`w-6 h-6 ${
                            star <= newReviewRating
                              ? 'fill-amber-400 text-amber-400'
                              : 'text-stone-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Your Name</label>
                    <input
                      type="text"
                      required
                      value={newReviewName}
                      onChange={(e) => setNewReviewName(e.target.value)}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Your City / State</label>
                    <input
                      type="text"
                      value={newReviewCity}
                      onChange={(e) => setNewReviewCity(e.target.value)}
                      placeholder="e.g. Pune, MH"
                      className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Review Headline</label>
                  <input
                    type="text"
                    required
                    value={newReviewTitle}
                    onChange={(e) => setNewReviewTitle(e.target.value)}
                    placeholder="e.g. Arrived fresh & leafy!"
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Detailed Feedback</label>
                  <textarea
                    rows={3}
                    required
                    value={newReviewComment}
                    onChange={(e) => setNewReviewComment(e.target.value)}
                    placeholder="Tell us about the packaging, plant health, fragrance or ease of care..."
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-3">
                  <button
                    type="button"
                    onClick={() => setReviewModalOpen(false)}
                    className="px-4 py-2 text-stone-600 font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-[#154D34] text-white rounded-xl font-bold"
                  >
                    {t('submitReview')}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
