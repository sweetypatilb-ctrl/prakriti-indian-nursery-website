import React, { useState, useMemo, useEffect } from 'react';
import {
  Filter,
  SlidersHorizontal,
  X,
  Star,
  Search,
  Check,
  ChevronDown,
  Sprout,
  Sun,
  Droplets,
  Dog,
  Sparkles,
  Compass,
  HeartHandshake,
  ShieldCheck,
  RefreshCw,
  Tag,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ProductCard } from '../components/ProductCard';
import {
  searchAndFilterPlants,
  detectSearchIntent,
  POPULAR_SEARCH_CHIPS,
  PlantFilterOptions,
} from '../lib/plantSearch';

// Quick filter pills for instant Indian nursery browsing
const QUICK_INTENT_PILLS = [
  { id: 'all', label: 'All Plants', query: '' },
  { id: 'flower', label: '🌹 Flower Plants', query: 'Flower Plant' },
  { id: 'decor', label: '✨ Decoration Plants', query: 'Decoration Plant' },
  { id: 'indoor', label: '🌿 Indoor Plants', query: 'Indoor Plant' },
  { id: 'outdoor', label: '☀️ Outdoor Plants', query: 'Outdoor Plant' },
  { id: 'medicinal', label: '🌱 Medicinal & Tulsi', query: 'Medicinal Plant' },
  { id: 'fruit', label: '🍋 Fruit Plants', query: 'Fruit Plant' },
  { id: 'vegetable', label: '🍅 Vegetable Plants', query: 'Vegetable' },
  { id: 'herbal', label: '🌿 Herbal Plants', query: 'Herbal Plant' },
  { id: 'palms', label: '🌴 Palms', query: 'Palm' },
  { id: 'bonsai', label: '🌳 Bonsai Plants', query: 'Bonsai' },
  { id: 'climbers', label: '🌿 Climbers & Creepers', query: 'Climber' },
  { id: 'trees', label: '🌲 Trees', query: 'Tree' },
  { id: 'cactus', label: '🌵 Cactus & Succulents', query: 'Cactus' },
  { id: 'purifying', label: '🍃 Air Purifying', query: 'Air Purifying Plant' },
  { id: 'low-maint', label: '🪴 Low Maintenance', query: 'Low Maintenance' },
  { id: 'balcony', label: '🏡 Balcony Plants', query: 'Balcony Plant' },
  { id: 'pooja', label: '🙏 Pooja & Sacred', query: 'Pooja' },
];

export const CatalogView: React.FC = () => {
  const {
    products,
    categories,
    selectedCategorySlug,
    searchQuery,
    setSearchQuery,
    language,
    t,
  } = useApp();

  // Filters State
  const [selectedCategory, setSelectedCategory] = useState<string>(selectedCategorySlug || 'all');
  const [priceMax, setPriceMax] = useState<number>(1500);
  const [minRating, setMinRating] = useState<number>(0);
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [selectedEnvironment, setSelectedEnvironment] = useState<'all' | 'Indoor' | 'Outdoor' | 'Both'>('all');
  const [selectedLight, setSelectedLight] = useState<string>('all');
  const [selectedWater, setSelectedWater] = useState<string>('all');
  const [selectedMaintenance, setSelectedMaintenance] = useState<string>('all');
  const [selectedSuitableFor, setSelectedSuitableFor] = useState<string>('all');
  const [selectedFlowering, setSelectedFlowering] = useState<'all' | 'Flowering' | 'Non-flowering'>('all');
  const [selectedColor, setSelectedColor] = useState<string>('all');
  const [selectedSeason, setSelectedSeason] = useState<string>('all');
  const [petFriendlyOnly, setPetFriendlyOnly] = useState<boolean>(false);
  const [beginnerFriendlyOnly, setBeginnerFriendlyOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<string>('popular');
  const [mobileFilterOpen, setMobileFilterOpen] = useState<boolean>(false);

  // Sync selectedCategory with selectedCategorySlug when updated from navigation
  useEffect(() => {
    if (selectedCategorySlug) {
      setSelectedCategory(selectedCategorySlug);
    }
  }, [selectedCategorySlug]);

  // Build filter options object
  const filterOptions: PlantFilterOptions = useMemo(() => {
    return {
      category: selectedCategory !== 'all' ? selectedCategory : undefined,
      priceRange: [0, priceMax],
      environment: selectedEnvironment,
      sunlight: selectedLight !== 'all' ? selectedLight : undefined,
      water: selectedWater !== 'all' ? selectedWater : undefined,
      maintenance: selectedMaintenance !== 'all' ? selectedMaintenance : undefined,
      flowering: selectedFlowering,
      color: selectedColor !== 'all' ? selectedColor : undefined,
      season: selectedSeason !== 'all' ? selectedSeason : undefined,
      inStockOnly: inStockOnly,
      suitableFor: selectedSuitableFor !== 'all' ? selectedSuitableFor : undefined,
    };
  }, [
    selectedCategory,
    priceMax,
    selectedEnvironment,
    selectedLight,
    selectedWater,
    selectedMaintenance,
    selectedFlowering,
    selectedColor,
    selectedSeason,
    inStockOnly,
    selectedSuitableFor,
  ]);

  // Execute smart search & filtering
  const searchResult = useMemo(() => {
    return searchAndFilterPlants(products, searchQuery, filterOptions);
  }, [products, searchQuery, filterOptions]);

  // Apply secondary post-filters: rating, petFriendly, beginnerFriendly
  const filteredProducts = useMemo(() => {
    return searchResult.products.filter((product) => {
      if (minRating > 0 && product.rating < minRating) return false;
      if (petFriendlyOnly && !product.specs?.petFriendly) return false;
      if (beginnerFriendlyOnly && !product.specs?.beginnerFriendly) return false;
      return true;
    });
  }, [searchResult.products, minRating, petFriendlyOnly, beginnerFriendlyOnly]);

  // Sort products
  const sortedProducts = useMemo(() => {
    const list = [...filteredProducts];
    if (sortBy === 'price-low') {
      return list.sort((a, b) => a.price - b.price);
    }
    if (sortBy === 'price-high') {
      return list.sort((a, b) => b.price - a.price);
    }
    if (sortBy === 'rating') {
      return list.sort((a, b) => b.rating - a.rating);
    }
    if (sortBy === 'newest') {
      return list.sort((a, b) => (b.isNewArrival ? 1 : 0) - (a.isNewArrival ? 1 : 0));
    }
    // popular default (reviewCount * rating)
    return list.sort((a, b) => (b.reviewCount * b.rating) - (a.reviewCount * a.rating));
  }, [filteredProducts, sortBy]);

  // Reset all filters
  const handleResetFilters = () => {
    setSelectedCategory('all');
    setPriceMax(1500);
    setMinRating(0);
    setInStockOnly(false);
    setSelectedEnvironment('all');
    setSelectedLight('all');
    setSelectedWater('all');
    setSelectedMaintenance('all');
    setSelectedSuitableFor('all');
    setSelectedFlowering('all');
    setSelectedColor('all');
    setSelectedSeason('all');
    setPetFriendlyOnly(false);
    setBeginnerFriendlyOnly(false);
    setSearchQuery('');
  };

  // Active filters count for badge
  const activeFiltersCount = [
    selectedCategory !== 'all',
    priceMax < 1500,
    minRating > 0,
    inStockOnly,
    selectedEnvironment !== 'all',
    selectedLight !== 'all',
    selectedWater !== 'all',
    selectedMaintenance !== 'all',
    selectedSuitableFor !== 'all',
    selectedFlowering !== 'all',
    selectedColor !== 'all',
    selectedSeason !== 'all',
    petFriendlyOnly,
    beginnerFriendlyOnly,
    Boolean(searchQuery.trim()),
  ].filter(Boolean).length;

  const currentCategoryObj = categories.find((c) => c.slug === selectedCategory);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Quick Intent Pills Bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-[#154D34]" />
            <span>Smart Plant Finder</span>
          </span>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1"
            >
              <X className="w-3.5 h-3.5" />
              <span>Clear Search</span>
            </button>
          )}
        </div>
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
          {QUICK_INTENT_PILLS.map((pill) => {
            const isActive = pill.query
              ? searchQuery.toLowerCase().includes(pill.query.toLowerCase())
              : !searchQuery;
            return (
              <button
                key={pill.id}
                type="button"
                onClick={() => {
                  setSearchQuery(pill.query);
                  if (pill.id === 'all') {
                    setSelectedCategory('all');
                  }
                }}
                className={`whitespace-nowrap px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all shrink-0 ${
                  isActive
                    ? 'bg-[#154D34] text-white shadow-sm ring-2 ring-[#154D34]/30'
                    : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200 shadow-2xs'
                }`}
              >
                {pill.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Smart Intent / Active Search Banner */}
      {(searchResult.matchedIntent || searchQuery.trim()) && (
        <div className="mb-6 p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-900 via-[#154D34] to-[#1E6043] text-white shadow-md relative overflow-hidden">
          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-700/60 text-emerald-100 text-[11px] font-bold uppercase tracking-wider">
                  Smart Nursery Search
                </span>
                {searchResult.matchedIntent && (
                  <span className="text-xs text-amber-300 font-semibold">
                    Intent: {searchResult.matchedIntent.label}
                  </span>
                )}
              </div>
              <h2 className="font-serif text-lg sm:text-xl font-bold flex items-center gap-2">
                <span>
                  {searchResult.matchedIntent
                    ? language === 'hi'
                      ? searchResult.matchedIntent.labelHi
                      : language === 'mr'
                      ? searchResult.matchedIntent.labelMr
                      : searchResult.matchedIntent.label
                    : `Search Results for "${searchQuery}"`}
                </span>
                <span className="text-xs font-normal text-emerald-200 bg-white/10 px-2 py-0.5 rounded-full">
                  {sortedProducts.length} plants
                </span>
              </h2>
              <p className="text-xs text-emerald-100/90 max-w-2xl leading-relaxed">
                {searchResult.matchedIntent?.description ||
                  `Hand-selected Indian nursery varieties matching your botanical query.`}
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setSearchQuery('')}
                className="px-3.5 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-semibold transition-colors flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Show All Plants</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-stone-200">
        <div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
            {searchQuery
              ? `Results for "${searchQuery}"`
              : selectedCategory === 'all'
              ? 'All Indian Plants & Nursery Supplies'
              : currentCategoryObj?.name || 'Plant Catalogue'}
          </h1>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Showing {sortedProducts.length} healthy nursery-grown plants dispatched across India in safe 5-layer packaging
          </p>
        </div>

        {/* Sort & Mobile Filter Toggle */}
        <div className="flex items-center gap-3 self-end md:self-auto">
          <button
            onClick={() => setMobileFilterOpen(true)}
            className="lg:hidden flex items-center gap-1.5 px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-xl border border-stone-300 relative"
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span>{t('filterBy')}</span>
            {activeFiltersCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-[#154D34] text-white text-[10px] flex items-center justify-center font-bold">
                {activeFiltersCount}
              </span>
            )}
          </button>

          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-500 font-medium hidden sm:inline">
              {t('sortBy')}:
            </span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="text-xs sm:text-sm py-2 px-3 bg-white border border-stone-300 rounded-xl focus:outline-none focus:border-[#154D34] font-medium text-stone-800 shadow-2xs"
            >
              <option value="popular">{t('sortPopular')}</option>
              <option value="newest">{t('sortNewest')}</option>
              <option value="price-low">{t('sortPriceLowHigh')}</option>
              <option value="price-high">{t('sortPriceHighLow')}</option>
              <option value="rating">{t('sortRating')}</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Content Layout: Sidebar + Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 pt-8">
        {/* Left Sidebar Filter (Desktop) */}
        <aside className="hidden lg:block space-y-6">
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-5 sticky top-24">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <span className="text-sm font-bold text-stone-900 flex items-center gap-1.5">
                <Filter className="w-4 h-4 text-[#154D34]" />
                <span>Filter Indian Plants</span>
                {activeFiltersCount > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full bg-emerald-100 text-[#154D34] text-[10px] font-bold">
                    {activeFiltersCount}
                  </span>
                )}
              </span>
              <button
                onClick={handleResetFilters}
                className="text-xs text-[#154D34] hover:underline font-semibold"
              >
                {t('clearAll')}
              </button>
            </div>

            {/* Category Select */}
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2">
                Categories
              </label>
              <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
                <button
                  onClick={() => setSelectedCategory('all')}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center justify-between ${
                    selectedCategory === 'all'
                      ? 'bg-emerald-50 text-[#154D34] font-bold'
                      : 'text-stone-600 hover:bg-stone-50'
                  }`}
                >
                  <span>All Categories</span>
                  <span>({products.length})</span>
                </button>
                {categories.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setSelectedCategory(c.slug)}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center justify-between ${
                      selectedCategory === c.slug
                        ? 'bg-emerald-50 text-[#154D34] font-bold'
                        : 'text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <span className="truncate">{c.name}</span>
                    <span className="text-stone-400">({c.count})</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Environment (Indoor / Outdoor / Both) */}
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2">
                Growing Environment
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {(['all', 'Indoor', 'Outdoor', 'Both'] as const).map((env) => (
                  <button
                    key={env}
                    type="button"
                    onClick={() => setSelectedEnvironment(env)}
                    className={`py-1.5 px-2 rounded-lg text-xs font-semibold text-center transition-colors ${
                      selectedEnvironment === env
                        ? 'bg-[#154D34] text-white'
                        : 'bg-stone-100 hover:bg-stone-200/80 text-stone-700'
                    }`}
                  >
                    {env === 'all' ? 'All Environments' : env}
                  </button>
                ))}
              </div>
            </div>

            {/* Sunlight Filter */}
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2 flex items-center gap-1">
                <Sun className="w-3.5 h-3.5 text-amber-500" />
                <span>Sunlight Requirement</span>
              </label>
              <select
                value={selectedLight}
                onChange={(e) => setSelectedLight(e.target.value)}
                className="w-full p-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-700 focus:outline-none focus:border-[#154D34]"
              >
                <option value="all">Any Sunlight Requirement</option>
                <option value="Full Sun">Full Sun (6+ hours direct light)</option>
                <option value="Partial Shade">Partial Shade (Morning sun / balcony)</option>
                <option value="Bright Indirect">Bright Indirect (Living room/office)</option>
                <option value="Low Light">Low Light (Bedroom/shaded desk)</option>
              </select>
            </div>

            {/* Water Needs */}
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2 flex items-center gap-1">
                <Droplets className="w-3.5 h-3.5 text-sky-500" />
                <span>Watering Needs</span>
              </label>
              <select
                value={selectedWater}
                onChange={(e) => setSelectedWater(e.target.value)}
                className="w-full p-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-700 focus:outline-none focus:border-[#154D34]"
              >
                <option value="all">Any Watering Frequency</option>
                <option value="Daily">Daily Watering (Summer/outdoors)</option>
                <option value="Moderate">Moderate (2-3 times weekly)</option>
                <option value="Low">Low (Once every 7-10 days)</option>
              </select>
            </div>

            {/* Maintenance Level */}
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2">
                Maintenance Level
              </label>
              <div className="grid grid-cols-3 gap-1">
                {['all', 'Low', 'Medium', 'High'].map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setSelectedMaintenance(lvl)}
                    className={`py-1 text-xs font-semibold rounded-lg text-center ${
                      selectedMaintenance === lvl
                        ? 'bg-[#154D34] text-white'
                        : 'bg-stone-100 hover:bg-stone-200 text-stone-600'
                    }`}
                  >
                    {lvl === 'all' ? 'Any' : lvl}
                  </button>
                ))}
              </div>
            </div>

            {/* Suitable For (Home, Office, Garden, Balcony, Pooja, Landscaping, Decoration) */}
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2">
                Suitable For
              </label>
              <select
                value={selectedSuitableFor}
                onChange={(e) => setSelectedSuitableFor(e.target.value)}
                className="w-full p-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-700 focus:outline-none focus:border-[#154D34]"
              >
                <option value="all">Any Space / Usage</option>
                <option value="Home">Home & Living Rooms</option>
                <option value="Balcony">Balcony & Verandas</option>
                <option value="Office">Office & Work Desks</option>
                <option value="Garden">Outdoor Gardens</option>
                <option value="Pooja">Pooja Mandir & Sacred</option>
                <option value="Decoration">Decoration & Aesthetics</option>
                <option value="Landscaping">Landscaping & Avenues</option>
              </select>
            </div>

            {/* Flowering Type */}
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2">
                Flowering Type
              </label>
              <div className="grid grid-cols-3 gap-1">
                {(['all', 'Flowering', 'Non-flowering'] as const).map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setSelectedFlowering(type)}
                    className={`py-1 px-1.5 text-[11px] font-semibold rounded-lg text-center truncate ${
                      selectedFlowering === type
                        ? 'bg-[#154D34] text-white'
                        : 'bg-stone-100 hover:bg-stone-200 text-stone-600'
                    }`}
                  >
                    {type === 'all' ? 'All' : type === 'Flowering' ? 'Blooms' : 'Foliage'}
                  </button>
                ))}
              </div>
            </div>

            {/* Flower Color Filter */}
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2 flex items-center justify-between">
                <span>Flower Color</span>
                {selectedColor !== 'all' && (
                  <button
                    onClick={() => setSelectedColor('all')}
                    className="text-[10px] text-[#154D34] font-semibold hover:underline lowercase"
                  >
                    clear
                  </button>
                )}
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'all', label: 'All Colors', dot: 'bg-stone-300' },
                  { id: 'Red', label: 'Red', dot: 'bg-rose-500' },
                  { id: 'Pink', label: 'Pink', dot: 'bg-pink-400' },
                  { id: 'White', label: 'White', dot: 'bg-stone-100 border border-stone-300' },
                  { id: 'Yellow', label: 'Yellow', dot: 'bg-amber-400' },
                  { id: 'Orange', label: 'Orange', dot: 'bg-orange-500' },
                  { id: 'Purple', label: 'Purple', dot: 'bg-purple-500' },
                  { id: 'Blue', label: 'Blue', dot: 'bg-sky-500' },
                  { id: 'Multicolored', label: 'Multi', dot: 'bg-gradient-to-r from-red-400 via-yellow-400 to-blue-400' },
                ].map((col) => (
                  <button
                    key={col.id}
                    type="button"
                    onClick={() => setSelectedColor(selectedColor === col.id ? 'all' : col.id)}
                    className={`py-1.5 px-2 text-[11px] font-semibold rounded-lg text-left flex items-center gap-1.5 transition-colors ${
                      selectedColor === col.id
                        ? 'bg-[#154D34] text-white shadow-2xs'
                        : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200'
                    }`}
                  >
                    <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${col.dot}`} />
                    <span className="truncate">{col.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Blooming Season Filter */}
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2 flex items-center justify-between">
                <span>Flowering Season</span>
                {selectedSeason !== 'all' && (
                  <button
                    onClick={() => setSelectedSeason('all')}
                    className="text-[10px] text-[#154D34] font-semibold hover:underline lowercase"
                  >
                    clear
                  </button>
                )}
              </label>
              <div className="space-y-1">
                {[
                  { id: 'all', label: 'Any Season' },
                  { id: 'Year-round', label: '☀️ All Season (Year-round)' },
                  { id: 'Summer', label: '🌞 Summer Blooms (March-June)' },
                  { id: 'Monsoon', label: '🌧️ Monsoon Blooms (July-Oct)' },
                  { id: 'Winter', label: '❄️ Winter Blooms (Nov-Feb)' },
                ].map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSelectedSeason(selectedSeason === s.id ? 'all' : s.id)}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center justify-between ${
                      selectedSeason === s.id
                        ? 'bg-emerald-50 text-[#154D34] font-bold border border-emerald-300'
                        : 'text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <span>{s.label}</span>
                    {selectedSeason === s.id && <Check className="w-3.5 h-3.5 text-[#154D34]" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Max Slider */}
            <div>
              <div className="flex justify-between text-xs font-bold text-stone-700 mb-1">
                <span className="uppercase tracking-wider">Max Price</span>
                <span className="text-[#154D34]">₹{priceMax}</span>
              </div>
              <input
                type="range"
                min={150}
                max={1500}
                step={50}
                value={priceMax}
                onChange={(e) => setPriceMax(Number(e.target.value))}
                className="w-full accent-[#154D34] cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-stone-400 mt-1">
                <span>₹150</span>
                <span>₹1,500</span>
              </div>
            </div>

            {/* Rating Filter */}
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2">
                Customer Rating
              </label>
              <div className="space-y-1">
                {[4.5, 4.0, 3.5].map((stars) => (
                  <button
                    key={stars}
                    onClick={() => setMinRating(minRating === stars ? 0 : stars)}
                    className={`w-full flex items-center justify-between p-1.5 rounded-lg text-xs transition-colors ${
                      minRating === stars
                        ? 'bg-amber-50 text-amber-900 font-bold border border-amber-300'
                        : 'text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <div className="flex items-center gap-1 text-amber-500">
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                      <span>{stars} Stars & Up</span>
                    </div>
                    {minRating === stars && <Check className="w-3.5 h-3.5 text-amber-700" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Toggles */}
            <div className="pt-2 border-t border-stone-100 space-y-2">
              <label className="flex items-center gap-2.5 text-xs text-stone-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={inStockOnly}
                  onChange={(e) => setInStockOnly(e.target.checked)}
                  className="rounded text-[#154D34] focus:ring-[#154D34] accent-[#154D34]"
                />
                <span className="font-medium">In-Stock Live Plants Only</span>
              </label>

              <label className="flex items-center gap-2.5 text-xs text-stone-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={petFriendlyOnly}
                  onChange={(e) => setPetFriendlyOnly(e.target.checked)}
                  className="rounded text-[#154D34] focus:ring-[#154D34] accent-[#154D34]"
                />
                <div className="flex items-center gap-1.5">
                  <Dog className="w-3.5 h-3.5 text-stone-400" />
                  <span>Pet Friendly (Non-toxic)</span>
                </div>
              </label>

              <label className="flex items-center gap-2.5 text-xs text-stone-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={beginnerFriendlyOnly}
                  onChange={(e) => setBeginnerFriendlyOnly(e.target.checked)}
                  className="rounded text-[#154D34] focus:ring-[#154D34] accent-[#154D34]"
                />
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-stone-400" />
                  <span>Beginner Friendly (Easy care)</span>
                </div>
              </label>
            </div>
          </div>
        </aside>

        {/* Product Grid Area */}
        <div className="lg:col-span-3 space-y-6">
          {/* Dedicated In-Catalog Search & Quick Discovery Bar */}
          <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-stone-200 shadow-xs flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search flower plants, Mogra, Rose, Marigold, color, season, care..."
                className="w-full pl-10 pr-9 py-2 bg-stone-50 hover:bg-white focus:bg-white border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-800 placeholder:text-stone-400 focus:outline-none focus:border-[#154D34] focus:ring-1 focus:ring-[#154D34] transition-all"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 p-0.5"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 shrink-0 text-xs text-stone-500">
              <span className="font-semibold text-stone-800">{sortedProducts.length}</span>
              <span>plants found</span>
              {activeFiltersCount > 0 && (
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="ml-2 text-rose-600 hover:text-rose-700 font-semibold underline text-xs"
                >
                  Clear all
                </button>
              )}
            </div>
          </div>

          {/* Flower Plants Category Hero Showcase Banner */}
          {(selectedCategory === 'flower-plants' ||
            selectedCategory === 'Flower Plants' ||
            selectedCategory === 'cat-flower' ||
            searchQuery.toLowerCase().includes('flower')) && (
            <div className="rounded-3xl bg-gradient-to-br from-[#0F3A27] via-[#154D34] to-[#1E6B47] text-white p-6 sm:p-7 shadow-sm border border-emerald-800/40 relative overflow-hidden">
              <div className="relative z-10 space-y-4">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-emerald-500/25 border border-emerald-400/30 text-emerald-200 text-xs font-bold tracking-wider uppercase flex items-center gap-1.5">
                    <span>🌸</span>
                    <span>Indian Flower Plants (50+ Varieties)</span>
                  </span>
                  <span className="text-xs text-amber-300 font-medium">
                    Fragrant Mogra • Desi Gulab • Sacred Parijat • Balcony Creepers
                  </span>
                </div>

                <div>
                  <h2 className="font-serif text-2xl sm:text-3xl font-bold text-white tracking-tight">
                    Flowering Plants for Indian Homes & Gardens
                  </h2>
                  <p className="text-xs sm:text-sm text-emerald-100/90 mt-1 max-w-2xl leading-relaxed">
                    Explore 50 carefully cultivated flowering varieties suited for Indian balconies, verandas, courtyards, pooja mandirs, and landscaping. Supplied healthy in nursery pots with premium organic mix.
                  </p>
                </div>

                {/* Quick Variety Filter Shortcuts */}
                <div className="pt-2 border-t border-emerald-700/40 space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-semibold text-emerald-200">
                    <span>Popular Varieties:</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 text-xs">
                    {[
                      { name: '🌹 Desi Gulab (Rose)', q: 'Rose' },
                      { name: '🤍 Mogra / Bela', q: 'Mogra' },
                      { name: '🌺 Hibiscus (Gudhal)', q: 'Hibiscus' },
                      { name: '🌼 Genda (Marigold)', q: 'Marigold' },
                      { name: '🌸 Bougainvillea', q: 'Bougainvillea' },
                      { name: '✨ Parijat (Harsingar)', q: 'Parijat' },
                      { name: '💙 Aparajita (Neelkanth)', q: 'Aparajita' },
                      { name: '🌿 Madhumalti (Rangoon)', q: 'Madhumalti' },
                      { name: '🏵️ Guldaudi (Mum)', q: 'Chrysanthemum' },
                      { name: '💮 Champa (Plumeria)', q: 'Champa' },
                      { name: '🪷 Lotus & Lily', q: 'Lotus' },
                      { name: '🌾 Rajnigandha', q: 'Rajnigandha' },
                    ].map((item) => (
                      <button
                        key={item.name}
                        type="button"
                        onClick={() => {
                          setSearchQuery(item.q);
                        }}
                        className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                          searchQuery.toLowerCase().includes(item.q.toLowerCase())
                            ? 'bg-amber-400 text-stone-900 font-bold shadow-xs'
                            : 'bg-white/10 hover:bg-white/20 text-white border border-white/15'
                        }`}
                      >
                        {item.name}
                      </button>
                    ))}
                  </div>

                  {/* Quick Color Filter Pills */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-1 text-xs">
                    <span className="text-emerald-200 text-xs font-semibold mr-1">Filter by Color:</span>
                    {[
                      { color: 'all', label: 'All Colors' },
                      { color: 'Red', label: '🔴 Red' },
                      { color: 'Pink', label: '🌸 Pink' },
                      { color: 'White', label: '⚪ White' },
                      { color: 'Yellow', label: '🟡 Yellow' },
                      { color: 'Orange', label: '🟠 Orange' },
                      { color: 'Purple', label: '🟣 Purple' },
                      { color: 'Blue', label: '🔵 Blue' },
                    ].map((c) => (
                      <button
                        key={c.color}
                        type="button"
                        onClick={() => setSelectedColor(selectedColor === c.color ? 'all' : c.color)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                          selectedColor === c.color
                            ? 'bg-white text-[#154D34] font-bold shadow-xs'
                            : 'bg-white/10 hover:bg-white/20 text-emerald-100 border border-white/10'
                        }`}
                      >
                        {c.label}
                      </button>
                    ))}
                  </div>

                  {/* Quick Season Filter Pills */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-1 text-xs">
                    <span className="text-emerald-200 text-xs font-semibold mr-1">Blooming Season:</span>
                    {[
                      { season: 'all', label: 'All Seasons' },
                      { season: 'Year-round', label: '☀️ Year-round Bloomer' },
                      { season: 'Summer', label: '🌞 Summer Blooms' },
                      { season: 'Winter', label: '❄️ Winter Annuals' },
                      { season: 'Monsoon', label: '🌧️ Monsoon Blooms' },
                    ].map((s) => (
                      <button
                        key={s.season}
                        type="button"
                        onClick={() => setSelectedSeason(selectedSeason === s.season ? 'all' : s.season)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                          selectedSeason === s.season
                            ? 'bg-amber-400 text-stone-900 font-bold shadow-xs'
                            : 'bg-white/10 hover:bg-white/20 text-emerald-100 border border-white/10'
                        }`}
                      >
                        {s.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Active Filter Chips Bar (if any filter is selected) */}
          {(selectedColor !== 'all' ||
            selectedSeason !== 'all' ||
            selectedEnvironment !== 'all' ||
            selectedLight !== 'all' ||
            selectedWater !== 'all' ||
            selectedSuitableFor !== 'all') && (
            <div className="flex items-center gap-2 flex-wrap text-xs">
              <span className="text-stone-400 font-medium">Applied:</span>
              {selectedColor !== 'all' && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 border border-rose-200 font-semibold">
                  <span>Color: {selectedColor}</span>
                  <button onClick={() => setSelectedColor('all')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {selectedSeason !== 'all' && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 font-semibold">
                  <span>Season: {selectedSeason}</span>
                  <button onClick={() => setSelectedSeason('all')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {selectedEnvironment !== 'all' && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-stone-100 text-stone-700 border border-stone-200 font-semibold">
                  <span>Environment: {selectedEnvironment}</span>
                  <button onClick={() => setSelectedEnvironment('all')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {selectedLight !== 'all' && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-stone-100 text-stone-700 border border-stone-200 font-semibold">
                  <span>Light: {selectedLight}</span>
                  <button onClick={() => setSelectedLight('all')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {selectedWater !== 'all' && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-stone-100 text-stone-700 border border-stone-200 font-semibold">
                  <span>Water: {selectedWater}</span>
                  <button onClick={() => setSelectedWater('all')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {selectedSuitableFor !== 'all' && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-stone-100 text-stone-700 border border-stone-200 font-semibold">
                  <span>Suitable: {selectedSuitableFor}</span>
                  <button onClick={() => setSelectedSuitableFor('all')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
            </div>
          )}

          {searchResult.isFallback && (
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs">
              <p className="font-bold">
                No exact plant matches for "{searchQuery}".
              </p>
              <p className="mt-0.5 text-amber-800">
                Our horticulturists have curated these popular, resilient Indian plants for you below. You can also try searching "Flower Plant", "Indoor Plant", "Medicinal Plant", or "Rose".
              </p>
            </div>
          )}

          {sortedProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {sortedProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-3xl p-12 text-center border border-stone-200 shadow-2xs">
              <div className="w-16 h-16 rounded-full bg-emerald-50 text-[#154D34] mx-auto flex items-center justify-center mb-4">
                <Sprout className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="text-lg font-bold text-stone-900">No matching plants found</h3>
              <p className="text-xs sm:text-sm text-stone-500 max-w-sm mx-auto mt-1 mb-6">
                Try adjusting or resetting your filters to discover more healthy nursery plants.
              </p>
              <button
                onClick={handleResetFilters}
                className="px-6 py-2.5 bg-[#154D34] text-white rounded-full text-xs font-semibold hover:bg-[#0D3222] transition-colors shadow-xs"
              >
                Reset All Filters
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Filter Drawer Modal */}
      {mobileFilterOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            onClick={() => setMobileFilterOpen(false)}
          />
          <div className="relative w-4/5 max-w-sm bg-white h-full shadow-2xl flex flex-col z-10 p-5 overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-stone-200">
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-[#154D34]" />
                <span className="text-base font-bold text-stone-900">{t('filterBy')}</span>
              </div>
              <button onClick={() => setMobileFilterOpen(false)} className="p-1 text-stone-500">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-4 py-4 flex-1">
              {/* Category */}
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                  Category
                </label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full p-2 bg-stone-100 rounded-xl text-xs"
                >
                  <option value="all">All Categories</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.slug}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Environment */}
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                  Growing Environment
                </label>
                <select
                  value={selectedEnvironment}
                  onChange={(e) => setSelectedEnvironment(e.target.value as any)}
                  className="w-full p-2 bg-stone-100 rounded-xl text-xs"
                >
                  <option value="all">All Environments</option>
                  <option value="Indoor">Indoor Only</option>
                  <option value="Outdoor">Outdoor Only</option>
                  <option value="Both">Both (Indoor & Outdoor)</option>
                </select>
              </div>

              {/* Sunlight */}
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                  Sunlight Requirement
                </label>
                <select
                  value={selectedLight}
                  onChange={(e) => setSelectedLight(e.target.value)}
                  className="w-full p-2 bg-stone-100 rounded-xl text-xs"
                >
                  <option value="all">Any Sunlight</option>
                  <option value="Full Sun">Full Sun (6+ hrs)</option>
                  <option value="Partial Shade">Partial Shade</option>
                  <option value="Bright Indirect">Bright Indirect Light</option>
                  <option value="Low Light">Low Light</option>
                </select>
              </div>

              {/* Watering */}
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                  Watering Needs
                </label>
                <select
                  value={selectedWater}
                  onChange={(e) => setSelectedWater(e.target.value)}
                  className="w-full p-2 bg-stone-100 rounded-xl text-xs"
                >
                  <option value="all">Any Watering</option>
                  <option value="Daily">Daily</option>
                  <option value="Moderate">Moderate (Twice weekly)</option>
                  <option value="Low">Low (Once every 7-10 days)</option>
                </select>
              </div>

              {/* Suitable For */}
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                  Suitable For
                </label>
                <select
                  value={selectedSuitableFor}
                  onChange={(e) => setSelectedSuitableFor(e.target.value)}
                  className="w-full p-2 bg-stone-100 rounded-xl text-xs"
                >
                  <option value="all">Any Space</option>
                  <option value="Home">Home & Living Rooms</option>
                  <option value="Balcony">Balcony</option>
                  <option value="Office">Office & Desk</option>
                  <option value="Garden">Garden & Lawn</option>
                  <option value="Pooja">Pooja Mandir</option>
                  <option value="Decoration">Decoration</option>
                  <option value="Landscaping">Landscaping</option>
                </select>
              </div>

              {/* Flower Color */}
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                  Flower Color
                </label>
                <select
                  value={selectedColor}
                  onChange={(e) => setSelectedColor(e.target.value)}
                  className="w-full p-2 bg-stone-100 rounded-xl text-xs"
                >
                  <option value="all">All Flower Colors</option>
                  <option value="Red">Red</option>
                  <option value="Pink">Pink</option>
                  <option value="White">White</option>
                  <option value="Yellow">Yellow</option>
                  <option value="Orange">Orange</option>
                  <option value="Purple">Purple</option>
                  <option value="Blue">Blue</option>
                  <option value="Multicolored">Multicolored</option>
                </select>
              </div>

              {/* Blooming Season */}
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                  Blooming Season
                </label>
                <select
                  value={selectedSeason}
                  onChange={(e) => setSelectedSeason(e.target.value)}
                  className="w-full p-2 bg-stone-100 rounded-xl text-xs"
                >
                  <option value="all">Any Blooming Season</option>
                  <option value="Year-round">All Season (Year-round)</option>
                  <option value="Summer">Summer Blooms</option>
                  <option value="Monsoon">Monsoon Blooms</option>
                  <option value="Winter">Winter Blooms</option>
                </select>
              </div>

              {/* Price Max */}
              <div>
                <div className="flex justify-between text-xs font-bold text-stone-700 mb-1">
                  <span>Max Price</span>
                  <span className="text-[#154D34]">₹{priceMax}</span>
                </div>
                <input
                  type="range"
                  min={150}
                  max={1500}
                  step={50}
                  value={priceMax}
                  onChange={(e) => setPriceMax(Number(e.target.value))}
                  className="w-full accent-[#154D34]"
                />
              </div>

              {/* Toggles */}
              <div className="space-y-2 pt-2 border-t border-stone-200">
                <label className="flex items-center gap-2 text-xs font-medium text-stone-700">
                  <input
                    type="checkbox"
                    checked={inStockOnly}
                    onChange={(e) => setInStockOnly(e.target.checked)}
                    className="rounded text-[#154D34]"
                  />
                  <span>In-Stock Live Plants Only</span>
                </label>
                <label className="flex items-center gap-2 text-xs font-medium text-stone-700">
                  <input
                    type="checkbox"
                    checked={petFriendlyOnly}
                    onChange={(e) => setPetFriendlyOnly(e.target.checked)}
                    className="rounded text-[#154D34]"
                  />
                  <span>Pet Friendly (Non-toxic)</span>
                </label>
                <label className="flex items-center gap-2 text-xs font-medium text-stone-700">
                  <input
                    type="checkbox"
                    checked={beginnerFriendlyOnly}
                    onChange={(e) => setBeginnerFriendlyOnly(e.target.checked)}
                    className="rounded text-[#154D34]"
                  />
                  <span>Beginner Friendly</span>
                </label>
              </div>
            </div>

            <div className="pt-4 border-t border-stone-200 grid grid-cols-2 gap-2">
              <button
                onClick={handleResetFilters}
                className="py-2.5 rounded-xl border border-stone-300 text-xs font-semibold text-stone-700"
              >
                Reset
              </button>
              <button
                onClick={() => setMobileFilterOpen(false)}
                className="py-2.5 rounded-xl bg-[#154D34] text-white text-xs font-semibold shadow-xs"
              >
                Apply ({sortedProducts.length})
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
