import React, { useState } from 'react';
import {
  User,
  Package,
  MapPin,
  Heart,
  Bell,
  LogOut,
  Truck,
  FileText,
  Trash2,
  Plus,
  CheckCircle2,
  Clock,
  ChevronRight,
  Shield,
  ShoppingBag,
  ExternalLink,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Address, Order } from '../types';
import { InvoiceModal } from '../components/InvoiceModal';
import { SafeImage } from '../components/SafeImage';

export const AccountView: React.FC = () => {
  const {
    currentUser,
    orders,
    wishlist,
    products,
    removeFromWishlist,
    moveAllWishlistToCart,
    addToCart,
    logoutUser,
    openAuthModal,
    navigateTo,
    accountActiveTab,
    setAccountActiveTab,
    t,
  } = useApp();

  const activeTab = accountActiveTab;
  const setActiveTab = setAccountActiveTab;
  const [selectedInvoiceOrder, setSelectedInvoiceOrder] = useState<Order | null>(null);

  // Saved Addresses State
  const [addresses, setAddresses] = useState<Address[]>([
    {
      id: 'addr_1',
      name: currentUser?.name || 'Geeta Bhutavale',
      mobile: currentUser?.mobile || '9822012345',
      addressLine: 'Flat 402, Green Meadows, Baner Road',
      landmark: 'Near Balewadi High Street',
      city: 'Pune',
      state: 'Maharashtra',
      pincode: '411045',
      type: 'home',
      isDefault: true,
    },
  ]);

  const [newAddrModal, setNewAddrModal] = useState(false);
  const [addrName, setAddrName] = useState('');
  const [addrMobile, setAddrMobile] = useState('');
  const [addrLine, setAddrLine] = useState('');
  const [addrCity, setAddrCity] = useState('');
  const [addrState, setAddrState] = useState('Maharashtra');
  const [addrPin, setAddrPin] = useState('');
  const [addrType, setAddrType] = useState<'home' | 'office' | 'other'>('home');

  if (!currentUser) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-5">
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-[#154D34] mx-auto flex items-center justify-center shadow-xs">
          <User className="w-8 h-8" />
        </div>
        <div>
          <h2 className="font-serif text-2xl font-bold text-stone-900">Sign in to your Account</h2>
          <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
            Track your live plant shipments, download GST bills, manage wishlist and access saved delivery addresses.
          </p>
        </div>
        <div className="space-y-2.5">
          <button
            onClick={() => navigateTo('login')}
            className="w-full py-3 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-2xl text-xs font-bold transition-colors shadow-md flex items-center justify-center gap-2"
          >
            <span>Sign In to Account</span>
          </button>
          <button
            onClick={() => navigateTo('register')}
            className="w-full py-3 bg-white hover:bg-stone-50 text-stone-800 border border-stone-300 rounded-2xl text-xs font-bold transition-colors shadow-xs flex items-center justify-center gap-2"
          >
            <span>Create New Account (Sign Up)</span>
          </button>
        </div>
        <div className="pt-2">
          <button
            onClick={() => navigateTo('catalog')}
            className="text-xs font-medium text-[#154D34] hover:underline"
          >
            ← Explore Live Nursery Catalog
          </button>
        </div>
      </div>
    );
  }

  const handleAddAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addrName || !addrMobile || !addrLine || !addrPin) return;

    const newAddr: Address = {
      id: 'addr_' + Date.now(),
      name: addrName,
      mobile: addrMobile,
      addressLine: addrLine,
      city: addrCity || 'Pune',
      state: addrState,
      pincode: addrPin,
      type: addrType,
      isDefault: addresses.length === 0,
    };

    setAddresses([...addresses, newAddr]);
    setNewAddrModal(false);
    setAddrName('');
    setAddrMobile('');
    setAddrLine('');
    setAddrPin('');
  };

  const wishlistedProducts = products.filter((p) => wishlist.includes(p.id));

  // Order tracking status steps helper
  const orderSteps = [
    { label: 'Order Placed', code: 'Placed' },
    { label: 'Confirmed', code: 'Confirmed' },
    { label: 'Packed with Care', code: 'Packed' },
    { label: 'Dispatched', code: 'Dispatched' },
    { label: 'Delivered', code: 'Delivered' },
  ];

  const getStepIndex = (status: string) => {
    switch (status) {
      case 'Placed':
        return 0;
      case 'Confirmed':
        return 1;
      case 'Packed':
        return 2;
      case 'Dispatched':
        return 3;
      case 'Delivered':
        return 4;
      default:
        return 1;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Account Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-[#154D34] text-white flex items-center justify-center font-bold text-2xl font-serif">
            {currentUser.name.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-stone-900">{currentUser.name}</h1>
              {currentUser.role === 'admin' && (
                <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-bold text-[10px] uppercase tracking-wider">
                  Admin
                </span>
              )}
            </div>
            <p className="text-xs text-stone-500">
              {currentUser.email} | +91 {currentUser.mobile}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-auto">
          {currentUser.role === 'admin' && (
            <button
              onClick={() => navigateTo('admin')}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
            >
              Open Admin Portal
            </button>
          )}
          <button
            onClick={logoutUser}
            className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b border-stone-200 gap-2 sm:gap-6 text-xs sm:text-sm font-bold overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('orders')}
          className={`pb-3 border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
            activeTab === 'orders'
              ? 'border-[#154D34] text-[#154D34]'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>My Plant Orders ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('wishlist')}
          className={`pb-3 border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
            activeTab === 'wishlist'
              ? 'border-[#154D34] text-[#154D34]'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>Wishlist ({wishlist.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('addresses')}
          className={`pb-3 border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
            activeTab === 'addresses'
              ? 'border-[#154D34] text-[#154D34]'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <MapPin className="w-4 h-4" />
          <span>Saved Addresses ({addresses.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`pb-3 border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
            activeTab === 'profile'
              ? 'border-[#154D34] text-[#154D34]'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <User className="w-4 h-4" />
          <span>Profile & Notifications</span>
        </button>
      </div>

      {/* Tab 1: Orders & Live Tracking */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          {orders.length > 0 ? (
            orders.map((ord) => {
              const currentStepIdx = getStepIndex(ord.orderStatus);

              return (
                <div
                  key={ord.id}
                  className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden"
                >
                  {/* Order Top Bar */}
                  <div className="p-4 sm:p-6 bg-stone-50/80 border-b border-stone-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-stone-900">
                          Order #{ord.id}
                        </span>
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                          {ord.orderStatus}
                        </span>
                      </div>
                      <p className="text-stone-500">
                        Placed on {ord.date} | Payment: {ord.paymentMethod}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedInvoiceOrder(ord)}
                        className="px-3 py-1.5 bg-white border border-stone-300 hover:bg-stone-100 text-stone-700 font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
                      >
                        <FileText className="w-3.5 h-3.5 text-[#154D34]" />
                        <span>GST Invoice</span>
                      </button>
                    </div>
                  </div>

                  {/* Visual Stepper for Tracking */}
                  <div className="p-6 border-b border-stone-100">
                    <h4 className="text-xs font-bold text-stone-500 uppercase tracking-wider mb-4">
                      Shipment Status (AWB: {ord.trackingNumber || 'Processing'})
                    </h4>

                    <div className="relative flex items-center justify-between max-w-2xl mx-auto">
                      {/* Connecting Line */}
                      <div className="absolute top-1/2 left-0 right-0 h-1 bg-stone-200 -translate-y-1/2 z-0" />
                      <div
                        className="absolute top-1/2 left-0 h-1 bg-[#154D34] -translate-y-1/2 z-0 transition-all duration-500"
                        style={{
                          width: `${(currentStepIdx / (orderSteps.length - 1)) * 100}%`,
                        }}
                      />

                      {orderSteps.map((step, idx) => {
                        const isDone = idx <= currentStepIdx;
                        return (
                          <div
                            key={step.code}
                            className="relative z-10 flex flex-col items-center text-center"
                          >
                            <div
                              className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-colors ${
                                isDone
                                  ? 'bg-[#154D34] border-[#154D34] text-white'
                                  : 'bg-white border-stone-300 text-stone-400'
                              }`}
                            >
                              {isDone ? '✓' : idx + 1}
                            </div>
                            <span
                              className={`text-[10px] sm:text-xs mt-1.5 font-medium max-w-[70px] ${
                                isDone ? 'text-stone-900 font-bold' : 'text-stone-400'
                              }`}
                            >
                              {step.label}
                            </span>
                          </div>
                        );
                      })}
                    </div>

                    <div className="mt-6 p-3 bg-emerald-50 rounded-xl text-xs text-emerald-900 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <Truck className="w-4 h-4 text-emerald-700" />
                        <span>
                          Estimated Delivery by <strong>{ord.estimatedDeliveryDate}</strong>
                        </span>
                      </span>
                      <span className="text-[11px] text-emerald-700">
                        {ord.courierPartner || 'Nursery Express Logistics'}
                      </span>
                    </div>
                  </div>

                  {/* Items List */}
                  <div className="p-4 sm:p-6 divide-y divide-stone-100">
                    {ord.items.map((item, idx) => (
                      <div key={idx} className="py-3 flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <SafeImage
                            src={item.image}
                            alt={item.name}
                            className="w-12 h-12 rounded-xl object-cover bg-stone-100 border border-stone-200"
                          />
                          <div>
                            <h5 className="font-bold text-stone-900 text-xs sm:text-sm">
                              {item.name}
                            </h5>
                            <p className="text-stone-400 text-xs">Qty: {item.quantity}</p>
                          </div>
                        </div>
                        <span className="font-bold text-stone-900 text-xs sm:text-sm">
                          ₹{item.price * item.quantity}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Order Total Footer */}
                  <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between text-xs font-bold text-stone-900">
                    <span>
                      Shipping to: {ord.shippingAddress.city}, {ord.shippingAddress.state}
                    </span>
                    <span className="text-sm text-[#154D34]">
                      Total: ₹{ord.totalAmount}
                    </span>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="bg-white p-12 rounded-3xl text-center border border-stone-200">
              <Package className="w-12 h-12 text-stone-300 mx-auto mb-3" />
              <h3 className="font-bold text-stone-900 text-base">No orders placed yet</h3>
              <p className="text-xs text-stone-500 mt-1 mb-4">
                Explore our healthy, nursery-grown plants to green up your space.
              </p>
              <button
                onClick={() => navigateTo('catalog')}
                className="px-6 py-2.5 bg-[#154D34] text-white rounded-full text-xs font-bold"
              >
                Browse Plants
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Wishlist */}
      {activeTab === 'wishlist' && (
        <div className="space-y-6">
          {wishlistedProducts.length > 0 ? (
            <>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-stone-50 p-4 rounded-2xl border border-stone-200">
                <div className="text-xs">
                  <span className="font-bold text-stone-900">
                    {wishlistedProducts.length} {wishlistedProducts.length === 1 ? 'Plant' : 'Plants'} Saved
                  </span>
                  <p className="text-stone-500 text-[11px]">Move items to cart for home delivery or view the full wishlist page.</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => navigateTo('wishlist')}
                    className="px-3.5 py-1.5 bg-white hover:bg-stone-100 text-stone-700 border border-stone-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Open Full Page</span>
                  </button>
                  <button
                    onClick={moveAllWishlistToCart}
                    className="px-3.5 py-1.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Move All to Cart</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                {wishlistedProducts.map((p) => (
                  <div
                    key={p.id}
                    className="bg-white rounded-2xl border border-stone-200 p-4 flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow"
                  >
                    <div className="relative aspect-square rounded-xl overflow-hidden bg-stone-100 mb-3 cursor-pointer group">
                      <div onClick={() => navigateTo('product-detail', { productSlug: p.slug })}>
                        <SafeImage
                          src={p.images[0]}
                          alt={p.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          removeFromWishlist(p.id);
                        }}
                        className="absolute top-2 right-2 p-1.5 bg-white/90 rounded-full text-rose-600 hover:bg-white transition-colors"
                        title="Remove from Wishlist"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div>
                      <h4
                        onClick={() => navigateTo('product-detail', { productSlug: p.slug })}
                        className="font-bold text-sm text-stone-900 hover:text-[#154D34] cursor-pointer transition-colors"
                      >
                        {p.name}
                      </h4>
                      <p className="text-xs text-stone-500">{p.category}</p>
                      <div className="flex items-baseline gap-2 mt-2">
                        <span className="font-bold text-stone-900">₹{p.price}</span>
                        <span className="text-xs text-stone-400 line-through">₹{p.mrp}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        addToCart(p, 1);
                        removeFromWishlist(p.id);
                      }}
                      className="mt-4 w-full py-2 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Move to Cart</span>
                    </button>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="bg-white p-12 rounded-3xl text-center border border-stone-200">
              <Heart className="w-12 h-12 text-stone-300 mx-auto mb-3" />
              <h3 className="font-bold text-stone-900 text-base">Your Wishlist is Empty</h3>
              <p className="text-xs text-stone-500 mt-1 mb-4">
                Save your favorite plants to order them anytime.
              </p>
              <button
                onClick={() => navigateTo('catalog')}
                className="px-6 py-2.5 bg-[#154D34] text-white rounded-full text-xs font-bold"
              >
                Discover Plants
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Saved Addresses */}
      {activeTab === 'addresses' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-stone-900 text-base">Saved Delivery Addresses</h3>
            <button
              onClick={() => setNewAddrModal(true)}
              className="px-4 py-2 bg-[#154D34] text-white rounded-xl text-xs font-semibold flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New Address</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {addresses.map((addr) => (
              <div
                key={addr.id}
                className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs relative space-y-2 text-xs"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-stone-900">{addr.name}</span>
                    <span className="px-2 py-0.5 rounded bg-stone-100 font-bold uppercase text-[10px] text-stone-600">
                      {addr.type}
                    </span>
                    {addr.isDefault && (
                      <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                        Default
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => setAddresses(addresses.filter((a) => a.id !== addr.id))}
                    className="text-stone-400 hover:text-rose-600 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-stone-600">{addr.addressLine}</p>
                {addr.landmark && <p className="text-stone-500">Landmark: {addr.landmark}</p>}
                <p className="text-stone-700">
                  {addr.city}, {addr.state} - <strong>{addr.pincode}</strong>
                </p>
                <p className="text-stone-500 pt-1">Mobile: +91 {addr.mobile}</p>
              </div>
            ))}
          </div>

          {/* New Address Modal */}
          {newAddrModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
              <div className="relative w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl space-y-4">
                <h4 className="font-bold text-stone-900 text-base">Add New Indian Delivery Address</h4>
                <form onSubmit={handleAddAddress} className="space-y-3 text-xs">
                  <div>
                    <label className="block font-semibold mb-1">Full Name *</label>
                    <input
                      type="text"
                      required
                      value={addrName}
                      onChange={(e) => setAddrName(e.target.value)}
                      className="w-full p-2 border rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold mb-1">Mobile (+91) *</label>
                    <input
                      type="tel"
                      required
                      maxLength={10}
                      value={addrMobile}
                      onChange={(e) => setAddrMobile(e.target.value.replace(/\D/g, ''))}
                      className="w-full p-2 border rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold mb-1">Flat / Building / Locality *</label>
                    <input
                      type="text"
                      required
                      value={addrLine}
                      onChange={(e) => setAddrLine(e.target.value)}
                      className="w-full p-2 border rounded-xl"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block font-semibold mb-1">City *</label>
                      <input
                        type="text"
                        required
                        value={addrCity}
                        onChange={(e) => setAddrCity(e.target.value)}
                        className="w-full p-2 border rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold mb-1">Pincode *</label>
                      <input
                        type="text"
                        required
                        maxLength={6}
                        value={addrPin}
                        onChange={(e) => setAddrPin(e.target.value.replace(/\D/g, ''))}
                        className="w-full p-2 border rounded-xl"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-3">
                    <button
                      type="button"
                      onClick={() => setNewAddrModal(false)}
                      className="px-4 py-2 font-semibold text-stone-500"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 bg-[#154D34] text-white rounded-xl font-bold"
                    >
                      Save Address
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Profile & Notification Preferences */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-xs max-w-xl space-y-6">
          <h3 className="font-bold text-stone-900 text-base">Account Information</h3>

          <div className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Your Name</label>
              <input
                type="text"
                defaultValue={currentUser.name}
                className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Email Address</label>
              <input
                type="email"
                defaultValue={currentUser.email}
                className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Registered Mobile (+91)</label>
              <input
                type="tel"
                defaultValue={currentUser.mobile}
                className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-stone-100">
            <h4 className="font-bold text-stone-900 text-sm mb-3">Notification Preferences</h4>
            <div className="space-y-2.5 text-xs text-stone-700">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" defaultChecked className="accent-[#154D34]" />
                <span>WhatsApp Order Tracking & Plant Care Reminders</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" defaultChecked className="accent-[#154D34]" />
                <span>SMS Dispatch and Delivery Updates</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" defaultChecked className="accent-[#154D34]" />
                <span>Email Seasonal Offers & Gardening Guides</span>
              </label>
            </div>
          </div>

          <button
            onClick={() => alert('Profile and preferences updated successfully!')}
            className="px-6 py-2.5 bg-[#154D34] text-white rounded-xl font-bold text-xs"
          >
            Update Profile
          </button>
        </div>
      )}

      {/* Invoice Modal for selected order */}
      {selectedInvoiceOrder && (
        <InvoiceModal
          order={selectedInvoiceOrder}
          onClose={() => setSelectedInvoiceOrder(null)}
        />
      )}
    </div>
  );
};
