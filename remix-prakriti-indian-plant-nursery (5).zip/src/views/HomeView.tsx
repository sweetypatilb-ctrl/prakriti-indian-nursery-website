import React, { useState } from 'react';
import {
  ArrowRight,
  ShieldCheck,
  Truck,
  Sparkles,
  HeartHandshake,
  Sprout,
  CheckCircle2,
  Star,
  Award,
  Calendar,
  Gift,
  Send,
  Flame,
  ChevronRight,
  Search,
  Compass,
  Sun,
  Droplets,
  Home,
  Briefcase,
  Flower2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ProductCard } from '../components/ProductCard';
import { SafeImage } from '../components/SafeImage';
import { POPULAR_SEARCH_CHIPS } from '../lib/plantSearch';

export const HomeView: React.FC = () => {
  const {
    t,
    products,
    categories,
    reviews,
    settings,
    navigateTo,
    language,
    setSearchQuery,
  } = useApp();

  const [heroSearch, setHeroSearch] = useState('');
  const [newsletterInput, setNewsletterInput] = useState('');
  const [newsletterDone, setNewsletterDone] = useState(false);

  // Best Sellers and Trending
  const bestSellers = (
    products.filter((p) => p.isBestSeller).length > 0
      ? products.filter((p) => p.isBestSeller)
      : products
  ).slice(0, 6);

  const newArrivals = (
    products.filter((p) => p.isNewArrival).length > 0
      ? products.filter((p) => p.isNewArrival)
      : products.slice(6)
  ).slice(0, 4);

  const handleHeroSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (heroSearch.trim()) {
      setSearchQuery(heroSearch.trim());
      navigateTo('catalog');
    }
  };

  const handleChipClick = (query: string) => {
    setSearchQuery(query);
    navigateTo('catalog');
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterInput.trim()) {
      setNewsletterDone(true);
      setNewsletterInput('');
    }
  };

  // Discover Plants Collections for Indian Homes, Gardens, Balconies, Offices, Pooja, & Landscaping
  const DISCOVER_SECTIONS = [
    {
      id: 'pooja',
      title: 'Pooja & Sacred Plants',
      titleHi: 'पूजा व पवित्र पौधे',
      titleMr: 'पूजेची व पवित्र वनस्पती',
      subtitle: 'Krishna Tulsi, Parijat, Desi Gulab, Shami & Bilva',
      desc: 'Revered holy plants for morning prayers, mandirs, and Indian courtyard sthapanas.',
      query: 'Pooja',
      image: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?auto=format&fit=crop&w=600&q=80',
      badge: 'Sacred Vastu',
    },
    {
      id: 'flower',
      title: 'Fragrant Flower Plants',
      titleHi: 'सुगंधित फूलों वाले पौधे',
      titleMr: 'सुगंधी फुलांची रोपे',
      subtitle: 'Mogra Jasmine, Desi Gulab, Hibiscus & Bougainvillea',
      desc: 'Abundant blooming varieties that perfume balconies and furnish fresh flowers for pooja.',
      query: 'Flower Plant',
      image: 'https://images.unsplash.com/photo-1597848212624-a19eb35e2651?auto=format&fit=crop&w=600&q=80',
      badge: 'All-Season Blooms',
    },
    {
      id: 'decor',
      title: 'Home Decor & Living Room',
      titleHi: 'सजावटी इनडोर पौधे',
      titleMr: 'घरातील शोभिवंत वनस्पती',
      subtitle: 'Money Plant, Areca Palm, Snake Plant & Croton',
      desc: 'Lush tropical greenery designed to bring calm luxury and fresh air to Indian flats.',
      query: 'Decoration Plant',
      image: 'https://images.unsplash.com/photo-1614594975525-e45190c55d0b?auto=format&fit=crop&w=600&q=80',
      badge: 'Aesthetic Greens',
    },
    {
      id: 'balcony',
      title: 'Balcony & Terrace Greens',
      titleHi: 'बालकनी व टेरेस की हरियाली',
      titleMr: 'गच्ची व बाल्कनीवरील रोपे',
      subtitle: 'Bougainvillea, Champa, Jade, Tulsi & Ferns',
      desc: 'Sun-hardy potted varieties that flourish in balcony planters and grills under Indian weather.',
      query: 'Balcony Plant',
      image: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=600&q=80',
      badge: 'Balcony Favorite',
    },
    {
      id: 'medicinal',
      title: 'Ayurvedic & Kitchen Herbs',
      titleHi: 'औषधी व रसोई मसाले पौधे',
      titleMr: 'औषधी व स्वयंपाकघर रोपे',
      subtitle: 'Curry Leaf (कढीपत्ता), Mint (पुदीना), Lemongrass & Aloe Vera',
      desc: 'Organic culinary herbs and therapeutic greens for daily Indian cooking and herbal chai.',
      query: 'Medicinal Plant',
      image: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=600&q=80',
      badge: 'Daily Kitchen Fresh',
    },
    {
      id: 'office',
      title: 'Office Desks & Workspaces',
      titleHi: 'ऑफिस टेबल व कम धूप के पौधे',
      titleMr: 'ऑफिस व अभ्यासाचे इनडोअर रोपे',
      subtitle: 'ZZ Plant, Snake Plant, Jade & Aglaonema',
      desc: 'Resilient low-light houseplants that thrive on work tables under air conditioning.',
      query: 'Indoor Plant',
      image: 'https://images.unsplash.com/photo-1632207691143-643e2a9a9361?auto=format&fit=crop&w=600&q=80',
      badge: 'Low Maintenance',
    },
  ];

  return (
    <div className="space-y-12 sm:space-y-16 pb-12">
      {/* 1. Hero Banner */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#EBF4EE] via-[#F4F8F5] to-white pt-8 sm:pt-12 pb-14 sm:pb-20 border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Left Copy */}
            <div className="lg:col-span-7 space-y-5 text-center lg:text-left">
              {/* Trust Badge */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100/90 text-[#154D34] text-xs font-bold shadow-2xs">
                <Sprout className="w-4 h-4 text-emerald-800" />
                <span>Prakriti Live Nursery • Acclimatized for Indian Homes & Climates</span>
              </div>

              <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-extrabold text-[#0D3222] tracking-tight leading-[1.12]">
                {language === 'hi'
                  ? 'प्रकृति की हरियाली हर भारतीय घर, बालकनी व पूजा में'
                  : language === 'mr'
                  ? 'भारतीय घरे, गच्ची व बागांसाठी अस्सल जिवंत रोपे'
                  : 'Nursery Fresh Live Plants for Indian Homes, Balconies & Pooja'}
              </h1>

              <p className="text-sm sm:text-lg text-stone-700 max-w-xl mx-auto lg:mx-0 leading-relaxed">
                Explore hand-nurtured Indian flowering plants, sacred Tulsi, air-purifying foliage, and fruit saplings — dispatched securely in 5-layer ventilated packaging with Pan-India live transit guarantee.
              </p>

              {/* Interactive Search Bar in Hero */}
              <div className="pt-2 max-w-xl mx-auto lg:mx-0">
                <form
                  onSubmit={handleHeroSearchSubmit}
                  className="flex items-center bg-white rounded-full p-1.5 shadow-md border border-stone-200 focus-within:border-[#154D34] focus-within:ring-2 focus-within:ring-[#154D34]/20 transition-all"
                >
                  <Search className="w-5 h-5 text-stone-400 ml-3 shrink-0" />
                  <input
                    type="text"
                    value={heroSearch}
                    onChange={(e) => setHeroSearch(e.target.value)}
                    placeholder="Search 'Flower Plant', 'Decoration Plant', 'Tulsi', 'Indoor', 'Rose'..."
                    className="w-full px-3 py-2 text-xs sm:text-sm text-stone-800 bg-transparent outline-none placeholder:text-stone-400"
                  />
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-[#154D34] hover:bg-[#0D3222] text-white text-xs sm:text-sm font-semibold rounded-full shrink-0 transition-colors shadow-xs flex items-center gap-1.5"
                  >
                    <span>Find Plants</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </form>

                {/* Popular Search Chips under search input */}
                <div className="flex items-center gap-1.5 flex-wrap justify-center lg:justify-start pt-3">
                  <span className="text-[11px] font-semibold text-stone-600">Quick Searches:</span>
                  {POPULAR_SEARCH_CHIPS.slice(0, 5).map((chip) => (
                    <button
                      key={chip.query}
                      type="button"
                      onClick={() => handleChipClick(chip.query)}
                      className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-stone-700 hover:text-[#154D34] text-xs rounded-full border border-stone-200 transition-colors font-medium shadow-2xs"
                    >
                      {chip.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Badges row */}
              <div className="pt-4 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs text-stone-600 border-t border-emerald-200/60 max-w-lg mx-auto lg:mx-0">
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-emerald-800 shrink-0" />
                  <span className="font-medium">{t('freeDeliveryBadge')}</span>
                </div>
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-800 shrink-0" />
                  <span className="font-medium">{t('safePackagingBadge')}</span>
                </div>
                <div className="flex items-center gap-2 col-span-2 sm:col-span-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-800 shrink-0" />
                  <span className="font-medium">100% Replacement Guarantee</span>
                </div>
              </div>
            </div>

            {/* Right Hero Image Card */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white aspect-[4/3] sm:aspect-square bg-stone-100">
                <SafeImage
                  src="https://images.unsplash.com/photo-1545241047-6083a3684587?auto=format&fit=crop&w=1000&q=80"
                  alt="Indian Modern Plant Nursery"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md p-4 rounded-2xl border border-white/40 shadow-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider">
                        Monsoon Special Green Box
                      </p>
                      <p className="text-sm font-bold text-stone-900">
                        Sacred Tulsi + Mogra + Golden Money Plant
                      </p>
                    </div>
                    <div className="text-right shrink-0 pl-3">
                      <span className="text-xs text-stone-400 line-through">₹699</span>
                      <p className="text-base font-extrabold text-[#154D34]">₹399</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleChipClick('Flower Plant')}
                    className="w-full mt-2.5 py-1.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs font-semibold text-center transition-colors block"
                  >
                    Shop Indian Monsoon Plants
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Indian Festival / Monsoon Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-emerald-950 via-[#154D34] to-[#1E6043] text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
          <div className="relative z-10 max-w-2xl space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400 text-stone-950 text-xs font-extrabold uppercase tracking-wider">
              <Flame className="w-3.5 h-3.5 fill-stone-950" />
              <span>{settings.activeFestival}</span>
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold">
              {settings.festivalBannerTitle}
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100 leading-relaxed">
              {settings.festivalBannerSubtext}
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={() => navigateTo('offers')}
                className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-stone-950 text-xs sm:text-sm font-bold rounded-full shadow-md transition-colors"
              >
                {settings.festivalBannerDiscount}
              </button>
              <button
                onClick={() => handleChipClick('Flower Plant')}
                className="text-xs sm:text-sm font-semibold text-white hover:underline flex items-center gap-1"
              >
                <span>Browse Season Specials</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
          <Sprout className="absolute -right-10 -bottom-10 w-64 h-64 text-white/5 pointer-events-none" />
        </div>
      </section>

      {/* 3. DISCOVER PLANTS SECTION (Custom for Indian homes, gardens, balconies, offices, decoration, and pooja) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-2">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#154D34] flex items-center gap-1">
              <Compass className="w-3.5 h-3.5" />
              <span>Discover Indian Plants</span>
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 mt-1">
              Curated for Every Space & Purpose
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 mt-0.5 max-w-xl">
              From sacred mandir puja flora and vibrant balcony climbers to purifying office succulents and organic culinary herbs.
            </p>
          </div>
          <button
            onClick={() => navigateTo('catalog')}
            className="text-xs sm:text-sm font-bold text-[#154D34] hover:text-[#0D3222] flex items-center gap-1 self-start sm:self-auto shrink-0"
          >
            <span>View All Nursery Varieties ({products.length})</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {DISCOVER_SECTIONS.map((sec) => (
            <div
              key={sec.id}
              onClick={() => handleChipClick(sec.query)}
              className="group relative rounded-3xl overflow-hidden bg-white border border-stone-200 hover:border-emerald-500 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col cursor-pointer"
            >
              <div className="aspect-[16/10] w-full overflow-hidden bg-stone-100 relative">
                <SafeImage
                  src={sec.image}
                  alt={sec.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />
                <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-xs text-[#154D34] text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full shadow-2xs">
                  {sec.badge}
                </div>
                <div className="absolute bottom-3 left-4 right-4 text-white">
                  <h3 className="font-serif text-lg font-bold">
                    {language === 'hi' ? sec.titleHi : language === 'mr' ? sec.titleMr : sec.title}
                  </h3>
                  <p className="text-xs text-emerald-200 font-medium line-clamp-1">
                    {sec.subtitle}
                  </p>
                </div>
              </div>

              <div className="p-4 flex flex-col justify-between flex-1">
                <p className="text-xs text-stone-600 leading-relaxed mb-4">
                  {sec.desc}
                </p>
                <div className="flex items-center justify-between pt-2 border-t border-stone-100 text-xs font-bold text-[#154D34] group-hover:text-[#0D3222]">
                  <span>Explore Collection</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Best Sellers / Trending Indian Plants Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-2">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#154D34]">
              Trending in Indian Homes
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 mt-1">
              {t('bestSellers')}
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 mt-0.5">
              Customer favorites loved for quick growth, divine fragrance, and easy maintenance.
            </p>
          </div>
          <button
            onClick={() => navigateTo('catalog')}
            className="text-xs sm:text-sm font-bold text-[#154D34] hover:text-[#0D3222] flex items-center gap-1 self-start sm:self-auto"
          >
            <span>{t('viewAll')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
          {bestSellers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* 5. Shop by Indian Botanical Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-2">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#154D34]">
              Nursery Taxonomies
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 mt-1">
              {t('shopByCategory')}
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 mt-0.5">
              {t('exploreAllCategories')}
            </p>
          </div>
          <button
            onClick={() => navigateTo('catalog')}
            className="text-xs sm:text-sm font-bold text-[#154D34] hover:text-[#0D3222] flex items-center gap-1 self-start sm:self-auto"
          >
            <span>View All Categories ({categories.length})</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
          {categories.map((cat) => {
            const catName =
              language === 'hi' ? cat.nameHi : language === 'mr' ? cat.nameMr : cat.name;
            return (
              <button
                key={cat.id}
                onClick={() => navigateTo('catalog', { categorySlug: cat.slug })}
                className="group relative rounded-2xl overflow-hidden bg-white border border-stone-200 hover:border-emerald-400 shadow-xs hover:shadow-md transition-all text-left flex flex-col"
              >
                <div className="aspect-[4/3] w-full overflow-hidden bg-stone-100 relative">
                  <SafeImage
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                </div>
                <div className="p-2.5 sm:p-3">
                  <h3 className="text-xs sm:text-sm font-bold text-stone-800 group-hover:text-[#154D34] truncate">
                    {catName}
                  </h3>
                  <p className="text-[11px] text-stone-500 mt-0.5">
                    {cat.count}+ Varieties
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* 6. Promotional Offers & Combos */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-[#EBF4EE] rounded-3xl p-6 border border-emerald-200 flex flex-col justify-between shadow-2xs">
            <div>
              <span className="text-[11px] font-bold uppercase text-emerald-800 bg-emerald-200 px-2 py-0.5 rounded">
                Code: WELCOME10
              </span>
              <h3 className="text-xl font-serif font-bold text-stone-900 mt-2">
                10% Off First Green Order
              </h3>
              <p className="text-xs text-stone-600 mt-1">
                Apply coupon code WELCOME10 during checkout on all nursery live plants above ₹499.
              </p>
            </div>
            <button
              onClick={() => navigateTo('offers')}
              className="mt-4 inline-flex items-center gap-1 text-xs font-bold text-[#154D34] hover:underline"
            >
              <span>Explore Coupons</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="bg-[#FFF8EB] rounded-3xl p-6 border border-amber-200 flex flex-col justify-between shadow-2xs">
            <div>
              <span className="text-[11px] font-bold uppercase text-amber-800 bg-amber-200 px-2 py-0.5 rounded">
                Indian Balcony Combos
              </span>
              <h3 className="text-xl font-serif font-bold text-stone-900 mt-2">
                Buy More Save More Combos
              </h3>
              <p className="text-xs text-stone-600 mt-1">
                Curated combos: Holy Basil + Mogra Jasmine Fragrance Pack & Kitchen Herb tadka kit.
              </p>
            </div>
            <button
              onClick={() => handleChipClick('Flower Plant')}
              className="mt-4 inline-flex items-center gap-1 text-xs font-bold text-amber-900 hover:underline"
            >
              <span>View Plant Combos</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="bg-[#F6F5F2] rounded-3xl p-6 border border-stone-200 flex flex-col justify-between shadow-2xs">
            <div>
              <span className="text-[11px] font-bold uppercase text-stone-800 bg-stone-200 px-2 py-0.5 rounded">
                Pan-India Express Dispatch
              </span>
              <h3 className="text-xl font-serif font-bold text-stone-900 mt-2">
                Free Shipping on ₹999+
              </h3>
              <p className="text-xs text-stone-600 mt-1">
                Engineered ventilated plant cylinders protect leaves and roots throughout journey.
              </p>
            </div>
            <button
              onClick={() => navigateTo('catalog')}
              className="mt-4 inline-flex items-center gap-1 text-xs font-bold text-stone-900 hover:underline"
            >
              <span>Shop Qualifying Plants</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* 7. New Arrivals */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-2">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#154D34]">
              Fresh Nursery Stock
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 mt-1">
              {t('newArrivals')}
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 mt-0.5">
              {t('newArrivalsSub')}
            </p>
          </div>
          <button
            onClick={() => navigateTo('catalog')}
            className="text-xs sm:text-sm font-bold text-[#154D34] hover:text-[#0D3222] flex items-center gap-1 self-start sm:self-auto"
          >
            <span>{t('viewAll')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {newArrivals.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* 8. Why Choose Prakriti Nursery */}
      <section className="bg-stone-100/70 py-16 border-y border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-widest text-[#154D34]">
              Our Promise
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 mt-1">
              {t('whyChooseUs')}
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 mt-1">
              Every plant is hand-selected, cleaned, fertilized, and packaged by experienced horticulturalists.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: Sprout,
                title: 'Acclimatized Healthy Plants',
                desc: 'Grown in open Indian polyhouses so they adapt instantly to your home environment without transplant shock.',
              },
              {
                icon: ShieldCheck,
                title: '5-Layer Plant-Safe Packing',
                desc: 'Specially engineered corrugated honeycomb cylinders with moist cocopeat root cushions.',
              },
              {
                icon: Truck,
                title: 'Express 2-4 Day Delivery',
                desc: 'Priority perishable plant dispatch with real-time SMS & WhatsApp tracking to 19,000+ Indian pincodes.',
              },
              {
                icon: Award,
                title: 'Free Replacement Guarantee',
                desc: 'In the rare case a plant arrives damaged or stressed, we replace it immediately without hassles.',
              },
              {
                icon: HeartHandshake,
                title: 'Expert WhatsApp Support',
                desc: 'Connect directly with our plant doctors anytime for personalized watering and repotting advice.',
              },
              {
                icon: CheckCircle2,
                title: '100% Indian Transparent Pricing',
                desc: 'Zero hidden taxes. GST invoice included. Cash on Delivery and all Indian UPI payment methods supported.',
              },
            ].map((item, idx) => {
              const Icon = item.icon;
              return (
                <div
                  key={idx}
                  className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs hover:border-emerald-300 transition-colors"
                >
                  <div className="w-12 h-12 rounded-xl bg-emerald-50 text-[#154D34] flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-stone-900 mb-1.5">{item.title}</h3>
                  <p className="text-xs text-stone-600 leading-relaxed">{item.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 9. Customer Reviews from Indian Plant Parents */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-widest text-[#154D34]">
            Verified Plant Parents
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 mt-1">
            {t('customerReviews')}
          </h2>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Real feedback from plant lovers across Pune, Mumbai, Bengaluru, Delhi, Hyderabad and beyond.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {reviews.slice(0, 6).map((rev) => (
            <div
              key={rev.id}
              className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-1 text-amber-400 mb-3">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <h4 className="text-sm font-bold text-stone-900 mb-2">"{rev.title}"</h4>
                <p className="text-xs text-stone-600 leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-stone-100 flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-stone-900">{rev.userName}</p>
                  <p className="text-[11px] text-stone-400">{rev.city}</p>
                </div>
                <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Verified Buyer</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 10. Newsletter Subscription */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#154D34] text-white rounded-3xl p-8 sm:p-12 text-center relative overflow-hidden shadow-xl">
          <div className="relative z-10 max-w-xl mx-auto space-y-4">
            <div className="w-12 h-12 rounded-full bg-emerald-800 mx-auto flex items-center justify-center">
              <Sprout className="w-6 h-6 text-emerald-200" />
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold">
              {t('newsletterTitle')}
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100 leading-relaxed">
              {t('newsletterSub')}
            </p>

            {newsletterDone ? (
              <div className="p-4 bg-emerald-800 rounded-2xl text-emerald-200 text-xs font-semibold flex items-center justify-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>Dhanyawaad! You are subscribed to Prakriti Green Care updates.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto pt-2">
                <input
                  type="text"
                  required
                  value={newsletterInput}
                  onChange={(e) => setNewsletterInput(e.target.value)}
                  placeholder={t('enterEmailOrMobile')}
                  className="flex-1 px-4 py-3 bg-white/10 text-white placeholder-emerald-200/70 border border-white/20 rounded-full text-xs sm:text-sm focus:outline-none focus:bg-white/20"
                />
                <button
                  type="submit"
                  className="px-6 py-3 bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs sm:text-sm rounded-full transition-colors shadow-md shrink-0"
                >
                  {t('subscribe')}
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};
