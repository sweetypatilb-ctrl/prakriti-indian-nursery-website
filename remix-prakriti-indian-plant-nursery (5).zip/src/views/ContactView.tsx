import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Send,
  MessageCircle,
  CheckCircle2,
  Building,
  ShieldCheck,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ContactView: React.FC = () => {
  const { settings, t } = useApp();
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('Order & Delivery Inquiry');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !mobile || !message) return;
    setSubmitted(true);
    setTimeout(() => {
      setName('');
      setMobile('');
      setEmail('');
      setMessage('');
      setSubmitted(false);
    }, 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-[#154D34]">
          Always Here For You
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-extrabold text-stone-900">
          Get in Touch with Prakriti Nursery
        </h1>
        <p className="text-xs sm:text-sm text-stone-600">
          Whether you need help selecting balcony plants, tracking a live courier, or corporate bulk gifting—our plant doctors and care team are happy to assist.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Contact Cards */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-5">
            <h3 className="font-bold text-stone-900 text-base">Customer Support</h3>

            <div className="space-y-4 text-xs">
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-[#154D34] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-stone-700 block">Phone Support (+91)</span>
                  <a href={`tel:${settings.phone}`} className="text-stone-900 font-bold hover:underline">
                    {settings.phone}
                  </a>
                  <p className="text-stone-400 text-[11px] mt-0.5">Mon - Sun, 9:00 AM - 8:00 PM IST</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <MessageCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-stone-700 block">WhatsApp Plant Doctor</span>
                  <a
                    href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-emerald-700 font-bold hover:underline"
                  >
                    {settings.whatsappNumber}
                  </a>
                  <p className="text-stone-400 text-[11px] mt-0.5">Instant plant health queries & photos</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-[#154D34] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-stone-700 block">Official Support Email</span>
                  <a href={`mailto:${settings.email}`} className="text-stone-900 font-bold hover:underline">
                    {settings.email}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 pt-2 border-t border-stone-100">
                <Clock className="w-5 h-5 text-[#154D34] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-stone-700 block">Greenhouse Visiting Hours</span>
                  <p className="text-stone-900 font-medium">8:00 AM - 7:00 PM (All 7 Days)</p>
                  <p className="text-stone-400 text-[11px]">Walk-ins welcome at our Pune & Bengaluru centers.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Greenhouse Addresses */}
          <div className="bg-[#FAF8F5] p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4 text-xs">
            <h4 className="font-bold text-stone-900 text-sm flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-[#154D34]" />
              <span>Nursery Greenhouse Locations</span>
            </h4>

            <div className="space-y-3">
              <div className="p-3 bg-white rounded-xl border border-stone-200">
                <p className="font-bold text-stone-900 text-xs">Central Greenhouse & Dispatch</p>
                <p className="text-stone-600 mt-0.5">{settings.address}</p>
                <p className="text-stone-400 text-[11px] mt-1">GSTIN: {settings.gstin}</p>
              </div>

              <div className="p-3 bg-white rounded-xl border border-stone-200">
                <p className="font-bold text-stone-900 text-xs">South India Polyhouse Hub</p>
                <p className="text-stone-600 mt-0.5">
                  Survey 84, Sarjapur-Attibele Road, Anekal Taluk, Bengaluru, Karnataka - 562125
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Contact & Inquiry Form */}
        <div className="lg:col-span-7">
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-xs space-y-5">
            <h3 className="font-bold text-stone-900 text-lg">Send Us a Message</h3>
            <p className="text-xs text-stone-500">
              Fill the form below and our horticulturalist team will reply within 4 hours.
            </p>

            {submitted ? (
              <div className="p-8 bg-emerald-50 rounded-2xl border border-emerald-200 text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                <h4 className="font-bold text-emerald-950 text-base">Message Sent Successfully!</h4>
                <p className="text-xs text-emerald-800">
                  Dhanyawaad! We have received your query. Our plant doctor will reach out via WhatsApp / Email shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Your Name *</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Anand Kulkarni"
                      className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Mobile (+91) *</label>
                    <input
                      type="tel"
                      required
                      maxLength={10}
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                      placeholder="10-digit mobile"
                      className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Email Address</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@email.com"
                      className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Query Subject</label>
                    <select
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                    >
                      <option value="Order & Delivery Inquiry">Order & Delivery Tracking</option>
                      <option value="Plant Care & Health Doctor">Plant Doctor (Health / Pests)</option>
                      <option value="Corporate & Wedding Gifting">Bulk Corporate / Wedding Gifting</option>
                      <option value="Replacement Request">Plant Replacement Guarantee</option>
                      <option value="General Feedback">General Feedback</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Your Message *</label>
                  <textarea
                    rows={4}
                    required
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Provide details about your query, pincode or plant condition..."
                    className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                  />
                </div>

                <button
                  type="submit"
                  className="px-8 py-3 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl font-bold text-xs sm:text-sm shadow-md transition-colors flex items-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Message</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
