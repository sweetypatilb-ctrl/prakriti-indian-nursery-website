import React, { useState } from 'react';
import {
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  ArrowRight,
  Sparkles,
  ShieldCheck,
  Tag,
  Check,
  Truck,
  ArrowLeft,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SafeImage } from '../components/SafeImage';

export const CartView: React.FC = () => {
  const {
    cart,
    cartTotal,
    cartSubtotal,
    cartCount,
    updateCartQuantity,
    updateCartQty,
    removeFromCart,
    appliedCoupon,
    applyCoupon,
    removeCoupon,
    coupons,
    settings,
    navigateTo,
    t,
  } = useApp();

  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState('');

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (typeof updateCartQuantity === 'function') {
      updateCartQuantity(productId, quantity);
    } else if (typeof updateCartQty === 'function') {
      updateCartQty(productId, quantity);
    }
  };

  // 100% Guaranteed Safe Subtotal Calculation
  const computedSubtotal = (Array.isArray(cart) ? cart : []).reduce((sum, item) => {
    if (!item || !item.product) return sum;
    const rawPrice = item.product.price ?? (item.product as any)?.priceInINR ?? 0;
    const price = typeof rawPrice === 'number' && Number.isFinite(rawPrice)
      ? rawPrice
      : (parseFloat(String(rawPrice).replace(/[^\d.-]/g, '')) || 0);
    const qty = Number(item.quantity) || 1;
    const line = price * qty;
    return sum + (Number.isFinite(line) ? line : 0);
  }, 0);

  const effectiveCartTotal = (typeof cartTotal === 'number' && Number.isFinite(cartTotal) && cartTotal >= 0)
    ? cartTotal
    : (typeof cartSubtotal === 'number' && Number.isFinite(cartSubtotal) && cartSubtotal >= 0)
      ? cartSubtotal
      : computedSubtotal;

  const freeDeliveryThreshold = Number(settings?.freeDeliveryThreshold ?? settings?.freeShippingThreshold) || 999;
  const isFreeDelivery = effectiveCartTotal >= freeDeliveryThreshold;
  const diffForFree = Math.max(0, freeDeliveryThreshold - effectiveCartTotal);
  const standardFee = Number(settings?.standardDeliveryCharge ?? settings?.standardShippingFee) || 99;
  const deliveryCharge = isFreeDelivery || effectiveCartTotal === 0 ? 0 : standardFee;

  // Coupon calculation
  let couponDiscount = 0;
  if (appliedCoupon && effectiveCartTotal > 0) {
    const discVal = Number(appliedCoupon.discountValue) || 0;
    if (appliedCoupon.discountType === 'percentage') {
      couponDiscount = Math.round((effectiveCartTotal * discVal) / 100);
      if (appliedCoupon.maxDiscount) {
        couponDiscount = Math.min(couponDiscount, Number(appliedCoupon.maxDiscount) || couponDiscount);
      }
    } else {
      couponDiscount = Math.min(effectiveCartTotal, discVal);
    }
  }
  couponDiscount = Number.isFinite(couponDiscount) ? Math.max(0, couponDiscount) : 0;

  // Estimated GST (Included in MRP, calculated for transparent breakdown)
  const gstRate = Number(settings?.gstRate) || 0;
  const taxableAmount = Math.max(0, effectiveCartTotal - couponDiscount);
  const gstAmount = gstRate > 0 ? Math.round((taxableAmount * gstRate) / (100 + gstRate)) : 0;
  const finalTotal = Math.max(0, effectiveCartTotal - couponDiscount + deliveryCharge);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    if (!couponInput.trim()) return;

    const res = applyCoupon(couponInput.trim());
    if (!res.success) {
      setCouponError(res.message);
    } else {
      setCouponInput('');
    }
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <div className="w-20 h-20 rounded-full bg-emerald-50 text-[#154D34] mx-auto flex items-center justify-center mb-4">
          <ShoppingBag className="w-10 h-10 text-emerald-600" />
        </div>
        <h2 className="font-serif text-2xl font-bold text-stone-900">{t('emptyCart')}</h2>
        <p className="text-xs sm:text-sm text-stone-500 max-w-sm mx-auto mt-2 mb-8">
          {t('emptyCartDesc')}
        </p>
        <button
          onClick={() => navigateTo('catalog')}
          className="px-8 py-3.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-full font-bold text-sm shadow-md transition-colors inline-flex items-center gap-2"
        >
          <span>{t('startShopping')}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Title */}
      <div className="flex items-center justify-between pb-4 border-b border-stone-200">
        <div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
            {t('cartTitle')} ({cartCount} {cartCount === 1 ? 'item' : 'items'})
          </h1>
          <p className="text-xs text-stone-500 mt-0.5">
            Carefully packaged live plants ready for dispatch
          </p>
        </div>
        <button
          onClick={() => navigateTo('catalog')}
          className="text-xs font-semibold text-[#154D34] hover:underline flex items-center gap-1"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>{t('continueShopping')}</span>
        </button>
      </div>

      {/* Free Shipping Progress Indicator */}
      <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4">
        <div className="flex items-center justify-between text-xs font-semibold text-emerald-950 mb-2">
          <div className="flex items-center gap-1.5">
            <Truck className="w-4 h-4 text-emerald-700" />
            <span>
              {isFreeDelivery
                ? '🎉 Congratulations! You have unlocked FREE Plant Delivery!'
                : `Add ₹${diffForFree.toLocaleString('en-IN')} more live greens to qualify for FREE Delivery!`}
            </span>
          </div>
          <span className="font-mono font-bold">
            ₹{effectiveCartTotal.toLocaleString('en-IN')} / ₹{freeDeliveryThreshold.toLocaleString('en-IN')}
          </span>
        </div>
        <div className="w-full h-2 bg-emerald-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-[#154D34] rounded-full transition-all duration-300"
            style={{ width: `${Math.min(100, freeDeliveryThreshold > 0 ? (effectiveCartTotal / freeDeliveryThreshold) * 100 : 100)}%` }}
          />
        </div>
      </div>

      {/* Main Cart Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Cart Items List */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden divide-y divide-stone-100 shadow-xs">
            {cart.map((item) => {
              const itemPrice = Number(item.product?.price ?? (item.product as any)?.priceInINR) || 0;
              const itemMrp = Number(item.product?.mrp) || Math.round(itemPrice * 1.3);
              const itemQty = Number(item.quantity) || 1;
              const lineTotal = itemPrice * itemQty;

              return (
                <div
                  key={item.product.id}
                  className="p-4 sm:p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                >
                  {/* Thumbnail and Info */}
                  <div className="flex items-center gap-4">
                    <div
                      onClick={() => navigateTo('product-detail', { productSlug: item.product.slug })}
                      className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden bg-stone-100 shrink-0 border border-stone-200 cursor-pointer"
                    >
                      <SafeImage
                        src={item.product.images?.[0]}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">
                        {item.product.category}
                      </span>
                      <h3
                        onClick={() => navigateTo('product-detail', { productSlug: item.product.slug })}
                        className="text-sm sm:text-base font-bold text-stone-900 hover:text-[#154D34] cursor-pointer"
                      >
                        {item.product.name}
                      </h3>
                      <p className="text-xs text-stone-400 mt-0.5">
                        Potted in 5" Nursery Pot
                      </p>
                      <div className="flex items-baseline gap-2 mt-1.5">
                        <span className="text-base font-bold text-stone-900">
                          ₹{itemPrice.toLocaleString('en-IN')}
                        </span>
                        <span className="text-xs text-stone-400 line-through">
                          ₹{itemMrp.toLocaleString('en-IN')}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Quantity and Actions */}
                  <div className="flex items-center justify-between w-full sm:w-auto sm:justify-end gap-6 pt-2 sm:pt-0">
                    {/* Quantity Counter */}
                    <div className="flex items-center border border-stone-300 rounded-xl bg-stone-50 p-1">
                      <button
                        onClick={() => handleUpdateQuantity(item.product.id, itemQty - 1)}
                        className="p-1.5 text-stone-600 hover:text-stone-900 rounded-lg hover:bg-white transition-colors"
                        title="Decrease quantity"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-8 text-center font-bold text-xs sm:text-sm text-stone-800">
                        {itemQty}
                      </span>
                      <button
                        onClick={() => handleUpdateQuantity(item.product.id, itemQty + 1)}
                        className="p-1.5 text-stone-600 hover:text-stone-900 rounded-lg hover:bg-white transition-colors"
                        title="Increase quantity"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Line Total */}
                    <div className="text-right">
                      <span className="text-base font-bold text-stone-900">
                        ₹{lineTotal.toLocaleString('en-IN')}
                      </span>
                    </div>

                    {/* Remove Button */}
                    <button
                      onClick={() => removeFromCart(item.product.id)}
                      className="p-2 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Plant Packing Guarantee */}
          <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 flex items-center gap-3 text-xs text-stone-600">
            <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0" />
            <span>
              Your plants will be packed with moist cocopeat and protective cardboard cylinders to ensure 100% fresh arrival.
            </span>
          </div>
        </div>

        {/* Order Summary & Coupon Sidebar */}
        <div className="lg:col-span-4 space-y-6">
          {/* Coupon Box */}
          <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-xs space-y-4">
            <div className="flex items-center gap-2 text-sm font-bold text-stone-900">
              <Tag className="w-4 h-4 text-[#154D34]" />
              <span>{t('applyCoupon')}</span>
            </div>

            {appliedCoupon ? (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-emerald-800 font-mono text-sm">
                    {appliedCoupon.code}
                  </span>
                  <p className="text-emerald-700 text-[11px] mt-0.5">
                    {appliedCoupon.description}
                  </p>
                </div>
                <button
                  onClick={removeCoupon}
                  className="text-rose-600 font-semibold hover:underline text-xs"
                >
                  Remove
                </button>
              </div>
            ) : (
              <form onSubmit={handleApplyCoupon} className="space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                    placeholder="Enter Coupon Code"
                    className="flex-1 px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-mono uppercase focus:outline-none focus:border-[#154D34]"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold transition-colors"
                  >
                    Apply
                  </button>
                </div>
                {couponError && (
                  <p className="text-[11px] text-rose-600 font-medium">{couponError}</p>
                )}
              </form>
            )}

            {/* Quick Available Coupons */}
            {!appliedCoupon && (
              <div className="pt-2 border-t border-stone-100 space-y-1.5">
                <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider">
                  Available Offers
                </span>
                {coupons.map((c) => (
                  <div
                    key={c.code}
                    className="flex items-center justify-between p-2 rounded-lg bg-stone-50 text-xs border border-dashed border-stone-300"
                  >
                    <div>
                      <span className="font-mono font-bold text-[#154D34]">{c.code}</span>
                      <p className="text-[10px] text-stone-500">Min spend ₹{c.minOrderValue}</p>
                    </div>
                    <button
                      onClick={() => applyCoupon(c.code)}
                      className="px-2.5 py-1 text-[11px] font-bold text-[#154D34] bg-white border border-[#154D34] rounded-md hover:bg-emerald-50"
                    >
                      Apply
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Price Breakdown Box */}
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
            <h3 className="font-bold text-stone-900 text-base">{t('priceSummary')}</h3>

            <div className="space-y-2.5 text-xs text-stone-600">
              <div className="flex justify-between">
                <span>{t('subtotal')}</span>
                <span className="font-semibold text-stone-900">₹{effectiveCartTotal.toLocaleString('en-IN')}</span>
              </div>

              {couponDiscount > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Coupon Discount</span>
                  <span>-₹{couponDiscount.toLocaleString('en-IN')}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>{t('deliveryCharge')}</span>
                <span className={deliveryCharge === 0 ? 'text-emerald-700 font-bold' : 'font-semibold text-stone-900'}>
                  {deliveryCharge === 0 ? 'FREE' : `₹${deliveryCharge.toLocaleString('en-IN')}`}
                </span>
              </div>

              <div className="flex justify-between text-[11px] text-stone-400">
                <span>Estimated GST Included (Approx 5%-18%)</span>
                <span>₹{gstAmount.toLocaleString('en-IN')}</span>
              </div>

              <div className="flex justify-between text-base font-bold text-stone-900 pt-3 border-t border-stone-200">
                <span>{t('totalAmount')}</span>
                <span className="text-xl text-[#154D34]">₹{finalTotal.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <button
              onClick={() => navigateTo('checkout')}
              className="w-full py-3.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-2xl text-sm font-bold shadow-md transition-colors flex items-center justify-center gap-2"
            >
              <span>{t('proceedToCheckout')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <p className="text-center text-[11px] text-stone-400">
              100% Secure Checkout | UPI & Cash on Delivery Available
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
