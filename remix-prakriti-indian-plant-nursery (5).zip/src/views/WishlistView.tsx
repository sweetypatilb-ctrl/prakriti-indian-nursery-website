import React, { useState } from 'react';
import {
  Heart,
  ShoppingBag,
  Trash2,
  ArrowRight,
  Sparkles,
  Check,
  Sun,
  Droplets,
  ShieldCheck,
  ChevronRight,
  Share2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SafeImage } from '../components/SafeImage';
import { ProductCard } from '../components/ProductCard';

export const WishlistView: React.FC = () => {
  const {
    wishlist,
    products,
    removeFromWishlist,
    clearWishlist,
    moveAllWishlistToCart,
    addToCart,
    navigateTo,
    t,
  } = useApp();

  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 3000);
  };

  // Get wishlisted product objects
  const wishlistedProducts = products.filter((p) => wishlist.includes(p.id));

  // Recommended products if wishlist has few or no items
  const recommendedProducts = products
    .filter((p) => !wishlist.includes(p.id))
    .slice(0, 4);

  // Financial summary of wishlist
  const totalValue = wishlistedProducts.reduce((sum, p) => {
    const pr = Number(p.price ?? (p as any)?.priceInINR) || 0;
    return sum + pr;
  }, 0);
  const totalMrp = wishlistedProducts.reduce((sum, p) => {
    const pr = Number(p.price ?? (p as any)?.priceInINR) || 0;
    const mrp = Number(p.mrp) || Math.round(pr * 1.3);
    return sum + mrp;
  }, 0);
  const totalSavings = Math.max(0, totalMrp - totalValue);

  const handleMoveToCart = (product: typeof products[0]) => {
    addToCart(product, 1);
    removeFromWishlist(product.id);
    showNotification(`"${product.name}" moved to your cart!`);
  };

  const handleMoveAll = () => {
    if (wishlistedProducts.length === 0) return;
    moveAllWishlistToCart();
    showNotification('All saved plants have been moved to your cart!');
  };

  const handleShareWishlist = () => {
    if (navigator.share) {
      navigator
        .share({
          title: 'My Prakriti Nursery Plant Wishlist',
          text: `Check out the plants I saved on Prakriti Indian Plant Nursery!`,
          url: window.location.href,
        })
        .catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      showNotification('Wishlist link copied to clipboard!');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
      {/* Toast Notification */}
      {notification && (
        <div className="fixed bottom-20 sm:bottom-6 right-6 z-50 bg-[#154D34] text-white px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 text-xs font-semibold animate-fade-in border border-emerald-700/50">
          <Check className="w-4 h-4 text-emerald-300" />
          <span>{notification}</span>
        </div>
      )}

      {/* Breadcrumb Navigation */}
      <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-stone-500 mb-6">
        <button
          onClick={() => navigateTo('home')}
          className="hover:text-emerald-800 transition-colors"
        >
          {t('home')}
        </button>
        <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
        <span className="font-semibold text-stone-800">{t('wishlist')}</span>
      </nav>

      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-8 border-b border-stone-200">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-bold font-serif text-stone-900 tracking-tight flex items-center gap-2.5">
              <span>{t('wishlist')}</span>
              <span className="text-rose-500 text-xl font-normal">❤️</span>
            </h1>
            <span className="px-3 py-1 bg-stone-100 text-stone-700 rounded-full text-xs font-bold">
              {wishlistedProducts.length} {wishlistedProducts.length === 1 ? 'plant' : 'plants'}
            </span>
          </div>
          <p className="text-stone-600 text-sm mt-1.5 max-w-xl">
            Your personal green curation. Move items directly to your cart or track their availability and seasonal care tips.
          </p>
        </div>

        {wishlistedProducts.length > 0 && (
          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={handleShareWishlist}
              className="px-4 py-2.5 bg-white hover:bg-stone-50 text-stone-700 border border-stone-200 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all shadow-xs"
              title="Share Wishlist"
            >
              <Share2 className="w-3.5 h-3.5 text-stone-500" />
              <span>Share</span>
            </button>

            <button
              onClick={clearWishlist}
              className="px-4 py-2.5 bg-white hover:bg-rose-50 text-stone-600 hover:text-rose-600 border border-stone-200 hover:border-rose-200 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all shadow-xs"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear All</span>
            </button>

            <button
              onClick={handleMoveAll}
              className="px-5 py-2.5 bg-[#154D34] hover:bg-[#0E3624] text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-all shadow-sm hover:shadow-md"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Move All to Cart</span>
            </button>
          </div>
        )}
      </div>

      {/* Main Content Area */}
      {wishlistedProducts.length > 0 ? (
        <div className="mt-8 space-y-10">
          {/* Summary Strip */}
          <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4 text-xs">
              <div>
                <span className="text-stone-500 block">Wishlist Value:</span>
                <span className="text-base font-bold text-stone-900">₹{totalValue}</span>
              </div>
              {totalSavings > 0 && (
                <div className="border-l border-emerald-200 pl-4">
                  <span className="text-emerald-800 block">You Save:</span>
                  <span className="text-base font-bold text-emerald-800">₹{totalSavings}</span>
                </div>
              )}
              <div className="border-l border-emerald-200 pl-4 hidden md:block">
                <span className="text-stone-500 block">Packaging:</span>
                <span className="font-semibold text-emerald-900 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                  Eco-friendly 4-Layer Pot Box
                </span>
              </div>
            </div>

            <button
              onClick={handleMoveAll}
              className="self-start sm:self-auto text-xs font-bold text-[#154D34] hover:text-emerald-950 flex items-center gap-1 group"
            >
              <span>Ready to purchase all? Add to Cart</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Wishlist Items Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {wishlistedProducts.map((plant) => {
              const discountPercent = Math.round(((plant.mrp - plant.price) / plant.mrp) * 100);

              return (
                <div
                  key={plant.id}
                  className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between group"
                >
                  {/* Plant Image & Quick Badges */}
                  <div className="relative aspect-square overflow-hidden bg-stone-100">
                    <button
                      onClick={() =>
                        navigateTo('product-detail', { productSlug: plant.slug })
                      }
                      className="w-full h-full block text-left"
                    >
                      <SafeImage
                        src={plant.images[0]}
                        alt={plant.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </button>

                    {/* Category Tag */}
                    <div className="absolute top-3 left-3 flex flex-col gap-1.5">
                      <span className="px-2.5 py-1 bg-white/95 backdrop-blur-xs text-stone-800 rounded-lg text-[10px] font-bold shadow-xs">
                        {plant.category}
                      </span>
                      {discountPercent > 0 && (
                        <span className="px-2 py-0.5 bg-rose-600 text-white rounded-md text-[10px] font-extrabold shadow-xs">
                          {discountPercent}% OFF
                        </span>
                      )}
                    </div>

                    {/* Remove Button */}
                    <button
                      onClick={() => {
                        removeFromWishlist(plant.id);
                        showNotification(`Removed "${plant.name}" from wishlist`);
                      }}
                      className="absolute top-3 right-3 p-2 bg-white/95 hover:bg-white text-stone-400 hover:text-rose-600 rounded-full shadow-xs transition-colors"
                      title="Remove from Wishlist"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    {/* Native Indian Name Badge */}
                    {plant.nameHi && (
                      <div className="absolute bottom-2 left-2 bg-stone-900/80 backdrop-blur-xs text-white px-2 py-0.5 rounded text-[10px] font-medium">
                        {plant.nameHi} {plant.nameMr && `• ${plant.nameMr}`}
                      </div>
                    )}
                  </div>

                  {/* Plant Information */}
                  <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <button
                        onClick={() =>
                          navigateTo('product-detail', { productSlug: plant.slug })
                        }
                        className="text-left group/title"
                      >
                        <h3 className="font-bold text-sm sm:text-base text-stone-900 group-hover/title:text-[#154D34] transition-colors line-clamp-1">
                          {plant.name}
                        </h3>
                        {plant.scientificName && (
                          <p className="text-[11px] text-stone-400 italic line-clamp-1 mt-0.5">
                            {plant.scientificName}
                          </p>
                        )}
                      </button>

                      {/* Plant Care Highlights */}
                      <div className="mt-3 flex items-center gap-3 text-[11px] text-stone-600">
                        {plant.sunlightRequirement && (
                          <div className="flex items-center gap-1" title={plant.sunlightRequirement}>
                            <Sun className="w-3 h-3 text-amber-500 shrink-0" />
                            <span className="truncate max-w-[80px]">{plant.sunlightRequirement}</span>
                          </div>
                        )}
                        {plant.waterRequirement && (
                          <div className="flex items-center gap-1" title={plant.waterRequirement}>
                            <Droplets className="w-3 h-3 text-sky-500 shrink-0" />
                            <span className="truncate max-w-[80px]">{plant.waterRequirement}</span>
                          </div>
                        )}
                      </div>

                      {/* Pricing */}
                      <div className="mt-4 flex items-baseline gap-2">
                        <span className="text-base font-bold text-stone-900">₹{plant.price}</span>
                        {plant.mrp > plant.price && (
                          <span className="text-xs text-stone-400 line-through">₹{plant.mrp}</span>
                        )}
                        <span className="text-[10px] text-emerald-700 font-bold ml-auto">
                          In Stock
                        </span>
                      </div>
                    </div>

                    {/* Card Actions */}
                    <div className="mt-4 pt-3 border-t border-stone-100 flex items-center gap-2">
                      <button
                        onClick={() => handleMoveToCart(plant)}
                        className="flex-1 py-2.5 bg-[#154D34] hover:bg-[#0E3624] text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        <span>Move to Cart</span>
                      </button>
                      <button
                        onClick={() =>
                          navigateTo('product-detail', { productSlug: plant.slug })
                        }
                        className="p-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-medium transition-colors"
                        title="View Plant Details"
                      >
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* Empty State */
        <div className="py-16 text-center">
          <div className="w-20 h-20 bg-rose-50 border border-rose-100 rounded-full flex items-center justify-center mx-auto mb-5 shadow-xs">
            <Heart className="w-10 h-10 text-rose-400 stroke-[1.5]" />
          </div>
          <h2 className="text-xl font-bold font-serif text-stone-900">Your Wishlist is Empty</h2>
          <p className="text-stone-500 text-sm max-w-md mx-auto mt-2 mb-8">
            You haven’t added any plants to your wishlist yet. Tap the heart icon on any plant to save it for later or compare favorites.
          </p>
          <button
            onClick={() => navigateTo('catalog')}
            className="px-6 py-3 bg-[#154D34] hover:bg-[#0E3624] text-white rounded-xl text-xs font-bold inline-flex items-center gap-2 shadow-sm transition-all"
          >
            <Sparkles className="w-4 h-4 text-emerald-300" />
            <span>Explore Botanical Nursery Catalog</span>
          </button>
        </div>
      )}

      {/* Recommended Plants Section */}
      {recommendedProducts.length > 0 && (
        <section className="mt-16 pt-12 border-t border-stone-200">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-bold font-serif text-stone-900">
                Popular Plants to Add to Your Collection
              </h2>
              <p className="text-xs text-stone-500 mt-1">
                Handpicked, hardy Indian flora loved by home gardeners
              </p>
            </div>
            <button
              onClick={() => navigateTo('catalog')}
              className="text-xs font-bold text-[#154D34] hover:underline flex items-center gap-1"
            >
              <span>View All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {recommendedProducts.map((prod) => (
              <ProductCard key={prod.id} product={prod} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
