import React, { useState } from 'react';
import {
  Droplets,
  Sun,
  Sprout,
  AlertTriangle,
  Sparkles,
  Calendar,
  CheckCircle2,
  Bug,
  HelpCircle,
  ArrowRight,
  Send,
  RefreshCw,
  MessageSquare,
  Bot,
  Leaf,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const CareGuideView: React.FC = () => {
  const { navigateTo, language, t } = useApp();
  const [selectedSeason, setSelectedSeason] = useState<'monsoon' | 'summer' | 'winter'>('monsoon');

  // AI Plant Doctor Consultation State
  const [plantQuery, setPlantQuery] = useState('');
  const [selectedPlantCategory, setSelectedPlantCategory] = useState('Tulsi');
  const [selectedSymptomPreset, setSelectedSymptomPreset] = useState('');
  const [aiLang, setAiLang] = useState<'en' | 'hi' | 'mr'>((language as 'en' | 'hi' | 'mr') || 'en');
  const [consultationLoading, setConsultationLoading] = useState(false);
  const [doctorResponse, setDoctorResponse] = useState<string | null>(null);
  const [consultationSource, setConsultationSource] = useState<string | null>(null);
  const [consultationError, setConsultationError] = useState<string | null>(null);

  const POPULAR_PLANTS = [
    'Tulsi (Holy Basil)',
    'Money Plant',
    'Mogra (Jasmine)',
    'Hibiscus (Gudhal)',
    'Snake Plant',
    'Peace Lily',
    'Areca Palm',
    'Desi Rose',
    'Curry Leaf (Kadi Patta)',
    'Jade Plant',
    'Bougainvillea',
  ];

  const COMMON_SYMPTOMS = [
    'Yellowing leaves',
    'White cottony mealybugs',
    'Drooping & wilting stems',
    'Brown crispy leaf tips',
    'Flower buds dropping before bloom',
    'Soil stays wet & roots decaying',
  ];

  const QUICK_PROMPTS = [
    'How often should I water my Tulsi in heavy monsoon season?',
    'Why are my Money Plant leaves turning pale yellow?',
    'Organic spray for white mealybugs on my Hibiscus plant',
    'How to make Mogra (Jasmine) bloom abundantly with fragrance?',
  ];

  const handleConsultDoctor = async (customPrompt?: string) => {
    const queryToSend = customPrompt || plantQuery || selectedSymptomPreset;
    if (!queryToSend.trim() && !selectedPlantCategory) return;

    setConsultationLoading(true);
    setConsultationError(null);

    try {
      const res = await fetch('/api/plant-ai-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: queryToSend,
          plantName: selectedPlantCategory,
          problem: selectedSymptomPreset,
          language: aiLang,
        }),
      });

      const data = await res.json();
      if (data.success && data.advice) {
        setDoctorResponse(data.advice);
        setConsultationSource(data.source === 'gemini' ? 'Gemini 2.5 AI Horticulturist' : 'Prakriti Botanical Engine');
      } else {
        setConsultationError(data.error || 'Unable to fetch advisory at this moment.');
      }
    } catch (err: any) {
      setConsultationError(err?.message || 'Connection error. Please try again.');
    } finally {
      setConsultationLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-[#154D34]">
          Prakriti Horticultural Advisory
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-extrabold text-stone-900">
          Indian Plant Care Doctor & Calendar
        </h1>
        <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
          Expert horticultural tips formulated for Indian tropical, arid, and humid climates.
          Keep your balcony greens thriving in every season.
        </p>
      </div>

      {/* Season Selector Tabs */}
      <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-xs">
        <h2 className="text-sm font-bold text-stone-900 uppercase tracking-wider mb-4">
          Seasonal Gardening Guide (ऋतु अनुसार देखभाल)
        </h2>

        <div className="grid grid-cols-3 gap-3 mb-6">
          <button
            onClick={() => setSelectedSeason('monsoon')}
            className={`p-3 sm:p-4 rounded-2xl border-2 font-bold text-xs sm:text-sm transition-all text-center ${
              selectedSeason === 'monsoon'
                ? 'border-[#154D34] bg-emerald-50 text-[#154D34]'
                : 'border-stone-200 text-stone-600 hover:bg-stone-50'
            }`}
          >
            🌧️ Monsoon (July - Sept)
          </button>
          <button
            onClick={() => setSelectedSeason('summer')}
            className={`p-3 sm:p-4 rounded-2xl border-2 font-bold text-xs sm:text-sm transition-all text-center ${
              selectedSeason === 'summer'
                ? 'border-[#154D34] bg-emerald-50 text-[#154D34]'
                : 'border-stone-200 text-stone-600 hover:bg-stone-50'
            }`}
          >
            ☀️ Summer (March - June)
          </button>
          <button
            onClick={() => setSelectedSeason('winter')}
            className={`p-3 sm:p-4 rounded-2xl border-2 font-bold text-xs sm:text-sm transition-all text-center ${
              selectedSeason === 'winter'
                ? 'border-[#154D34] bg-emerald-50 text-[#154D34]'
                : 'border-stone-200 text-stone-600 hover:bg-stone-50'
            }`}
          >
            ❄️ Winter (Nov - Feb)
          </button>
        </div>

        {/* Seasonal Content */}
        <div className="bg-stone-50 p-6 rounded-2xl border border-stone-200 text-xs sm:text-sm leading-relaxed text-stone-700 space-y-3">
          {selectedSeason === 'monsoon' && (
            <>
              <h3 className="font-bold text-[#154D34] text-base">
                Monsoon Care: Drainage is King
              </h3>
              <p>
                During Indian monsoons, the biggest threat to balcony plants is waterlogging, leading to root rot. Ensure nursery pots have unobstructed drainage holes. Elevate pots using pot stands or bricks.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="bg-white p-3 rounded-xl border border-stone-200">
                  <span className="font-bold text-emerald-800 block mb-1">✓ Recommended</span>
                  <p className="text-xs text-stone-600">
                    Apply Neem cake powder to soil surface to prevent soil fungus and fungal gnats.
                  </p>
                </div>
                <div className="bg-white p-3 rounded-xl border border-stone-200">
                  <span className="font-bold text-rose-700 block mb-1">⚠️ Avoid</span>
                  <p className="text-xs text-stone-600">
                    Do not let saucers retain stagnant rainwater as it attracts mosquitoes and chokes roots.
                  </p>
                </div>
              </div>
            </>
          )}

          {selectedSeason === 'summer' && (
            <>
              <h3 className="font-bold text-[#154D34] text-base">
                Summer Care: Beat The 40°C Scorching Heat
              </h3>
              <p>
                In Indian peak summers, high temperatures and dry winds dehydrate leaves within hours. Move delicate foliage like Peace Lilies and Ferns away from west-facing afternoon sun.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="bg-white p-3 rounded-xl border border-stone-200">
                  <span className="font-bold text-emerald-800 block mb-1">✓ Water Early Morning</span>
                  <p className="text-xs text-stone-600">
                    Water thoroughly before 8:00 AM so soil remains hydrated before peak afternoon sun hits.
                  </p>
                </div>
                <div className="bg-white p-3 rounded-xl border border-stone-200">
                  <span className="font-bold text-emerald-800 block mb-1">✓ Cocopeat Mulching</span>
                  <p className="text-xs text-stone-600">
                    Add a 1-inch layer of moist cocopeat or dried leaves on topsoil to trap moisture.
                  </p>
                </div>
              </div>
            </>
          )}

          {selectedSeason === 'winter' && (
            <>
              <h3 className="font-bold text-[#154D34] text-base">
                Winter Care: Dormancy & Morning Sun
              </h3>
              <p>
                Most tropical plants slow down growth in winter. Reduce watering frequency substantially. Always test the soil with your index finger—water only if the top 2 inches are completely dry.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="bg-white p-3 rounded-xl border border-stone-200">
                  <span className="font-bold text-emerald-800 block mb-1">✓ Maximize Sunlight</span>
                  <p className="text-xs text-stone-600">
                    Move your Mogra, Roses and Hibiscus into direct morning sun for blooming energy.
                  </p>
                </div>
                <div className="bg-white p-3 rounded-xl border border-stone-200">
                  <span className="font-bold text-rose-700 block mb-1">⚠️ Halt Chemical Fertilizers</span>
                  <p className="text-xs text-stone-600">
                    Avoid heavy fertilizing during dormancy; gentle vermicompost once in two months is ample.
                  </p>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Special Section: Tulsi & Holy Plants Care */}
      <div className="bg-amber-50/70 rounded-3xl p-6 sm:p-8 border border-amber-200 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-amber-200 flex items-center justify-center text-amber-900 font-bold text-lg">
            ॐ
          </div>
          <div>
            <h3 className="text-lg font-serif font-bold text-stone-900">
              Sacred Tulsi (Holy Basil) Care Protocol
            </h3>
            <p className="text-xs text-stone-600">
              Keep your Tulsi plant green, bushy and healthy throughout the year
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-stone-700 pt-2">
          <div className="bg-white p-4 rounded-xl border border-amber-200 shadow-xs">
            <span className="font-bold text-amber-900 block mb-1">1. Pinch The Manjari (Seed Spikes)</span>
            <p className="text-stone-600">
              When seed heads (manjari) appear, pinch them off gently with clean fingers. This stops the plant from maturing and stimulates lush fresh green leaves.
            </p>
          </div>

          <div className="bg-white p-4 rounded-xl border border-amber-200 shadow-xs">
            <span className="font-bold text-amber-900 block mb-1">2. Morning Sunlight & Fresh Air</span>
            <p className="text-stone-600">
              Tulsi requires a minimum of 4-5 hours of direct morning sunlight. East or North-East balconies (Ishan Kona) are ideal for healthy growth according to Vastu.
            </p>
          </div>

          <div className="bg-white p-4 rounded-xl border border-amber-200 shadow-xs">
            <span className="font-bold text-amber-900 block mb-1">3. Natural Turmeric Soil Dressing</span>
            <p className="text-stone-600">
              Sprinkle half a teaspoon of kitchen turmeric (haldi) around the soil roots once a month. Turmeric acts as a sacred natural anti-fungal and ant-repellent.
            </p>
          </div>
        </div>
      </div>

      {/* Interactive AI Plant Doctor Consultation Engine */}
      <div id="ai-plant-doctor" className="bg-gradient-to-br from-emerald-900 via-[#154D34] to-[#0D3222] text-white rounded-3xl p-6 sm:p-10 shadow-xl space-y-6 relative overflow-hidden">
        {/* Subtle decorative background botanical shape */}
        <div className="absolute -right-10 -bottom-10 opacity-10 pointer-events-none">
          <Leaf className="w-80 h-80 text-white" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-emerald-700/50 pb-6">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 bg-emerald-800/80 border border-emerald-600/50 px-3 py-1 rounded-full text-[11px] font-bold tracking-wider text-emerald-200">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>GEMINI 2.5 FLASH BOTANICAL AI</span>
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight">
              Prakriti AI Plant Doctor (प्रकृति एआई वनस्पति डॉक्टर)
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100/80 max-w-2xl leading-relaxed">
              Ask our certified AI horticulturist any question about sick houseplants, pest attacks, yellowing leaves, or seasonal balcony care tailored for Indian weather.
            </p>
          </div>

          {/* Language Selector */}
          <div className="flex items-center gap-1.5 bg-emerald-950/60 p-1 rounded-2xl border border-emerald-700/60 self-start md:self-auto shrink-0">
            <button
              onClick={() => setAiLang('en')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                aiLang === 'en' ? 'bg-emerald-600 text-white shadow-xs' : 'text-emerald-200 hover:text-white'
              }`}
            >
              English
            </button>
            <button
              onClick={() => setAiLang('hi')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                aiLang === 'hi' ? 'bg-emerald-600 text-white shadow-xs' : 'text-emerald-200 hover:text-white'
              }`}
            >
              हिन्दी
            </button>
            <button
              onClick={() => setAiLang('mr')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                aiLang === 'mr' ? 'bg-emerald-600 text-white shadow-xs' : 'text-emerald-200 hover:text-white'
              }`}
            >
              मराठी
            </button>
          </div>
        </div>

        {/* Plant & Symptom Pickers */}
        <div className="relative z-10 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-emerald-200 uppercase tracking-wider mb-2">
              1. Select Plant (पौधा चुनें / रोप निवडा):
            </label>
            <div className="flex flex-wrap gap-2">
              {POPULAR_PLANTS.map((plant) => (
                <button
                  key={plant}
                  type="button"
                  onClick={() => setSelectedPlantCategory(plant)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                    selectedPlantCategory === plant
                      ? 'bg-white text-[#154D34] font-bold shadow-sm'
                      : 'bg-emerald-800/60 text-emerald-100 hover:bg-emerald-700/60 border border-emerald-700/40'
                  }`}
                >
                  {plant}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-emerald-200 uppercase tracking-wider mb-2">
              2. Quick Symptoms (लक्षण / समस्या):
            </label>
            <div className="flex flex-wrap gap-2">
              {COMMON_SYMPTOMS.map((symptom) => (
                <button
                  key={symptom}
                  type="button"
                  onClick={() => {
                    setSelectedSymptomPreset(symptom);
                    setPlantQuery(`My ${selectedPlantCategory} is showing: ${symptom}. Please diagnose and provide organic remedies.`);
                  }}
                  className={`px-3 py-1 rounded-full text-xs transition-all ${
                    selectedSymptomPreset === symptom
                      ? 'bg-amber-400 text-stone-900 font-bold'
                      : 'bg-emerald-950/50 text-emerald-200 hover:bg-emerald-800/40 border border-emerald-800/60'
                  }`}
                >
                  {symptom}
                </button>
              ))}
            </div>
          </div>

          {/* Query Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleConsultDoctor();
            }}
            className="pt-2"
          >
            <div className="relative flex items-center">
              <input
                type="text"
                value={plantQuery}
                onChange={(e) => setPlantQuery(e.target.value)}
                placeholder={`Describe issue with your ${selectedPlantCategory || 'plant'} or ask anything...`}
                className="w-full pl-4 pr-32 py-3.5 bg-white/10 hover:bg-white/15 focus:bg-white text-stone-900 placeholder:text-emerald-200/70 focus:placeholder:text-stone-400 text-sm rounded-2xl border border-emerald-500/40 focus:border-white focus:ring-4 focus:ring-emerald-400/20 outline-none transition-all focus:text-stone-900"
              />
              <button
                type="submit"
                disabled={consultationLoading || (!plantQuery.trim() && !selectedSymptomPreset)}
                className="absolute right-2 px-4 py-2 bg-amber-400 hover:bg-amber-300 disabled:bg-stone-500 text-stone-900 font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed"
              >
                {consultationLoading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Analyzing...</span>
                  </>
                ) : (
                  <>
                    <Bot className="w-3.5 h-3.5" />
                    <span>Consult Doctor</span>
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Quick FAQ Prompts */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
            <span className="text-[11px] font-semibold text-emerald-300 shrink-0">Try asking:</span>
            {QUICK_PROMPTS.map((prompt, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setPlantQuery(prompt);
                  handleConsultDoctor(prompt);
                }}
                className="whitespace-nowrap px-2.5 py-1 rounded-lg text-[11px] bg-emerald-950/40 hover:bg-emerald-900/60 text-emerald-200 border border-emerald-700/40 transition-colors"
              >
                "{prompt}"
              </button>
            ))}
          </div>

          {/* Consultation Error */}
          {consultationError && (
            <div className="p-4 rounded-2xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs">
              ⚠️ {consultationError}
            </div>
          )}

          {/* Doctor Advisory Result Box */}
          {doctorResponse && (
            <div className="mt-4 p-6 bg-white text-stone-900 rounded-2xl shadow-xl border border-emerald-300 space-y-4 animate-in fade-in zoom-in-95 duration-200">
              <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-[#154D34]">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-stone-900">
                      Prakriti Botanical Prescription ({selectedPlantCategory})
                    </h3>
                    <span className="text-[10px] text-emerald-700 font-medium">
                      Verified by {consultationSource || 'Gemini Horticultural AI'}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setDoctorResponse(null)}
                  className="text-xs text-stone-400 hover:text-stone-700 font-medium"
                >
                  Clear
                </button>
              </div>

              <div className="text-xs sm:text-sm text-stone-700 leading-relaxed whitespace-pre-line font-sans">
                {doctorResponse}
              </div>

              <div className="bg-emerald-50 rounded-xl p-3 border border-emerald-100 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="text-xs text-emerald-900">
                  <span className="font-bold">🌿 Recommended Organic Care:</span> Pure Cold-Pressed Neem Oil & Enriched Vermicompost
                </div>
                <button
                  onClick={() => navigateTo('catalog', { categorySlug: 'fertilizers-plant-care' })}
                  className="px-4 py-2 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-lg text-xs font-bold transition-colors shrink-0"
                >
                  Order Organic Medicines & Care →
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Common Plant Problems & Organic Home Remedies */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-xs space-y-6">
        <h3 className="font-serif text-xl font-bold text-stone-900">
          Plant Doctor: Common Symptoms & Organic Solutions
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-1.5">
            <div className="flex items-center gap-2 text-rose-700 font-bold text-sm">
              <AlertTriangle className="w-4 h-4" />
              <span>Yellowing Lower Leaves</span>
            </div>
            <p className="text-stone-700 font-medium">
              <strong>Cause:</strong> Overwatering and soggy soil, leading to suffocated roots.
            </p>
            <p className="text-stone-500">
              <strong>Remedy:</strong> Stop watering until top 2 inches dry out. Loosen the topsoil with a fork to allow air circulation into the root zone.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-1.5">
            <div className="flex items-center gap-2 text-amber-700 font-bold text-sm">
              <Bug className="w-4 h-4" />
              <span>White Sticky Cotton (Mealybugs)</span>
            </div>
            <p className="text-stone-700 font-medium">
              <strong>Cause:</strong> Mealybug infestation common on Hibiscus and Succulents.
            </p>
            <p className="text-stone-500">
              <strong>Remedy:</strong> Mix 5ml Cold-Pressed Neem Oil + 2 drops of mild liquid soap in 1 liter of warm water. Spray every 4 days on undersides of leaves.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-1.5">
            <div className="flex items-center gap-2 text-stone-700 font-bold text-sm">
              <Sun className="w-4 h-4 text-amber-500" />
              <span>Crispy Brown Leaf Tips</span>
            </div>
            <p className="text-stone-700 font-medium">
              <strong>Cause:</strong> Low humidity from ceiling fans or AC air in apartments.
            </p>
            <p className="text-stone-500">
              <strong>Remedy:</strong> Group plants together to create a humid microclimate. Mist leaves lightly twice a week in the mornings.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-1.5">
            <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm">
              <Sprout className="w-4 h-4 text-emerald-600" />
              <span>Pale Leaves with Stunted Growth</span>
            </div>
            <p className="text-stone-700 font-medium">
              <strong>Cause:</strong> Soil nutrient depletion after months in nursery pot.
            </p>
            <p className="text-stone-500">
              <strong>Remedy:</strong> Top-dress with 2 handfuls of rich Organic Vermicompost (केंचुआ खाद) and water gently.
            </p>
          </div>
        </div>

        <div className="text-center pt-4">
          <button
            onClick={() => navigateTo('catalog', { categorySlug: 'fertilizers-plant-care' })}
            className="px-6 py-3 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-full text-xs sm:text-sm font-bold shadow-md transition-colors inline-flex items-center gap-2"
          >
            <span>Shop Organic Neem Oil & Vermicompost</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
