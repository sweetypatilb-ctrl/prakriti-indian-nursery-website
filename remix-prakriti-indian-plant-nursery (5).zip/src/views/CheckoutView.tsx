import React, { useState } from 'react';
import {
  ShieldCheck,
  Truck,
  CreditCard,
  QrCode,
  Banknote,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Building,
  MapPin,
  Phone,
  User,
  Sparkles,
  Gift,
  AlertCircle,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../context/AppContext';
import { Address, Order } from '../types';
import { SafeImage } from '../components/SafeImage';

export const CheckoutView: React.FC = () => {
  const {
    cart,
    cartTotal,
    cartSubtotal,
    appliedCoupon,
    settings,
    currentUser,
    addOrder,
    clearCart,
    navigateTo,
    openAuthModal,
    refreshData,
    t,
  } = useApp();

  // Address form fields
  const [name, setName] = useState(currentUser?.name || '');
  const [mobile, setMobile] = useState(currentUser?.mobile || '');
  const [alternateMobile, setAlternateMobile] = useState('');
  const [pincode, setPincode] = useState('400001');
  const [flatBuilding, setFlatBuilding] = useState('');
  const [streetArea, setStreetArea] = useState('');
  const [landmark, setLandmark] = useState('');
  const [city, setCity] = useState('Mumbai');
  const [state, setState] = useState('Maharashtra');
  const [addressType, setAddressType] = useState<'home' | 'office' | 'other'>('home');

  // Delivery & payment selection
  const [deliverySpeed, setDeliverySpeed] = useState<'standard' | 'express'>('standard');
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'COD' | 'Card' | 'NetBanking'>('UPI');
  const [upiId, setUpiId] = useState('');
  const [giftNote, setGiftNote] = useState('');
  const [orderNotes, setOrderNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const [simulatedModal, setSimulatedModal] = useState<{ open: boolean; orderData: any } | null>(null);

  // Address lookup helper for pincode
  const handlePincodeChange = (pin: string) => {
    const clean = pin.replace(/\D/g, '');
    setPincode(clean);
    if (clean.length === 6) {
      const prefix = clean.substring(0, 2);
      if (prefix === '40') {
        setCity('Mumbai');
        setState('Maharashtra');
      } else if (prefix === '41') {
        setCity('Pune');
        setState('Maharashtra');
      } else if (prefix === '11') {
        setCity('New Delhi');
        setState('Delhi NCR');
      } else if (prefix === '56') {
        setCity('Bengaluru');
        setState('Karnataka');
      } else if (prefix === '50') {
        setCity('Hyderabad');
        setState('Telangana');
      } else if (prefix === '60') {
        setCity('Chennai');
        setState('Tamil Nadu');
      } else if (prefix === '70') {
        setCity('Kolkata');
        setState('West Bengal');
      } else if (prefix === '38') {
        setCity('Ahmedabad');
        setState('Gujarat');
      }
    }
  };

  // Indian States
  const indianStates = [
    'Maharashtra',
    'Karnataka',
    'Delhi NCR',
    'Telangana',
    'Tamil Nadu',
    'Gujarat',
    'West Bengal',
    'Rajasthan',
    'Uttar Pradesh',
    'Kerala',
    'Punjab',
    'Madhya Pradesh',
    'Haryana',
    'Goa',
    'Andhra Pradesh',
    'Bihar',
    'Odisha',
  ];

  // 100% Guaranteed Safe Financial Calculations
  const computedSubtotal = (Array.isArray(cart) ? cart : []).reduce((sum, item) => {
    if (!item || !item.product) return sum;
    const rawPrice = item.product.price ?? (item.product as any)?.priceInINR ?? 0;
    const price = typeof rawPrice === 'number' && Number.isFinite(rawPrice)
      ? rawPrice
      : (parseFloat(String(rawPrice).replace(/[^\d.-]/g, '')) || 0);
    const qty = Number(item.quantity) || 1;
    const line = price * qty;
    return sum + (Number.isFinite(line) ? line : 0);
  }, 0);

  const effectiveCartTotal = (typeof cartTotal === 'number' && Number.isFinite(cartTotal) && cartTotal >= 0)
    ? cartTotal
    : (typeof cartSubtotal === 'number' && Number.isFinite(cartSubtotal) && cartSubtotal >= 0)
      ? cartSubtotal
      : computedSubtotal;

  const freeDeliveryThreshold = Number(settings?.freeDeliveryThreshold ?? settings?.freeShippingThreshold) || 999;
  const isFreeDelivery = effectiveCartTotal >= freeDeliveryThreshold;
  const standardFee = Number(settings?.standardDeliveryCharge ?? settings?.standardShippingFee) || 99;
  const baseDelivery = isFreeDelivery ? 0 : standardFee;
  const expressSurcharge = deliverySpeed === 'express' ? 99 : 0;
  const totalShipping = baseDelivery + expressSurcharge;

  let couponDiscount = 0;
  if (appliedCoupon && effectiveCartTotal > 0) {
    const discVal = Number(appliedCoupon.discountValue) || 0;
    if (appliedCoupon.discountType === 'percentage') {
      couponDiscount = Math.round((effectiveCartTotal * discVal) / 100);
      if (appliedCoupon.maxDiscount) {
        couponDiscount = Math.min(couponDiscount, Number(appliedCoupon.maxDiscount) || couponDiscount);
      }
    } else {
      couponDiscount = Math.min(effectiveCartTotal, discVal);
    }
  }
  couponDiscount = Number.isFinite(couponDiscount) ? Math.max(0, couponDiscount) : 0;

  const finalTotal = Math.max(0, effectiveCartTotal - couponDiscount + totalShipping);
  const gstRate = Number(settings?.gstRate) || 0;
  const taxableAmount = Math.max(0, effectiveCartTotal - couponDiscount);
  const gstAmount = gstRate > 0 ? Math.round((taxableAmount * gstRate) / (100 + gstRate)) : 0;

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutError(null);

    if (!name || !mobile || !pincode || !flatBuilding || !streetArea) {
      setCheckoutError('Please fill in all mandatory address fields marked with (*).');
      return;
    }

    if (mobile.replace(/\D/g, '').length < 10) {
      setCheckoutError('Please enter a valid 10-digit Indian contact number.');
      return;
    }

    setIsSubmitting(true);

    const fullAddress: Address = {
      id: 'addr_' + Date.now(),
      name: name.trim(),
      mobile: mobile.trim(),
      addressLine: `${flatBuilding.trim()}, ${streetArea.trim()}`,
      landmark: landmark.trim(),
      city: city.trim(),
      state: state.trim(),
      pincode: pincode.trim(),
      type: addressType,
      isDefault: true,
    };

    const customerInfo = {
      userId: currentUser?.uid || currentUser?.id || 'guest',
      name: name.trim(),
      email: currentUser?.email || 'customer@prakritinursery.in',
      mobile: mobile.trim(),
    };

    try {
      // 1. Cash on Delivery (COD) Flow
      if (paymentMethod === 'COD') {
        const resp = await fetch('/api/create-cod-order', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            items: cart.map((item) => ({
              productId: item.product.id,
              quantity: item.quantity,
            })),
            customerInfo,
            shippingAddress: fullAddress,
            couponCode: appliedCoupon?.code,
            deliverySpeed,
            notes: orderNotes + (giftNote ? ` [Gift Message: ${giftNote}]` : ''),
          }),
        });

        const data = await resp.json();
        if (!resp.ok) {
          throw new Error(data.error || 'Failed to place Cash on Delivery order.');
        }

        await addOrder(data.order);
        await refreshData();
        clearCart();
        setIsSubmitting(false);

        try {
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#154D34', '#25D366', '#FFB703', '#FFFFFF'],
          });
        } catch {}

        navigateTo('order-confirmation', { orderId: data.orderId });
        return;
      }

      // 2. Online Payment Flow (Razorpay UPI, Card, NetBanking)
      const orderResp = await fetch('/api/create-razorpay-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cart.map((item) => ({
            productId: item.product.id,
            quantity: item.quantity,
          })),
          customerInfo,
          shippingAddress: fullAddress,
          couponCode: appliedCoupon?.code,
          deliverySpeed,
          notes: orderNotes + (giftNote ? ` [Gift Message: ${giftNote}]` : ''),
        }),
      });

      const orderData = await orderResp.json();
      if (!orderResp.ok) {
        throw new Error(orderData.error || 'Failed to initialize payment.');
      }

      const hasRazorpayWindow = typeof (window as any).Razorpay === 'function';

      if (!orderData.isSimulated && hasRazorpayWindow) {
        const options = {
          key: orderData.keyId,
          amount: orderData.amount,
          currency: 'INR',
          name: 'Prakriti Indian Plant Nursery',
          description: `Order #${orderData.orderId} - Live Plant Botanical Shipment`,
          image: 'https://images.unsplash.com/photo-1545241047-6083a3684587?auto=format&fit=crop&w=200&q=80',
          order_id: orderData.razorpayOrderId,
          prefill: {
            name: name.trim(),
            email: currentUser?.email || 'customer@prakritinursery.in',
            contact: mobile.trim(),
          },
          notes: {
            orderId: orderData.orderId,
          },
          theme: {
            color: '#154D34',
          },
          handler: async function (paymentResponse: any) {
            try {
              // Server-side Signature Verification & Atomic Stock Reduction
              const verifyResp = await fetch('/api/verify-payment', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  razorpay_order_id: paymentResponse.razorpay_order_id || orderData.razorpayOrderId,
                  razorpay_payment_id: paymentResponse.razorpay_payment_id,
                  razorpay_signature: paymentResponse.razorpay_signature,
                  orderId: orderData.orderId,
                }),
              });

              const verifyData = await verifyResp.json();
              if (!verifyResp.ok) {
                throw new Error(verifyData.error || 'Server signature verification failed.');
              }

              await refreshData();
              clearCart();
              setIsSubmitting(false);

              try {
                confetti({
                  particleCount: 100,
                  spread: 70,
                  origin: { y: 0.6 },
                  colors: ['#154D34', '#25D366', '#FFB703', '#FFFFFF'],
                });
              } catch {}

              navigateTo('order-confirmation', { orderId: orderData.orderId });
            } catch (verErr: any) {
              setCheckoutError(verErr.message || 'Signature verification error.');
              setIsSubmitting(false);
            }
          },
          modal: {
            ondismiss: async function () {
              setIsSubmitting(false);
              await fetch('/api/payment-failed', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  orderId: orderData.orderId,
                  reason: 'Customer dismissed the Razorpay checkout window.',
                  razorpay_order_id: orderData.razorpayOrderId,
                }),
              }).catch(() => null);
            },
          },
        };

        const rzp = new (window as any).Razorpay(options);
        rzp.on('payment.failed', async function (failedResp: any) {
          setIsSubmitting(false);
          setCheckoutError(`Payment failed: ${failedResp.error?.description || 'Transaction was declined by bank.'}`);
          await fetch('/api/payment-failed', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              orderId: orderData.orderId,
              reason: failedResp.error?.description || 'Transaction failed',
              razorpay_order_id: orderData.razorpayOrderId,
            }),
          }).catch(() => null);
        });

        rzp.open();
      } else {
        // Safe interactive modal for test environment or before user sets live keys
        setSimulatedModal({ open: true, orderData });
        setIsSubmitting(false);
      }
    } catch (err: any) {
      console.error('Checkout error:', err);
      setCheckoutError(err.message || 'Error processing checkout.');
      setIsSubmitting(false);
    }
  };

  const handleConfirmSimulatedPayment = async () => {
    if (!simulatedModal?.orderData) return;
    setIsSubmitting(true);
    try {
      const verifyResp = await fetch('/api/verify-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          razorpay_order_id: simulatedModal.orderData.razorpayOrderId,
          razorpay_payment_id: 'pay_simulated_' + Math.random().toString(36).substring(2, 12),
          razorpay_signature: 'simulated_signature_valid',
          orderId: simulatedModal.orderData.orderId,
        }),
      });

      const verifyData = await verifyResp.json();
      if (!verifyResp.ok) {
        throw new Error(verifyData.error || 'Verification failed');
      }

      const confirmedId = simulatedModal.orderData.orderId;
      setSimulatedModal(null);
      await refreshData();
      clearCart();
      setIsSubmitting(false);

      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#154D34', '#25D366', '#FFB703', '#FFFFFF'],
        });
      } catch {}

      navigateTo('order-confirmation', { orderId: confirmedId });
    } catch (err: any) {
      setCheckoutError(err.message || 'Simulation payment error.');
      setIsSubmitting(false);
    }
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <h2 className="text-xl font-bold text-stone-900">Your cart is empty</h2>
        <button
          onClick={() => navigateTo('catalog')}
          className="mt-4 px-6 py-2.5 bg-[#154D34] text-white rounded-full text-xs font-semibold"
        >
          Browse Plants
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Top Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-stone-500 mb-6">
        <button
          onClick={() => navigateTo('cart')}
          className="flex items-center gap-1 hover:text-[#154D34]"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Cart</span>
        </button>
        <span>/</span>
        <span className="font-semibold text-stone-800">Secure Indian Checkout</span>
      </div>

      {/* Sign In / Sign Up Prompt Banner for Guest Users */}
      {!currentUser && (
        <div className="mb-6 p-4 sm:p-5 bg-emerald-50/90 border border-emerald-200 rounded-3xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#154D34] text-white flex items-center justify-center shrink-0 shadow-xs">
              <User className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-stone-900">
                Already a Plant Parent or want to register?
              </p>
              <p className="text-[11px] text-stone-600">
                Sign In or Sign Up to connect this order to your account, track nursery dispatch & download tax invoices.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 self-stretch sm:self-auto shrink-0">
            <button
              type="button"
              onClick={() => navigateTo('login')}
              className="flex-1 sm:flex-initial px-4 py-2 bg-white hover:bg-stone-50 text-stone-800 border border-stone-300 rounded-xl text-xs font-bold transition-colors shadow-2xs text-center"
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => navigateTo('register')}
              className="flex-1 sm:flex-initial px-4 py-2 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs font-bold transition-colors shadow-xs text-center"
            >
              Sign Up
            </button>
          </div>
        </div>
      )}

      {checkoutError && (
        <div className="mb-6 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-3 shadow-xs">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
          <div className="flex-1">
            <p className="font-bold">Checkout Notice</p>
            <p className="mt-0.5">{checkoutError}</p>
          </div>
          <button
            type="button"
            onClick={() => setCheckoutError(null)}
            className="text-rose-500 hover:text-rose-800 font-bold ml-2 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Form: Delivery Address & Payment */}
        <div className="lg:col-span-8 space-y-8">
          {/* Section 1: Shipping Address */}
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-emerald-100 text-[#154D34] flex items-center justify-center font-bold text-xs">
                  1
                </div>
                <h2 className="font-bold text-stone-900 text-base">
                  {t('shippingAddress')}
                </h2>
              </div>
              <span className="text-xs text-emerald-700 font-semibold">
                ✓ Pan-India Delivery
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Full Name *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Recipient's Name"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                  />
                  <User className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Mobile Number (+91) *
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                    placeholder="10-digit mobile number"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                  />
                  <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Pincode *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={pincode}
                    onChange={(e) => handlePincodeChange(e.target.value)}
                    placeholder="6-digit Indian pincode"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                  />
                  <MapPin className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Alternate Mobile (Optional)
                </label>
                <input
                  type="tel"
                  maxLength={10}
                  value={alternateMobile}
                  onChange={(e) => setAlternateMobile(e.target.value.replace(/\D/g, ''))}
                  placeholder="Secondary phone"
                  className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-stone-700 mb-1">
                  Flat / House No. / Building Name *
                </label>
                <input
                  type="text"
                  required
                  value={flatBuilding}
                  onChange={(e) => setFlatBuilding(e.target.value)}
                  placeholder="Flat 402, Lotus Residency, Near Sai Temple"
                  className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-stone-700 mb-1">
                  Street / Area / Sector / Colony *
                </label>
                <input
                  type="text"
                  required
                  value={streetArea}
                  onChange={(e) => setStreetArea(e.target.value)}
                  placeholder="Shivaji Nagar / Baner Road"
                  className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Landmark (Optional)
                </label>
                <input
                  type="text"
                  value={landmark}
                  onChange={(e) => setLandmark(e.target.value)}
                  placeholder="Opposite D-Mart, Behind Metro station"
                  className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  City / District *
                </label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="City"
                  className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  State *
                </label>
                <select
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:outline-none focus:border-[#154D34]"
                >
                  {indianStates.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Address Type
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAddressType('home')}
                    className={`py-2 rounded-xl font-bold border transition-colors ${
                      addressType === 'home'
                        ? 'bg-emerald-50 border-[#154D34] text-[#154D34]'
                        : 'bg-stone-50 border-stone-200 text-stone-600'
                    }`}
                  >
                    🏠 Home (All Days)
                  </button>
                  <button
                    type="button"
                    onClick={() => setAddressType('office')}
                    className={`py-2 rounded-xl font-bold border transition-colors ${
                      addressType === 'office'
                        ? 'bg-emerald-50 border-[#154D34] text-[#154D34]'
                        : 'bg-stone-50 border-stone-200 text-stone-600'
                    }`}
                  >
                    🏢 Office (10-6)
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Delivery Speed */}
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-stone-100">
              <div className="w-7 h-7 rounded-full bg-emerald-100 text-[#154D34] flex items-center justify-center font-bold text-xs">
                2
              </div>
              <h2 className="font-bold text-stone-900 text-base">Select Delivery Speed</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <label
                onClick={() => setDeliverySpeed('standard')}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                  deliverySpeed === 'standard'
                    ? 'border-[#154D34] bg-emerald-50/50'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-sm text-stone-900">Standard Plant Courier</span>
                    <span className="text-xs font-bold text-emerald-800">
                      {isFreeDelivery ? 'FREE' : '₹99'}
                    </span>
                  </div>
                  <p className="text-xs text-stone-500">Delivered within 3-4 business days.</p>
                </div>
                <div className="mt-3 flex items-center gap-1 text-[11px] text-emerald-700 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Ventilated 5-layer plant cylinder</span>
                </div>
              </label>

              <label
                onClick={() => setDeliverySpeed('express')}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                  deliverySpeed === 'express'
                    ? 'border-[#154D34] bg-emerald-50/50'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-sm text-stone-900">Express Priority Air</span>
                    <span className="text-xs font-bold text-stone-900">
                      {isFreeDelivery ? '₹99' : '₹198'}
                    </span>
                  </div>
                  <p className="text-xs text-stone-500">Fast 1-2 business days delivery.</p>
                </div>
                <div className="mt-3 flex items-center gap-1 text-[11px] text-amber-700 font-medium">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Recommended for sensitive flowering plants</span>
                </div>
              </label>
            </div>
          </div>

          {/* Section 3: Indian Payment Options */}
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-stone-100">
              <div className="w-7 h-7 rounded-full bg-emerald-100 text-[#154D34] flex items-center justify-center font-bold text-xs">
                3
              </div>
              <h2 className="font-bold text-stone-900 text-base">
                {t('selectPaymentMethod')}
              </h2>
            </div>

            <div className="space-y-3">
              {/* Option: UPI */}
              <label
                onClick={() => setPaymentMethod('UPI')}
                className={`block p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  paymentMethod === 'UPI'
                    ? 'border-[#154D34] bg-emerald-50/50'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <QrCode className="w-5 h-5 text-emerald-800" />
                    <div>
                      <span className="font-bold text-sm text-stone-900">
                        UPI (Google Pay, PhonePe, Paytm, BHIM)
                      </span>
                      <p className="text-xs text-stone-500">Fast, instant & zero transaction fee</p>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                    Popular
                  </span>
                </div>

                {paymentMethod === 'UPI' && (
                  <div className="mt-4 pt-3 border-t border-emerald-200/60 space-y-2">
                    <label className="block text-xs font-semibold text-stone-700">
                      Enter your UPI ID (e.g. yourname@oksbi or 9876543210@paytm)
                    </label>
                    <input
                      type="text"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      placeholder="yourname@okhdfcbank"
                      className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs font-mono"
                    />
                    <p className="text-[11px] text-stone-400">
                      Or scan QR code on the next confirmation screen.
                    </p>
                  </div>
                )}
              </label>

              {/* Option: Cash on Delivery (COD) */}
              <label
                onClick={() => setPaymentMethod('COD')}
                className={`block p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  paymentMethod === 'COD'
                    ? 'border-[#154D34] bg-emerald-50/50'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Banknote className="w-5 h-5 text-amber-700" />
                    <div>
                      <span className="font-bold text-sm text-stone-900">
                        Cash on Delivery (COD)
                      </span>
                      <p className="text-xs text-stone-500">Pay cash or UPI to delivery agent</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-emerald-700">Available</span>
                </div>

                {paymentMethod === 'COD' && (
                  <div className="mt-3 text-xs text-amber-900 bg-amber-50 p-3 rounded-xl border border-amber-200">
                    ℹ️ To prevent plant distress, please ensure someone is present at your delivery address to receive live potted plants.
                  </div>
                )}
              </label>

              {/* Option: Debit / Credit Card */}
              <label
                onClick={() => setPaymentMethod('Card')}
                className={`block p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  paymentMethod === 'Card'
                    ? 'border-[#154D34] bg-emerald-50/50'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <CreditCard className="w-5 h-5 text-stone-700" />
                  <div>
                    <span className="font-bold text-sm text-stone-900">
                      Debit / Credit Card (RuPay, Visa, Mastercard)
                    </span>
                    <p className="text-xs text-stone-500">All Indian bank debit and credit cards</p>
                  </div>
                </div>
              </label>

              {/* Option: Net Banking */}
              <label
                onClick={() => setPaymentMethod('NetBanking')}
                className={`block p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  paymentMethod === 'NetBanking'
                    ? 'border-[#154D34] bg-emerald-50/50'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Building className="w-5 h-5 text-stone-700" />
                  <div>
                    <span className="font-bold text-sm text-stone-900">
                      Net Banking (50+ Indian Banks)
                    </span>
                    <p className="text-xs text-stone-500">SBI, HDFC, ICICI, Axis, Kotak, PNB & more</p>
                  </div>
                </div>
              </label>
            </div>
          </div>

          {/* Section 4: Gift Message & Order Notes */}
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
            <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
              <Gift className="w-4 h-4 text-emerald-800" />
              <span>Plant Gifting Message (Optional)</span>
            </h3>
            <textarea
              rows={2}
              value={giftNote}
              onChange={(e) => setGiftNote(e.target.value)}
              placeholder="Sending plants as a gift? Add a greeting message for the handwritten card (Free of charge)."
              className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl text-xs focus:bg-white focus:outline-none"
            />
          </div>
        </div>

        {/* Right Sidebar: Order Summary & Place Order CTA */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-5 sticky top-24">
            <h3 className="font-bold text-stone-900 text-base">Order Review ({cart.length} items)</h3>

            {/* Item Mini Thumbnails */}
            <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1 divide-y divide-stone-100 text-xs">
              {cart.map((item) => {
                const itemPrice = Number(item.product?.price ?? (item.product as any)?.priceInINR) || 0;
                const itemQty = Number(item.quantity) || 1;
                const lineTotal = itemPrice * itemQty;
                return (
                  <div key={item.product.id} className="pt-2 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <SafeImage
                        src={item.product.images?.[0]}
                        alt={item.product.name}
                        className="w-10 h-10 rounded-lg object-cover bg-stone-100 shrink-0"
                      />
                      <div>
                        <p className="font-bold text-stone-800 truncate max-w-[140px]">
                          {item.product.name}
                        </p>
                        <p className="text-stone-400">Qty: {itemQty}</p>
                      </div>
                    </div>
                    <span className="font-bold text-stone-900">
                      ₹{lineTotal.toLocaleString('en-IN')}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Calculations */}
            <div className="space-y-2 text-xs text-stone-600 pt-3 border-t border-stone-200">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>₹{effectiveCartTotal.toLocaleString('en-IN')}</span>
              </div>
              {couponDiscount > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Coupon ({appliedCoupon?.code})</span>
                  <span>-₹{couponDiscount.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Shipping ({deliverySpeed})</span>
                <span className={totalShipping === 0 ? 'text-emerald-700 font-bold' : ''}>
                  {totalShipping === 0 ? 'FREE' : `₹${totalShipping.toLocaleString('en-IN')}`}
                </span>
              </div>
              <div className="flex justify-between text-[11px] text-stone-400">
                <span>GST (Tax invoice included)</span>
                <span>₹{gstAmount.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-base font-bold text-stone-900 pt-2 border-t border-stone-200">
                <span>Total Payable</span>
                <span className="text-xl text-[#154D34]">₹{finalTotal.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-2xl text-sm font-bold shadow-md transition-colors flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {isSubmitting ? (
                <span>Generating Order...</span>
              ) : (
                <>
                  <span>{t('placeOrder')}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            <div className="p-3 bg-stone-50 rounded-xl text-[11px] text-stone-500 space-y-1">
              <div className="flex items-center gap-1 text-emerald-700 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Prakriti 100% Plant Freshness Assured</span>
              </div>
              <p>Replacement guarantee if damaged during transit.</p>
            </div>
          </div>
        </div>
      </form>

      {/* Razorpay Simulation & Verification Dialog */}
      {simulatedModal?.open && simulatedModal.orderData && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white max-w-md w-full rounded-3xl p-6 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-emerald-100 text-[#154D34] flex items-center justify-center font-bold text-xs">
                  ₹
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-sm">Razorpay Checkout Ready</h3>
                  <p className="text-[11px] text-stone-500">Order #{simulatedModal.orderData.orderId}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSimulatedModal(null)}
                className="text-stone-400 hover:text-stone-700 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-4 bg-emerald-50/70 rounded-2xl border border-emerald-100 space-y-2 text-xs">
              <div className="flex justify-between font-bold text-stone-900 text-sm">
                <span>Server Verified Total</span>
                <span className="text-[#154D34]">₹{simulatedModal.orderData.totalAmount?.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-stone-500 text-[11px]">
                <span>Subtotal</span>
                <span>₹{simulatedModal.orderData.subtotal?.toLocaleString('en-IN')}</span>
              </div>
              {simulatedModal.orderData.couponDiscount > 0 && (
                <div className="flex justify-between text-emerald-700 text-[11px]">
                  <span>Coupon Applied</span>
                  <span>-₹{simulatedModal.orderData.couponDiscount?.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="flex justify-between text-stone-500 text-[11px]">
                <span>Shipping & Tax</span>
                <span>₹{(Number(simulatedModal.orderData.shippingCharges || 0) + Number(simulatedModal.orderData.gstAmount || 0)).toLocaleString('en-IN')}</span>
              </div>
            </div>

            <p className="text-[11px] text-stone-500 leading-relaxed">
              Razorpay API keys (<code>RAZORPAY_KEY_ID</code> & <code>RAZORPAY_KEY_SECRET</code>) can be provided via environment variables. Click below to execute server-side verification and atomic inventory stock deduction.
            </p>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSimulatedModal(null)}
                className="flex-1 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isSubmitting}
                onClick={handleConfirmSimulatedPayment}
                className="flex-1 py-2.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs font-bold shadow-xs transition-colors disabled:opacity-50 cursor-pointer"
              >
                {isSubmitting ? 'Verifying...' : `Confirm Payment ₹${simulatedModal.orderData.totalAmount?.toLocaleString('en-IN')}`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
