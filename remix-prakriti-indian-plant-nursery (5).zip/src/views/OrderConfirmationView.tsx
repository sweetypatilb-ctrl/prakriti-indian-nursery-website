import React, { useState } from 'react';
import {
  CheckCircle2,
  FileText,
  Truck,
  ArrowRight,
  ShoppingBag,
  MapPin,
  Calendar,
  CreditCard,
  Sprout,
  Share2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { InvoiceModal } from '../components/InvoiceModal';
import { SafeImage } from '../components/SafeImage';

export const OrderConfirmationView: React.FC = () => {
  const { orders, selectedOrderId, navigateTo, t } = useApp();
  const [invoiceOpen, setInvoiceOpen] = useState(false);

  // Find order or take the latest
  const order = orders.find((o) => o.id === selectedOrderId) || orders[0];

  if (!order) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <h2 className="text-xl font-bold text-stone-900">No recent order found</h2>
        <button
          onClick={() => navigateTo('home')}
          className="mt-4 px-6 py-2 bg-[#154D34] text-white rounded-full text-xs font-semibold"
        >
          Go to Home
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Thank you Banner */}
      <div className="bg-emerald-50 border border-emerald-200 rounded-3xl p-6 sm:p-8 text-center space-y-3">
        <div className="w-16 h-16 rounded-full bg-[#154D34] text-white mx-auto flex items-center justify-center shadow-lg animate-bounce duration-1000">
          <CheckCircle2 className="w-9 h-9" />
        </div>

        <h1 className="font-serif text-2xl sm:text-3xl font-extrabold text-[#154D34]">
          {t('orderSuccessTitle')}
        </h1>

        <p className="text-xs sm:text-sm text-stone-600 max-w-md mx-auto">
          {t('orderSuccessSub')}
        </p>

        <div className="inline-flex items-center gap-2 bg-white px-4 py-2 rounded-full border border-emerald-300 shadow-xs text-xs">
          <span className="text-stone-500">Order ID:</span>
          <span className="font-mono font-bold text-stone-900">{order.id}</span>
        </div>
      </div>

      {/* Action Buttons: Invoice & Tracking */}
      <div className="flex flex-wrap items-center justify-center gap-3">
        <button
          onClick={() => setInvoiceOpen(true)}
          className="px-5 py-2.5 bg-white hover:bg-stone-50 text-stone-800 border border-stone-300 rounded-xl text-xs sm:text-sm font-semibold shadow-xs flex items-center gap-2 transition-colors"
        >
          <FileText className="w-4 h-4 text-[#154D34]" />
          <span>{t('downloadInvoice')} (GST)</span>
        </button>

        <button
          onClick={() => navigateTo('account')}
          className="px-5 py-2.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs sm:text-sm font-semibold shadow-xs flex items-center gap-2 transition-colors"
        >
          <Truck className="w-4 h-4" />
          <span>{t('trackOrder')}</span>
        </button>

        <button
          onClick={() => navigateTo('catalog')}
          className="px-5 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs sm:text-sm font-semibold transition-colors"
        >
          {t('continueShopping')}
        </button>
      </div>

      {/* Order Highlights Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Delivery Timeline */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
            <Calendar className="w-4 h-4 text-[#154D34]" />
            <span>Delivery Timeline</span>
          </div>
          <div className="p-3 bg-stone-50 rounded-xl space-y-1 text-xs">
            <p className="text-stone-500">Estimated Delivery:</p>
            <p className="font-bold text-stone-900 text-sm">{order.estimatedDeliveryDate}</p>
            <p className="text-[11px] text-emerald-700 mt-1">
              Courier Partner: {order.courierPartner || 'BlueDart Logistics'}
            </p>
            <p className="text-[11px] text-stone-400">
              Tracking AWB: {order.trackingNumber}
            </p>
          </div>
        </div>

        {/* Shipping Address */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
            <MapPin className="w-4 h-4 text-[#154D34]" />
            <span>Shipping To</span>
          </div>
          <div className="p-3 bg-stone-50 rounded-xl text-xs text-stone-700 space-y-0.5">
            <p className="font-bold text-stone-900">{order.shippingAddress.name}</p>
            <p>{order.shippingAddress.addressLine}</p>
            <p>
              {order.shippingAddress.city}, {order.shippingAddress.state} -{' '}
              <strong className="font-mono">{order.shippingAddress.pincode}</strong>
            </p>
            <p className="text-stone-500 pt-1">Mobile: +91 {order.shippingAddress.mobile}</p>
          </div>
        </div>
      </div>

      {/* Items Summary Table */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-stone-100 font-bold text-stone-900 text-sm flex items-center justify-between">
          <span>Items Ordered ({order.items.length})</span>
          <span className="text-xs text-stone-500 font-normal">Payment: {order.paymentMethod}</span>
        </div>

        <div className="divide-y divide-stone-100">
          {order.items.map((item, idx) => (
            <div key={idx} className="p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <SafeImage
                  src={item.image}
                  alt={item.name}
                  className="w-12 h-12 rounded-xl object-cover bg-stone-100 border border-stone-200 shrink-0"
                />
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-stone-800">{item.name}</h4>
                  <p className="text-[11px] text-stone-400">Qty: {item.quantity}</p>
                </div>
              </div>
              <span className="text-xs sm:text-sm font-bold text-stone-900">
                ₹{item.price * item.quantity}
              </span>
            </div>
          ))}
        </div>

        {/* Totals */}
        <div className="p-5 bg-stone-50/70 border-t border-stone-200 space-y-2 text-xs">
          <div className="flex justify-between text-stone-600">
            <span>Subtotal</span>
            <span>₹{order.subtotal}</span>
          </div>
          {order.couponDiscount > 0 && (
            <div className="flex justify-between text-emerald-700 font-medium">
              <span>Coupon Discount ({order.couponCode})</span>
              <span>-₹{order.couponDiscount}</span>
            </div>
          )}
          <div className="flex justify-between text-stone-600">
            <span>Shipping</span>
            <span>{order.shippingCharges === 0 ? 'FREE' : `₹${order.shippingCharges}`}</span>
          </div>
          <div className="flex justify-between font-bold text-sm text-stone-900 pt-2 border-t border-stone-200">
            <span>Total Paid / Payable</span>
            <span className="text-base text-[#154D34]">₹{order.totalAmount}</span>
          </div>
        </div>
      </div>

      {/* Invoice Modal */}
      {invoiceOpen && <InvoiceModal order={order} onClose={() => setInvoiceOpen(false)} />}
    </div>
  );
};
