import React, { useState } from 'react';
import {
  Tag,
  Copy,
  Check,
  Gift,
  Truck,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  ShoppingBag,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SafeImage } from '../components/SafeImage';

export const OffersView: React.FC = () => {
  const { coupons, navigateTo, t } = useApp();
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-[#154D34] text-white rounded-3xl p-8 sm:p-12 text-center relative overflow-hidden shadow-xl">
        <span className="inline-block px-3 py-1 rounded-full bg-amber-400 text-stone-900 text-xs font-extrabold uppercase tracking-wider mb-3">
          Special Indian Nursery Deals
        </span>
        <h1 className="font-serif text-3xl sm:text-5xl font-extrabold tracking-tight">
          Offers, Coupons & Combo Packs
        </h1>
        <p className="text-xs sm:text-sm text-emerald-100 max-w-xl mx-auto mt-2">
          Save on live air-purifying greens, medicinal herbs, artisan pots and natural fertilizers with our active voucher codes.
        </p>
      </div>

      {/* Available Coupon Cards Grid */}
      <div className="space-y-6">
        <h2 className="font-serif text-2xl font-bold text-stone-900">
          Active Discount Coupons (छूट कूपन)
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {coupons.map((coupon) => (
            <div
              key={coupon.code}
              className="bg-white rounded-2xl border-2 border-dashed border-emerald-300 p-5 shadow-xs flex flex-col justify-between hover:border-[#154D34] transition-colors"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
                    {coupon.discountType === 'percentage' ? `${coupon.discountValue}% Off` : `₹${coupon.discountValue} Off`}
                  </span>
                  <span className="text-[10px] text-stone-400">Valid till {coupon.expiryDate}</span>
                </div>
                <h3 className="font-mono text-xl font-extrabold text-[#154D34] mb-1">
                  {coupon.code}
                </h3>
                <p className="text-xs text-stone-600 mb-3">{coupon.description}</p>
                <div className="text-[11px] text-stone-500 font-medium bg-stone-50 p-2 rounded-lg mb-4">
                  Min Order Value: <strong>₹{coupon.minOrderValue}</strong>
                </div>
              </div>

              <button
                onClick={() => handleCopy(coupon.code)}
                className="w-full py-2 bg-emerald-50 hover:bg-emerald-100 text-[#154D34] border border-emerald-200 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
              >
                {copiedCode === coupon.code ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Copied to Clipboard!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Value Combo Packs */}
      <div className="space-y-6">
        <h2 className="font-serif text-2xl font-bold text-stone-900">
          Handpicked Green Combo Packs
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-3xl border border-stone-200 p-6 shadow-xs flex flex-col justify-between">
            <div>
              <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-stone-100 mb-4">
                <SafeImage
                  src="https://images.unsplash.com/photo-1545241047-6083a3684587?auto=format&fit=crop&w=600&q=80"
                  alt="Air Purifier Trio"
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="text-[11px] font-bold uppercase text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                Save ₹350
              </span>
              <h3 className="font-serif font-bold text-lg text-stone-900 mt-2">
                NASA Air Purifier Trio
              </h3>
              <p className="text-xs text-stone-600 mt-1">
                Snake Plant Laurentii + Money Plant + ZZ Plant in matching eco-friendly white planters.
              </p>
              <div className="flex items-baseline gap-2 mt-3">
                <span className="text-xl font-extrabold text-[#154D34]">₹899</span>
                <span className="text-xs text-stone-400 line-through">₹1,249</span>
              </div>
            </div>
            <button
              onClick={() => navigateTo('catalog')}
              className="mt-5 w-full py-2.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Explore Combo</span>
            </button>
          </div>

          <div className="bg-white rounded-3xl border border-stone-200 p-6 shadow-xs flex flex-col justify-between">
            <div>
              <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-stone-100 mb-4">
                <SafeImage
                  src="https://images.unsplash.com/photo-1614594975525-e45190c55d0b?auto=format&fit=crop&w=600&q=80"
                  alt="Holy Basil and Fragrance"
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="text-[11px] font-bold uppercase text-amber-800 bg-amber-50 px-2 py-0.5 rounded">
                Save ₹250
              </span>
              <h3 className="font-serif font-bold text-lg text-stone-900 mt-2">
                Holy Vastu & Fragrance Duo
              </h3>
              <p className="text-xs text-stone-600 mt-1">
                Sacred Rama Tulsi Plant + Sweet Fragrant Mogra (Arabian Jasmine) with terracotta nursery pots.
              </p>
              <div className="flex items-baseline gap-2 mt-3">
                <span className="text-xl font-extrabold text-[#154D34]">₹449</span>
                <span className="text-xs text-stone-400 line-through">₹699</span>
              </div>
            </div>
            <button
              onClick={() => navigateTo('catalog')}
              className="mt-5 w-full py-2.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Explore Combo</span>
            </button>
          </div>

          <div className="bg-white rounded-3xl border border-stone-200 p-6 shadow-xs flex flex-col justify-between">
            <div>
              <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-stone-100 mb-4">
                <SafeImage
                  src="https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e?auto=format&fit=crop&w=600&q=80"
                  alt="Desi Kitchen Garden Kit"
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="text-[11px] font-bold uppercase text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                Best Seller
              </span>
              <h3 className="font-serif font-bold text-lg text-stone-900 mt-2">
                Desi Kitchen Herb & Seed Starter
              </h3>
              <p className="text-xs text-stone-600 mt-1">
                Potted Curry Leaf Plant + 10 Desi Vegetable seed packets (Palak, Methi, Coriander, Tomato).
              </p>
              <div className="flex items-baseline gap-2 mt-3">
                <span className="text-xl font-extrabold text-[#154D34]">₹399</span>
                <span className="text-xs text-stone-400 line-through">₹599</span>
              </div>
            </div>
            <button
              onClick={() => navigateTo('catalog')}
              className="mt-5 w-full py-2.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Explore Combo</span>
            </button>
          </div>
        </div>
      </div>

      {/* Corporate & Festival Gifting Inquiry Banner */}
      <div className="bg-[#FAF8F5] border border-stone-200 rounded-3xl p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-[#154D34] font-bold text-xs uppercase tracking-wider">
            <Gift className="w-4 h-4" />
            <span>Corporate & Wedding Bulk Gifting</span>
          </div>
          <h3 className="font-serif text-2xl font-bold text-stone-900">
            Gift Green Living This Festive Season
          </h3>
          <p className="text-xs sm:text-sm text-stone-600 max-w-lg leading-relaxed">
            Replace sweets with breathing green plants! Custom branded ceramic planters, jute sleeves and handwritten seed cards for orders above 25 units.
          </p>
        </div>
        <button
          onClick={() => navigateTo('contact')}
          className="px-6 py-3.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-full text-xs sm:text-sm font-bold shadow-md transition-colors shrink-0 flex items-center gap-2"
        >
          <span>Enquire Bulk Corporate Gifting</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
