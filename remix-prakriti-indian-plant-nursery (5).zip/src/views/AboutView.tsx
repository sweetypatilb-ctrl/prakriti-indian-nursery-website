import React from 'react';
import {
  Sprout,
  ShieldCheck,
  Heart,
  Award,
  Users,
  MapPin,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SafeImage } from '../components/SafeImage';

export const AboutView: React.FC = () => {
  const { navigateTo, settings } = useApp();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Hero */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold uppercase tracking-widest text-[#154D34]">
          Our Green Roots
        </span>
        <h1 className="font-serif text-3xl sm:text-5xl font-extrabold text-stone-900 tracking-tight">
          Nurturing India's Living Spaces Since 2018
        </h1>
        <p className="text-xs sm:text-base text-stone-600 leading-relaxed">
          Prakriti Indian Nursery was founded with a single mission: to connect modern Indian urban apartments with resilient, healthy, and sacred plants nurtured in open Indian climate.
        </p>
      </div>

      {/* Visual Story Banner */}
      <div className="relative rounded-3xl overflow-hidden shadow-xl aspect-[16/9] max-h-96 bg-stone-200">
        <SafeImage
          src="https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=1200&q=80"
          alt="Prakriti Nursery Greenhouses"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent flex items-end p-6 sm:p-10">
          <div className="text-white max-w-lg space-y-1">
            <p className="text-xs font-bold uppercase tracking-wider text-emerald-300">
              Pune Polyhouses & Bengaluru Greenhouses
            </p>
            <h2 className="font-serif text-xl sm:text-2xl font-bold">
              Over 20 Acres of Acclimatized Cultivation
            </h2>
          </div>
        </div>
      </div>

      {/* 3 Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-[#154D34] flex items-center justify-center">
            <Sprout className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-stone-900 text-lg">Acclimatized Growth</h3>
          <p className="text-xs text-stone-600 leading-relaxed">
            Unlike plants raised in refrigerated artificial chambers, our plants grow under natural Indian humidity and sun. When they arrive at your home, they don't experience transplant shock.
          </p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-[#154D34] flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-stone-900 text-lg">5-Layer Safe Transit</h3>
          <p className="text-xs text-stone-600 leading-relaxed">
            Our packaging engineers designed corrugated honeycomb cylinders with moist root locks. Live plants breathe comfortably during their 2 to 4-day journey across Indian highways.
          </p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-[#154D34] flex items-center justify-center">
            <Award className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-stone-900 text-lg">Zero Toxic Chemicals</h3>
          <p className="text-xs text-stone-600 leading-relaxed">
            We nourish our soil strictly with aged organic vermicompost, cow dung manure, neem cake, and trichoderma bio-fungicides. Safe for your children and household pets.
          </p>
        </div>
      </div>

      {/* Our Green Mission */}
      <div className="bg-[#FAF8F5] border border-stone-200 rounded-3xl p-8 sm:p-10 space-y-4">
        <h3 className="font-serif text-2xl font-bold text-stone-900">
          Rooted in Indian Heritage & Botany
        </h3>
        <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
          Indian architectural traditions (Vastu Shastra) and Ayurvedic botany have long recognized the physical, emotional and spiritual healing powers of plants. From sacred Rama Tulsi that purifies home energy, to fragrant night-blooming Mogra, to culinary curry leaves that flavor our daily rasam and dal—we celebrate India’s rich green biodiversity.
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-stone-200 text-center">
          <div>
            <span className="text-2xl sm:text-3xl font-extrabold text-[#154D34]">50,000+</span>
            <p className="text-xs text-stone-500 mt-0.5">Indian Homes Greened</p>
          </div>
          <div>
            <span className="text-2xl sm:text-3xl font-extrabold text-[#154D34]">19,000+</span>
            <p className="text-xs text-stone-500 mt-0.5">Pincodes Served</p>
          </div>
          <div>
            <span className="text-2xl sm:text-3xl font-extrabold text-[#154D34]">120+</span>
            <p className="text-xs text-stone-500 mt-0.5">Native Plant Varieties</p>
          </div>
          <div>
            <span className="text-2xl sm:text-3xl font-extrabold text-[#154D34]">99.4%</span>
            <p className="text-xs text-stone-500 mt-0.5">Safe Transit Rate</p>
          </div>
        </div>
      </div>

      <div className="text-center pt-4">
        <button
          onClick={() => navigateTo('catalog')}
          className="px-8 py-3.5 bg-[#154D34] hover:bg-[#0D3222] text-white rounded-full font-bold text-xs sm:text-sm shadow-md transition-colors inline-flex items-center gap-2"
        >
          <span>Explore Our Nursery Catalog</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
