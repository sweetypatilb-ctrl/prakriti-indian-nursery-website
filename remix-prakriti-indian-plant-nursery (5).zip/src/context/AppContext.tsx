import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import {
  Language,
  Product,
  Category,
  CartItem,
  Order,
  Address,
  Coupon,
  Review,
  NurserySettings,
  User,
  OrderStatus,
} from '../types';
import { translations } from '../translations';
import {
  INITIAL_CATEGORIES,
  INITIAL_PRODUCTS,
  INITIAL_COUPONS,
  INITIAL_REVIEWS,
  INITIAL_SETTINGS,
  INITIAL_ADDRESSES,
  INITIAL_ORDERS,
} from '../data/initialData';
import { parseSafePrice, parseSafeQuantity } from '../utils/pricing';

import {
  auth,
  db,
  uploadPlantImage,
} from '../lib/firebase';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updateProfile as updateAuthProfile,
  onAuthStateChanged,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  writeBatch,
} from 'firebase/firestore';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  currency: string;
  products: Product[];
  categories: Category[];
  cart: CartItem[];
  wishlist: string[];
  orders: Order[];
  allOrders: Order[];
  addresses: Address[];
  coupons: Coupon[];
  reviews: Review[];
  settings: NurserySettings;
  user: User | null;
  currentUser: User | null;
  allUsers: User[];
  activeCoupon: Coupon | null;
  currentView: string;
  selectedProductSlug: string | null;
  selectedCategorySlug: string | null;
  trackingOrderId: string | null;
  confirmedOrder: Order | null;
  searchQuery: string;
  authModalOpen: boolean;
  authModalMode: 'login' | 'register' | 'forgot' | 'otp';
  accountActiveTab: 'orders' | 'addresses' | 'wishlist' | 'profile';
  setAccountActiveTab: (tab: 'orders' | 'addresses' | 'wishlist' | 'profile') => void;
  isFirebaseConnected: boolean;
  authLoading: boolean;

  // Navigation & View Actions
  navigateTo: (
    view: string,
    payload?: { productSlug?: string; categorySlug?: string; orderId?: string; accountTab?: 'orders' | 'addresses' | 'wishlist' | 'profile' }
  ) => void;
  setSearchQuery: (query: string) => void;
  openAuthModal: (mode?: 'login' | 'register' | 'forgot' | 'otp') => void;
  closeAuthModal: () => void;

  // Cart & Wishlist Actions
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQty: (productId: string, quantity: number) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  cartTotal: number;
  selectedOrderId: string | null;
  toggleWishlist: (productId: string) => void;
  removeFromWishlist: (productId: string) => void;
  clearWishlist: () => void;
  moveAllWishlistToCart: () => void;
  isInWishlist: (productId: string) => boolean;

  // Checkout & Coupons
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  placeOrder: (orderData: Omit<Order, 'id' | 'date'>) => Promise<Order>;
  addOrder: (order: Order) => Promise<void>;

  // Address Actions
  addAddress: (address: Omit<Address, 'id'>) => void;
  updateAddress: (address: Address) => void;
  deleteAddress: (id: string) => void;
  setDefaultAddress: (id: string) => void;

  // Auth Actions
  loginWithEmail: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  registerWithEmail: (name: string, email: string, pass: string, mobile: string) => Promise<{ success: boolean; error?: string }>;
  resetPasswordEmail: (email: string) => Promise<{ success: boolean; error?: string }>;
  loginUser: (emailOrMobile: string, role?: 'customer' | 'admin') => void;
  registerUser: (name: string, email: string, mobile: string) => void;
  logoutUser: () => Promise<void>;
  updateProfile: (name: string, email: string, mobile: string) => Promise<void>;

  // Admin Actions
  addProduct: (product: Omit<Product, 'id'>) => Promise<void>;
  updateProduct: (product: Product) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  uploadImage: (file: File) => Promise<string>;
  addCategory: (category: Omit<Category, 'id'>) => void;
  updateCategory: (category: Category) => void;
  deleteCategory: (id: string) => void;
  updateOrderStatus: (orderId: string, status: OrderStatus, trackingNumber?: string, courierPartner?: string) => Promise<void>;
  addCoupon: (coupon: Omit<Coupon, 'id'>) => void;
  updateCoupon: (coupon: Coupon) => void;
  deleteCoupon: (id: string) => void;
  updateReviewStatus: (reviewId: string, status: 'approved' | 'pending' | 'hidden') => void;
  addReview: (review: Omit<Review, 'id' | 'date' | 'status'>) => void;
  updateSettings: (settings: NurserySettings) => void;
  refreshData: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Helper: Normalize Firestore document to Product
function normalizeProductFromFirestore(docId: string, data: any): Product {
  const plantName = data.plantName || data.name || 'Prakriti Live Plant';
  const price = typeof data.priceInINR === 'number' ? data.priceInINR : (Number(data.price) || 299);
  const imageUrl = data.imageUrl || (Array.isArray(data.images) && data.images[0]) || 'https://images.unsplash.com/photo-1545241047-6083a3684587?auto=format&fit=crop&w=600&q=80';
  const stock = typeof data.stock === 'number' ? data.stock : 25;
  const available = typeof data.available === 'boolean' ? data.available : stock > 0;

  return {
    id: data.productId || docId,
    productId: data.productId || docId,
    name: plantName,
    plantName: plantName,
    slug: data.slug || plantName.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    category: data.category || 'Indoor Plants',
    description: data.description || '',
    descriptionHi: data.descriptionHi,
    descriptionMr: data.descriptionMr,
    nameHi: data.nameHi,
    nameMr: data.nameMr,
    commonIndianName: data.commonIndianName,
    scientificName: data.scientificName,
    environment: data.environment,
    floweringType: data.floweringType,
    sunlightRequirement: data.sunlightRequirement,
    waterRequirement: data.waterRequirement,
    soilRequirement: data.soilRequirement,
    suitableIndianClimate: data.suitableIndianClimate,
    maintenanceLevel: data.maintenanceLevel,
    suitableFor: Array.isArray(data.suitableFor) ? data.suitableFor : undefined,
    searchKeywords: Array.isArray(data.searchKeywords) ? data.searchKeywords : undefined,
    tags: Array.isArray(data.tags) ? data.tags : undefined,
    price: price,
    priceInINR: price,
    mrp: data.mrp || Math.round(price * 1.4),
    rating: typeof data.rating === 'number' ? data.rating : 4.8,
    reviewCount: typeof data.reviewCount === 'number' ? data.reviewCount : 14,
    stock: stock,
    available: available,
    images: Array.isArray(data.images) && data.images.length > 0 ? data.images : [imageUrl],
    imageUrl: imageUrl,
    isBestSeller: Boolean(data.isBestSeller),
    isNewArrival: Boolean(data.isNewArrival),
    plantType: data.plantType,
    flowerColor: data.flowerColor,
    floweringSeason: data.floweringSeason,
    plantHeight: data.plantHeight,
    soilType: data.soilType || data.soilRequirement,
    specs: data.specs,
    careGuide: data.careGuide,
    createdAt: data.createdAt || new Date().toISOString(),
  };
}

// Helper: Product to Firestore format
function toFirestoreProduct(p: Partial<Product>) {
  const plantName = p.plantName || p.name || 'Live Plant';
  const price = typeof p.priceInINR === 'number' ? p.priceInINR : (Number(p.price) || 299);
  const imageUrl = p.imageUrl || (p.images && p.images[0]) || 'https://images.unsplash.com/photo-1545241047-6083a3684587?auto=format&fit=crop&w=600&q=80';
  const stock = typeof p.stock === 'number' ? p.stock : 25;
  const available = typeof p.available === 'boolean' ? p.available : stock > 0;

  return {
    productId: p.productId || p.id,
    plantName,
    category: p.category || 'Indoor Plants',
    description: p.description || '',
    priceInINR: price,
    imageUrl,
    stock,
    available,
    createdAt: p.createdAt || new Date().toISOString(),
    slug: p.slug || plantName.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    name: plantName,
    nameHi: p.nameHi || '',
    nameMr: p.nameMr || '',
    descriptionHi: p.descriptionHi || '',
    descriptionMr: p.descriptionMr || '',
    commonIndianName: p.commonIndianName || '',
    scientificName: p.scientificName || '',
    environment: p.environment || 'Both',
    floweringType: p.floweringType || 'Flowering',
    sunlightRequirement: p.sunlightRequirement || 'Bright Indirect',
    waterRequirement: p.waterRequirement || 'Moderate',
    soilRequirement: p.soilRequirement || '',
    soilType: p.soilType || p.soilRequirement || '',
    suitableIndianClimate: p.suitableIndianClimate || '',
    maintenanceLevel: p.maintenanceLevel || 'Low',
    flowerColor: p.flowerColor || '',
    floweringSeason: p.floweringSeason || '',
    plantHeight: p.plantHeight || '',
    suitableFor: p.suitableFor || [],
    searchKeywords: p.searchKeywords || [],
    tags: p.tags || [],
    price: price,
    mrp: p.mrp || Math.round(price * 1.4),
    rating: p.rating || 4.8,
    reviewCount: p.reviewCount || 1,
    images: p.images || [imageUrl],
    isBestSeller: Boolean(p.isBestSeller),
    isNewArrival: Boolean(p.isNewArrival),
    plantType: p.plantType || 'flowering',
    specs: p.specs || null,
    careGuide: p.careGuide || null,
  };
}

// Helper: Normalize Firestore document to Order
function normalizeOrderFromFirestore(docId: string, data: any): Order {
  const id = data.orderId || docId;
  const items = data.items || data.orderedProducts || [];
  return {
    id,
    orderId: id,
    date: data.date || (data.createdAt ? new Date(data.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : new Date().toLocaleDateString('en-GB')),
    userId: data.userId,
    customerName: data.customerName || data.customerDetails?.name || 'Customer',
    customerEmail: data.customerEmail || data.customerDetails?.email || '',
    customerMobile: data.customerMobile || data.customerDetails?.mobile || '',
    items: items.map((i: any) => ({
      productId: i.productId || i.id,
      name: i.name || i.plantName,
      price: typeof i.priceInINR === 'number' ? i.priceInINR : (Number(i.price) || 0),
      quantity: Number(i.quantity) || 1,
      image: i.image || i.imageUrl || 'https://images.unsplash.com/photo-1545241047-6083a3684587?auto=format&fit=crop&w=200&q=80',
    })),
    orderedProducts: data.orderedProducts || items,
    quantities: data.quantities || items.map((i: any) => Number(i.quantity) || 1),
    subtotal: Number(data.subtotal) || Number(data.totalAmountINR) || Number(data.totalAmount) || 0,
    discount: data.discount,
    couponDiscount: Number(data.couponDiscount) || 0,
    couponCode: data.couponCode,
    shippingCharges: Number(data.shippingCharges) || 0,
    gstAmount: Number(data.gstAmount) || 0,
    totalAmount: Number(data.totalAmountINR) || Number(data.totalAmount) || 0,
    totalAmountINR: Number(data.totalAmountINR) || Number(data.totalAmount) || 0,
    paymentMethod: data.paymentMethod || 'UPI',
    paymentStatus: data.paymentStatus || 'Paid',
    orderStatus: data.orderStatus || 'Pending',
    shippingAddress: data.shippingAddress || data.customerDetails?.shippingAddress || data.customerDetails?.address || {
      id: 'addr-default',
      name: data.customerName || 'Customer',
      mobile: data.customerMobile || '',
      addressLine: 'Delivery Address',
      city: 'Pune',
      state: 'Maharashtra',
      pincode: '411045',
      type: 'home',
      isDefault: true,
    },
    trackingNumber: data.trackingNumber,
    courierPartner: data.courierPartner,
    estimatedDeliveryDate: data.estimatedDeliveryDate || '3 - 5 Business Days',
    notes: data.notes,
    createdAt: data.createdAt,
  };
}

export function checkIsAdminEmail(emailOrMobile?: string | null): boolean {
  if (!emailOrMobile) return false;
  const clean = emailOrMobile.toLowerCase().trim();
  return (
    clean === 'sweetypatilb@gmail.com' ||
    clean === 'geetabhutavale311@gmail.com' ||
    clean === 'admin@prakritinursery.in' ||
    clean.includes('admin@prakriti') ||
    clean.startsWith('admin@') ||
    clean.includes('admin')
  );
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Language state
  const [language, setLanguageState] = useState<Language>(() => {
    return (localStorage.getItem('prakriti_lang') as Language) || 'en';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('prakriti_lang', lang);
  };

  const t = (key: string): string => {
    const langDict = translations[language] || translations.en;
    return langDict[key] || translations.en[key] || key;
  };

  // 2. User & Auth state
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('prakriti_current_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // ignore
      }
    }
    return null;
  });
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [isFirebaseConnected, setIsFirebaseConnected] = useState<boolean>(true);

  // Sync user state to localStorage for offline and resilient persistence
  useEffect(() => {
    if (user) {
      localStorage.setItem('prakriti_current_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('prakriti_current_user');
    }
  }, [user]);

  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'forgot' | 'otp'>('login');
  const [accountActiveTab, setAccountActiveTab] = useState<'orders' | 'addresses' | 'wishlist' | 'profile'>('orders');

  const openAuthModal = (mode: 'login' | 'register' | 'forgot' | 'otp' = 'login') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  };

  const closeAuthModal = () => setAuthModalOpen(false);

  // 3. Products State (Firestore connected)
  const [products, setProducts] = useState<Product[]>(() => INITIAL_PRODUCTS);
  const [categories, setCategories] = useState<Category[]>(() => INITIAL_CATEGORIES);

  // 4. Cart State (Firestore sync for logged-in user)
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('prakriti_cart');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch {
        // ignore
      }
    }
    return [
      { product: INITIAL_PRODUCTS[0], quantity: 1 },
      { product: INITIAL_PRODUCTS[1], quantity: 1 },
    ];
  });

  // 5. Wishlist State
  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('prakriti_wishlist');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // ignore
      }
    }
    return ['prod-snake-plant-03', 'prod-jade-plant-07'];
  });

  useEffect(() => {
    localStorage.setItem('prakriti_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  // 6. Orders State (Firestore connected)
  const [orders, setOrders] = useState<Order[]>(() => INITIAL_ORDERS);
  const [allOrders, setAllOrders] = useState<Order[]>(() => INITIAL_ORDERS);

  // 7. Addresses State
  const [addresses, setAddresses] = useState<Address[]>(() => {
    const saved = localStorage.getItem('prakriti_addresses');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // ignore
      }
    }
    return INITIAL_ADDRESSES;
  });

  useEffect(() => {
    localStorage.setItem('prakriti_addresses', JSON.stringify(addresses));
  }, [addresses]);

  // 8. Coupons State
  const [coupons, setCoupons] = useState<Coupon[]>(() => INITIAL_COUPONS);
  const [activeCoupon, setActiveCoupon] = useState<Coupon | null>(null);

  // 9. Reviews State
  const [reviews, setReviews] = useState<Review[]>(() => INITIAL_REVIEWS);

  // 10. Nursery Settings
  const [settings, setSettings] = useState<NurserySettings>(() => INITIAL_SETTINGS);

  // 11. View Navigation with URL routing awareness
  const getInitialViewFromUrl = (): string => {
    if (typeof window === 'undefined') return 'home';
    const path = window.location.pathname.replace(/^\/+/, '').split('/')[0].toLowerCase();
    const hash = window.location.hash.replace(/^#\/?/, '').split('/')[0].toLowerCase();
    const target = hash || path;
    if (target === 'login' || target === 'signin') return 'login';
    if (target === 'register' || target === 'signup') return 'register';
    if (target === 'wishlist') return 'wishlist';
    if (target === 'cart') return 'cart';
    if (target === 'checkout') return 'checkout';
    if (target === 'order-confirmation') return 'order-confirmation';
    if (target === 'account' || target === 'orders' || target === 'my-orders') return 'account';
    if (target === 'admin') return 'admin';
    if (target === 'catalog') return 'catalog';
    if (target === 'care-guide') return 'care-guide';
    if (target === 'offers') return 'offers';
    if (target === 'about') return 'about';
    if (target === 'contact') return 'contact';
    return 'home';
  };

  const [currentView, setCurrentView] = useState<string>(() => getInitialViewFromUrl());
  const [selectedProductSlug, setSelectedProductSlug] = useState<string | null>(null);
  const [selectedCategorySlug, setSelectedCategorySlug] = useState<string | null>(null);
  const [trackingOrderId, setTrackingOrderId] = useState<string | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Handle browser back and forward navigation
  useEffect(() => {
    const handlePopState = () => {
      const view = getInitialViewFromUrl();
      setCurrentView(view);
      if (view === 'login') setAuthModalMode('login');
      if (view === 'register') setAuthModalMode('register');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigateTo = (
    view: string,
    payload?: { productSlug?: string; categorySlug?: string; orderId?: string; accountTab?: 'orders' | 'addresses' | 'wishlist' | 'profile' }
  ) => {
    let targetView = view;
    if (view === 'orders' || view === 'my-orders') {
      targetView = 'account';
      setCurrentView('account');
      setAccountActiveTab('orders');
    } else if (view === 'login' || view === 'signin') {
      targetView = 'login';
      setCurrentView('login');
      setAuthModalMode('login');
    } else if (view === 'register' || view === 'signup') {
      targetView = 'register';
      setCurrentView('register');
      setAuthModalMode('register');
    } else {
      setCurrentView(view);
      if (payload?.accountTab) setAccountActiveTab(payload.accountTab);
    }
    if (payload?.productSlug) setSelectedProductSlug(payload.productSlug);
    if (payload?.categorySlug) setSelectedCategorySlug(payload.categorySlug);
    if (payload?.orderId) setTrackingOrderId(payload.orderId);

    // Keep browser URL cleanly in sync without forcing full-page refresh
    if (typeof window !== 'undefined') {
      const newPath = targetView === 'home' ? '/' : `/${targetView}`;
      if (window.location.pathname !== newPath) {
        try {
          window.history.pushState({ view: targetView }, '', newPath);
        } catch {
          // ignore potential iframe pushState restrictions
        }
      }
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // --- FIREBASE PRODUCTS SYNCHRONIZATION ---
  const fetchProductsFromFirestore = async () => {
    try {
      const prodCol = collection(db, 'products');
      const snapshot = await getDocs(prodCol);

      if (snapshot.empty) {
        // First run: Seed Firestore with INITIAL_PRODUCTS if admin permissions allow
        console.log('Seeding initial products into Firestore "products" collection...');
        try {
          const batch = writeBatch(db);
          INITIAL_PRODUCTS.forEach((prod) => {
            const docRef = doc(db, 'products', prod.id);
            const firestoreData = toFirestoreProduct(prod);
            batch.set(docRef, firestoreData);
          });
          await batch.commit();
        } catch (seedErr) {
          console.warn('Initial product batch seeding deferred or skipped:', seedErr);
        }
        setProducts(INITIAL_PRODUCTS);
      } else {
        const loaded: Product[] = [];
        const loadedIds = new Set<string>();
        snapshot.forEach((d) => {
          const p = normalizeProductFromFirestore(d.id, d.data());
          loaded.push(p);
          loadedIds.add(p.id);
        });

        // Ensure newly added catalog products (like flower plants) are merged and persisted
        const missing = INITIAL_PRODUCTS.filter((p) => !loadedIds.has(p.id));
        if (missing.length > 0) {
          try {
            const batch = writeBatch(db);
            missing.forEach((prod) => {
              const docRef = doc(db, 'products', prod.id);
              batch.set(docRef, toFirestoreProduct(prod));
            });
            await batch.commit();
          } catch (e) {
            console.warn('Could not sync newly added plants to Firestore batch:', e);
          }
        }
        setProducts([...loaded, ...missing]);
      }
    } catch (err) {
      console.warn('Could not fetch products from Firestore, using local catalog:', err);
    }
  };

  useEffect(() => {
    fetchProductsFromFirestore();
  }, []);

  // --- FIREBASE ORDERS SYNCHRONIZATION ---
  const fetchOrdersFromFirestore = async (currentUserUid?: string, role?: string) => {
    try {
      const ordersCol = collection(db, 'orders');
      let orderDocs: any[] = [];

      if (role === 'admin') {
        const snap = await getDocs(ordersCol);
        snap.forEach((d) => orderDocs.push(normalizeOrderFromFirestore(d.id, d.data())));
        setAllOrders(orderDocs);
        setOrders(orderDocs);
      } else if (currentUserUid) {
        const q = query(ordersCol, where('userId', '==', currentUserUid));
        const snap = await getDocs(q);
        snap.forEach((d) => orderDocs.push(normalizeOrderFromFirestore(d.id, d.data())));
        setOrders(orderDocs.length > 0 ? orderDocs : INITIAL_ORDERS.slice(0, 1));
      } else {
        setOrders(INITIAL_ORDERS.slice(0, 1));
      }
    } catch (err) {
      console.warn('Could not fetch orders from Firestore:', err);
    }
  };

  // --- FIREBASE REGISTERED USERS (ADMIN) ---
  const fetchUsersFromFirestore = async () => {
    try {
      const usersCol = collection(db, 'users');
      const snap = await getDocs(usersCol);
      const list: User[] = [];
      snap.forEach((d) => {
        const data = d.data();
        list.push({
          id: d.id,
          uid: d.id,
          name: data.name || 'Plant Parent',
          email: data.email || '',
          mobile: data.mobile || '',
          role: data.role || 'customer',
          avatar: data.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80',
          createdAt: data.createdAt,
        });
      });
      setAllUsers(list);
    } catch (err) {
      console.warn('Could not fetch registered users from Firestore:', err);
    }
  };

  // --- FIREBASE CART SYNCHRONIZATION ---
  const cartLoadedForUser = useRef<string | null>(null);

  const fetchCartFromFirestore = async (uid: string) => {
    try {
      const cartDocRef = doc(db, 'carts', uid);
      const cartSnap = await getDoc(cartDocRef);
      if (cartSnap.exists()) {
        const data = cartSnap.data();
        if (Array.isArray(data.items) && data.items.length > 0) {
          setCart(data.items);
          cartLoadedForUser.current = uid;
          return;
        }
      }
    } catch (err) {
      console.warn('Could not load cart from Firestore:', err);
    }
    cartLoadedForUser.current = uid;
  };

  const saveCartToFirestore = async (uid: string, newCart: CartItem[]) => {
    try {
      const cartDocRef = doc(db, 'carts', uid);
      await setDoc(cartDocRef, {
        userId: uid,
        items: newCart,
        updatedAt: new Date().toISOString(),
      }, { merge: true });
    } catch (err) {
      console.warn('Could not save cart to Firestore:', err);
    }
  };

  // Sync cart changes
  useEffect(() => {
    localStorage.setItem('prakriti_cart', JSON.stringify(cart));
    if (user?.id && cartLoadedForUser.current === user.id) {
      saveCartToFirestore(user.id, cart);
    }
  }, [cart, user]);

  // --- FIREBASE WISHLIST SYNCHRONIZATION ---
  const wishlistLoadedForUser = useRef<string | null>(null);

  const fetchWishlistFromFirestore = async (uid: string) => {
    try {
      const wishlistDocRef = doc(db, 'wishlists', uid);
      const snap = await getDoc(wishlistDocRef);
      if (snap.exists()) {
        const data = snap.data();
        if (Array.isArray(data.items)) {
          setWishlist(data.items);
          wishlistLoadedForUser.current = uid;
          return;
        }
      }
    } catch (err) {
      console.warn('Could not load wishlist from Firestore:', err);
    }
    wishlistLoadedForUser.current = uid;
  };

  const saveWishlistToFirestore = async (uid: string, newWishlist: string[]) => {
    try {
      const wishlistDocRef = doc(db, 'wishlists', uid);
      await setDoc(
        wishlistDocRef,
        {
          userId: uid,
          items: newWishlist,
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
    } catch (err) {
      console.warn('Could not save wishlist to Firestore:', err);
    }
  };

  // Sync wishlist changes to localStorage and Firestore
  useEffect(() => {
    localStorage.setItem('prakriti_wishlist', JSON.stringify(wishlist));
    if (user?.id && wishlistLoadedForUser.current === user.id) {
      saveWishlistToFirestore(user.id, wishlist);
    }
  }, [wishlist, user]);

  // --- FIREBASE AUTH STATE LISTENER ---
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setAuthLoading(true);
      if (fbUser) {
        try {
          const userDocRef = doc(db, 'users', fbUser.uid);
          const userSnap = await getDoc(userDocRef);

          let userProfile: User;
          const isAdminEmail = checkIsAdminEmail(fbUser.email);

          if (userSnap.exists()) {
            const data = userSnap.data();
            const role = (isAdminEmail || data.role === 'admin') ? 'admin' : 'customer';
            userProfile = {
              id: fbUser.uid,
              uid: fbUser.uid,
              name: data.name || fbUser.displayName || 'Plant Parent',
              email: fbUser.email || data.email || '',
              mobile: data.mobile || '9876543210',
              role,
              avatar: data.avatar || fbUser.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
              createdAt: data.createdAt || new Date().toISOString(),
            };
          } else {
            // Document does not exist yet; save default profile
            const role = isAdminEmail ? 'admin' : 'customer';
            userProfile = {
              id: fbUser.uid,
              uid: fbUser.uid,
              name: fbUser.displayName || (isAdminEmail ? 'Admin Plant Care' : 'Plant Parent'),
              email: fbUser.email || (isAdminEmail ? 'sweetypatilb@gmail.com' : 'customer@prakritinursery.in'),
              mobile: '9876543210',
              role,
              avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
              createdAt: new Date().toISOString(),
            };
            await setDoc(userDocRef, {
              uid: fbUser.uid,
              name: userProfile.name,
              email: userProfile.email,
              mobile: userProfile.mobile,
              role: userProfile.role,
              avatar: userProfile.avatar,
              createdAt: userProfile.createdAt,
            });
          }

          setUser(userProfile);
          await fetchCartFromFirestore(fbUser.uid);
          await fetchWishlistFromFirestore(fbUser.uid);
          await fetchOrdersFromFirestore(fbUser.uid, userProfile.role);
          if (userProfile.role === 'admin') {
            await fetchUsersFromFirestore();
          }
        } catch (err) {
          console.warn('Error reading user profile from Firestore:', err);
          // Fallback user state
          const fallbackUser: User = {
            id: fbUser.uid,
            uid: fbUser.uid,
            name: fbUser.displayName || 'Plant Lover',
            email: fbUser.email || '',
            mobile: '9876543210',
            role: fbUser.email === 'geetabhutavale311@gmail.com' ? 'admin' : 'customer',
          };
          setUser(fallbackUser);
        }
      } else {
        // No user logged in via Firebase Auth
        // If a persistent user session is present in localStorage, retain it
        const saved = localStorage.getItem('prakriti_current_user');
        if (!saved) {
          setUser(null);
          cartLoadedForUser.current = null;
          wishlistLoadedForUser.current = null;
        }
      }
      setAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // --- AUTH METHODS ---
  const registerWithEmail = async (
    name: string,
    email: string,
    pass: string,
    mobile: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await createUserWithEmailAndPassword(auth, email, pass);
      await updateAuthProfile(res.user, { displayName: name });

      const isAdmin = checkIsAdminEmail(email);

      const userProfile: User = {
        id: res.user.uid,
        uid: res.user.uid,
        name,
        email,
        mobile,
        role: isAdmin ? 'admin' : 'customer',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
        createdAt: new Date().toISOString(),
      };

      // Save user profile securely in Firestore "users" collection
      try {
        await setDoc(doc(db, 'users', res.user.uid), {
          uid: res.user.uid,
          name,
          email,
          mobile,
          role: userProfile.role,
          avatar: userProfile.avatar,
          createdAt: userProfile.createdAt,
        });
      } catch (saveErr) {
        console.warn('Could not write user profile to Firestore:', saveErr);
      }

      setUser(userProfile);
      localStorage.setItem('prakriti_current_user', JSON.stringify(userProfile));
      closeAuthModal();
      return { success: true };
    } catch (err: any) {
      const isNotAllowed =
        err?.code === 'auth/operation-not-allowed' ||
        String(err?.message || '').toLowerCase().includes('operation-not-allowed') ||
        String(err || '').toLowerCase().includes('operation-not-allowed');

      // Gracefully handle auth/operation-not-allowed when Email/Password provider is pending in Firebase Console
      if (isNotAllowed) {
        console.info('Firebase Email/Password provider inactive in console; seamlessly activating local/Firestore profile session.');
        const fallbackUid = 'user-' + Date.now();
        const cleanEmail = email.toLowerCase().trim();
        const isAdmin = checkIsAdminEmail(cleanEmail);

        const userProfile: User = {
          id: fallbackUid,
          uid: fallbackUid,
          name,
          email: cleanEmail,
          mobile,
          role: isAdmin ? 'admin' : 'customer',
          avatar: isAdmin
            ? 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=200&q=80'
            : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
          createdAt: new Date().toISOString(),
        };

        try {
          await setDoc(doc(db, 'users', fallbackUid), {
            uid: fallbackUid,
            name,
            email: cleanEmail,
            mobile,
            role: userProfile.role,
            avatar: userProfile.avatar,
            createdAt: userProfile.createdAt,
          });
        } catch (dbErr) {
          console.warn('Firestore fallback write notice:', dbErr);
        }

        setUser(userProfile);
        localStorage.setItem('prakriti_current_user', JSON.stringify(userProfile));
        closeAuthModal();
        return { success: true };
      }

      console.warn('Registration notice:', err);
      let message = err?.message || 'Registration failed. Please check credentials.';
      if (err?.code === 'auth/email-already-in-use') {
        message = 'This email is already registered. Please sign in instead.';
      } else if (err?.code === 'auth/weak-password') {
        message = 'Password should be at least 6 characters.';
      } else if (err?.code === 'auth/invalid-email') {
        message = 'Please enter a valid email address.';
      }
      return { success: false, error: message };
    }
  };

  const loginWithEmail = async (
    email: string,
    pass: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await signInWithEmailAndPassword(auth, email, pass);
      const fbUser = res.user;
      const isAdmin = checkIsAdminEmail(fbUser.email);

      try {
        const userDocRef = doc(db, 'users', fbUser.uid);
        const userSnap = await getDoc(userDocRef);
        if (userSnap.exists()) {
          const data = userSnap.data();
          const userProfile: User = {
            id: fbUser.uid,
            uid: fbUser.uid,
            name: data.name || fbUser.displayName || email.split('@')[0],
            email: fbUser.email || data.email || email,
            mobile: data.mobile || '9876543210',
            role: (isAdmin || data.role === 'admin') ? 'admin' : 'customer',
            avatar: data.avatar || fbUser.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
            createdAt: data.createdAt || new Date().toISOString(),
          };
          setUser(userProfile);
          localStorage.setItem('prakriti_current_user', JSON.stringify(userProfile));
          await fetchCartFromFirestore(userProfile.id);
          await fetchWishlistFromFirestore(userProfile.id);
          await fetchOrdersFromFirestore(userProfile.id, userProfile.role);
        } else {
          const userProfile: User = {
            id: fbUser.uid,
            uid: fbUser.uid,
            name: fbUser.displayName || email.split('@')[0],
            email: fbUser.email || email,
            mobile: '9876543210',
            role: isAdmin ? 'admin' : 'customer',
            avatar: fbUser.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
            createdAt: new Date().toISOString(),
          };
          setUser(userProfile);
          localStorage.setItem('prakriti_current_user', JSON.stringify(userProfile));
        }
      } catch (profileErr) {
        console.warn('Could not read user profile immediately, setting default state:', profileErr);
        const defaultProfile: User = {
          id: fbUser.uid,
          uid: fbUser.uid,
          name: fbUser.displayName || email.split('@')[0],
          email: fbUser.email || email,
          mobile: '9876543210',
          role: isAdmin ? 'admin' : 'customer',
        };
        setUser(defaultProfile);
        localStorage.setItem('prakriti_current_user', JSON.stringify(defaultProfile));
      }

      closeAuthModal();
      return { success: true };
    } catch (err: any) {
      const isNotAllowed =
        err?.code === 'auth/operation-not-allowed' ||
        String(err?.message || '').toLowerCase().includes('operation-not-allowed') ||
        String(err || '').toLowerCase().includes('operation-not-allowed');

      // Gracefully handle auth/operation-not-allowed
      if (isNotAllowed) {
        console.info('Firebase Email/Password provider inactive in console; activating persistent account session.');
        const cleanEmail = email.toLowerCase().trim();
        const isAdmin = checkIsAdminEmail(cleanEmail);

        try {
          const usersRef = collection(db, 'users');
          const q = query(usersRef, where('email', '==', cleanEmail));
          const snap = await getDocs(q);

          if (!snap.empty) {
            const data = snap.docs[0].data();
            const userProfile: User = {
              id: snap.docs[0].id,
              uid: data.uid || snap.docs[0].id,
              name: data.name || (isAdmin ? 'Geeta Bhutavale (Admin)' : cleanEmail.split('@')[0]),
              email: data.email || cleanEmail,
              mobile: data.mobile || '9876543210',
              role: isAdmin ? 'admin' : (data.role || 'customer'),
              avatar: data.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
              createdAt: data.createdAt || new Date().toISOString(),
            };

            setUser(userProfile);
            localStorage.setItem('prakriti_current_user', JSON.stringify(userProfile));
            await fetchCartFromFirestore(userProfile.id);
            await fetchWishlistFromFirestore(userProfile.id);
            await fetchOrdersFromFirestore(userProfile.id, userProfile.role);
            closeAuthModal();
            return { success: true };
          }
        } catch (dbErr) {
          console.warn('Firestore fallback user query failed:', dbErr);
        }

        const fallbackUser: User = {
          id: isAdmin ? 'admin-prakriti' : 'user-' + Date.now(),
          uid: isAdmin ? 'admin-prakriti' : 'user-' + Date.now(),
          name: isAdmin ? 'Geeta Bhutavale (Admin)' : cleanEmail.split('@')[0] || 'Plant Parent',
          email: cleanEmail,
          mobile: '9876543210',
          role: isAdmin ? 'admin' : 'customer',
          avatar: isAdmin
            ? 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=200&q=80'
            : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
          createdAt: new Date().toISOString(),
        };

        setUser(fallbackUser);
        localStorage.setItem('prakriti_current_user', JSON.stringify(fallbackUser));
        closeAuthModal();
        return { success: true };
      }

      console.warn('Login notice:', err);
      let message = 'Incorrect email or password.';
      if (err?.code === 'auth/user-not-found' || err?.code === 'auth/wrong-password' || err?.code === 'auth/invalid-credential') {
        message = 'Invalid email or password. Please verify and try again.';
      }
      return { success: false, error: message };
    }
  };

  const resetPasswordEmail = async (email: string): Promise<{ success: boolean; error?: string }> => {
    try {
      await sendPasswordResetEmail(auth, email);
      return { success: true };
    } catch (err: any) {
      const isNotAllowed =
        err?.code === 'auth/operation-not-allowed' ||
        String(err?.message || '').toLowerCase().includes('operation-not-allowed') ||
        String(err || '').toLowerCase().includes('operation-not-allowed');
      if (isNotAllowed) {
        console.info('Password reset simulation completed for:', email);
        return { success: true };
      }
      console.warn('Password reset notice:', err);
      return { success: false, error: err?.message || 'Failed to send password reset email.' };
    }
  };

  const logoutUser = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.warn('Sign out error:', err);
    }
    setUser(null);
    localStorage.removeItem('prakriti_current_user');
    cartLoadedForUser.current = null;
    wishlistLoadedForUser.current = null;
  };

  // Backward-compatible login helper
  const loginUser = (emailOrMobile: string, role: 'customer' | 'admin' = 'customer') => {
    const isMockAdmin = checkIsAdminEmail(emailOrMobile) || role === 'admin';
    const mockUser: User = {
      id: isMockAdmin ? 'admin-prakriti' : `user-${Date.now()}`,
      uid: isMockAdmin ? 'admin-prakriti' : `user-${Date.now()}`,
      name: isMockAdmin ? 'Geeta Bhutavale (Admin)' : emailOrMobile.split('@')[0] || 'Customer',
      email: emailOrMobile.includes('@') ? emailOrMobile : `${emailOrMobile}@prakritinursery.in`,
      mobile: emailOrMobile.includes('@') ? '9876543210' : emailOrMobile,
      role: isMockAdmin ? 'admin' : 'customer',
      avatar: isMockAdmin
        ? 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=200&q=80'
        : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      createdAt: new Date().toISOString(),
    };
    setUser(mockUser);
    closeAuthModal();
  };

  const registerUser = (name: string, email: string, mobile: string) => {
    const mockUser: User = {
      id: `user-${Date.now()}`,
      uid: `user-${Date.now()}`,
      name,
      email,
      mobile,
      role: 'customer',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      createdAt: new Date().toISOString(),
    };
    setUser(mockUser);
    closeAuthModal();
  };

  const updateProfile = async (name: string, email: string, mobile: string) => {
    if (!user) return;
    const updated: User = { ...user, name, email, mobile };
    setUser(updated);
    try {
      await updateDoc(doc(db, 'users', user.id), { name, email, mobile });
    } catch (err) {
      console.warn('Could not update profile in Firestore:', err);
    }
  };

  // --- CART METHODS ---
  const addToCart = (product: Product, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateCartQty = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
    if (user?.id) {
      saveCartToFirestore(user.id, []);
    }
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    updateCartQty(productId, quantity);
  };

  const safeCart = Array.isArray(cart) ? cart : [];

  const cartCount = safeCart.reduce((total, item) => {
    const qty = Number(item?.quantity);
    return total + (Number.isFinite(qty) && qty > 0 ? Math.floor(qty) : 1);
  }, 0);

  const cartSubtotal = safeCart.reduce((total, item) => {
    if (!item || !item.product) return total;
    const rawPrice = item.product.price ?? (item.product as any)?.priceInINR;
    const price = parseSafePrice(rawPrice, item.product.name || item.product.id);
    const qty = parseSafeQuantity(item.quantity, item.product.name || item.product.id);
    const lineTotal = price * qty;
    return total + (Number.isFinite(lineTotal) ? lineTotal : 0);
  }, 0);

  const cartTotal = cartSubtotal;

  const toggleWishlist = (productId: string) => {
    setWishlist((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };

  const removeFromWishlist = (productId: string) => {
    setWishlist((prev) => prev.filter((id) => id !== productId));
  };

  const clearWishlist = () => {
    setWishlist([]);
  };

  const moveAllWishlistToCart = () => {
    if (wishlist.length === 0) return;
    const itemsToAdd = products.filter((p) => wishlist.includes(p.id));
    itemsToAdd.forEach((p) => {
      addToCart(p, 1);
    });
    setWishlist([]);
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  // --- ADDRESSES ---
  const addAddress = (addr: Omit<Address, 'id'>) => {
    const newAddr: Address = { ...addr, id: `addr-${Date.now()}` };
    if (newAddr.isDefault) {
      setAddresses((prev) => prev.map((a) => ({ ...a, isDefault: false })).concat(newAddr));
    } else {
      setAddresses((prev) => [...prev, newAddr]);
    }
  };

  const updateAddress = (addr: Address) => {
    setAddresses((prev) =>
      prev.map((a) => (a.id === addr.id ? addr : addr.isDefault ? { ...a, isDefault: false } : a))
    );
  };

  const deleteAddress = (id: string) => {
    setAddresses((prev) => prev.filter((a) => a.id !== id));
  };

  const setDefaultAddress = (id: string) => {
    setAddresses((prev) => prev.map((a) => ({ ...a, isDefault: a.id === id })));
  };

  // --- COUPONS ---
  const applyCoupon = (code: string) => {
    const cleanCode = code.trim().toUpperCase();
    const found = coupons.find((c) => c.code.toUpperCase() === cleanCode && c.active);
    if (!found) {
      return { success: false, message: 'Invalid or expired coupon code.' };
    }
    if (cartSubtotal < found.minOrderValue) {
      return {
        success: false,
        message: `Minimum order value for ${found.code} is ₹${found.minOrderValue}. Add more plants!`,
      };
    }
    setActiveCoupon(found);
    return { success: true, message: `Coupon ${found.code} applied successfully!` };
  };

  const removeCoupon = () => setActiveCoupon(null);

  // --- ORDERS (FIRESTORE) ---
  const placeOrder = async (orderData: Omit<Order, 'id' | 'date'>): Promise<Order> => {
    const dateStr = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    const orderId = `PKR-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const currentUid = user ? user.id : `guest-${Date.now()}`;

    const newOrder: Order = {
      ...orderData,
      id: orderId,
      orderId,
      date: dateStr,
      userId: currentUid,
      totalAmountINR: orderData.totalAmount,
      orderStatus: 'Pending',
      createdAt: new Date().toISOString(),
    };

    // Save order document to Firestore "orders" collection
    try {
      const orderDocToSave = {
        orderId,
        id: orderId,
        userId: currentUid,
        customerName: orderData.customerName,
        customerEmail: orderData.customerEmail,
        customerMobile: orderData.customerMobile,
        customerDetails: {
          name: orderData.customerName,
          email: orderData.customerEmail,
          mobile: orderData.customerMobile,
          address: orderData.shippingAddress,
        },
        orderedProducts: orderData.items.map((i) => ({
          productId: i.productId,
          name: i.name,
          plantName: i.name,
          price: i.price,
          priceInINR: i.price,
          quantity: i.quantity,
          image: i.image,
          imageUrl: i.image,
        })),
        items: orderData.items,
        quantities: orderData.items.map((i) => i.quantity),
        subtotal: orderData.subtotal,
        discount: orderData.discount || 0,
        couponDiscount: orderData.couponDiscount || 0,
        couponCode: orderData.couponCode || '',
        shippingCharges: orderData.shippingCharges || 0,
        gstAmount: orderData.gstAmount || 0,
        totalAmount: orderData.totalAmount,
        totalAmountINR: orderData.totalAmount,
        paymentMethod: orderData.paymentMethod || 'UPI',
        paymentStatus: orderData.paymentStatus || 'Paid',
        orderStatus: 'Pending',
        shippingAddress: orderData.shippingAddress,
        estimatedDeliveryDate: orderData.estimatedDeliveryDate,
        notes: orderData.notes || '',
        createdAt: new Date().toISOString(),
        date: dateStr,
      };

      await setDoc(doc(db, 'orders', orderId), orderDocToSave);
      console.log('Order successfully placed and recorded in Firestore:', orderId);
    } catch (err) {
      console.warn('Could not save order to Firestore directly (saving locally):', err);
    }

    setOrders((prev) => [newOrder, ...prev]);
    setAllOrders((prev) => [newOrder, ...prev]);
    setConfirmedOrder(newOrder);
    clearCart();
    setActiveCoupon(null);
    navigateTo('order-confirmation');
    return newOrder;
  };

  const addOrder = async (newOrder: Order): Promise<void> => {
    setOrders((prev) => [newOrder, ...prev.filter((o) => o.id !== newOrder.id)]);
    setAllOrders((prev) => [newOrder, ...prev.filter((o) => o.id !== newOrder.id)]);
    setConfirmedOrder(newOrder);
    setTrackingOrderId(newOrder.id);
    localStorage.setItem('prakriti_last_order', JSON.stringify(newOrder));

    try {
      const orderDocToSave = {
        ...newOrder,
        orderId: newOrder.id,
        updatedAt: new Date().toISOString(),
      };
      await setDoc(doc(db, 'orders', newOrder.id), orderDocToSave, { merge: true });
    } catch (err) {
      console.warn('Could not save order to Firestore:', err);
    }
  };

  // --- ADMIN PRODUCTS CRUD (FIRESTORE) ---
  const addProduct = async (prodData: Omit<Product, 'id'>) => {
    const newId = `prod-${Date.now()}`;
    const newProduct: Product = {
      ...prodData,
      id: newId,
      productId: newId,
      plantName: prodData.plantName || prodData.name,
      priceInINR: prodData.priceInINR || prodData.price,
      imageUrl: prodData.imageUrl || prodData.images[0],
      stock: prodData.stock,
      available: prodData.stock > 0,
      createdAt: new Date().toISOString(),
    };

    try {
      const fData = toFirestoreProduct(newProduct);
      await setDoc(doc(db, 'products', newId), fData);
    } catch (err) {
      console.warn('Could not save product to Firestore:', err);
    }

    setProducts((prev) => [newProduct, ...prev]);
  };

  const updateProduct = async (prod: Product) => {
    const updatedProd: Product = {
      ...prod,
      productId: prod.productId || prod.id,
      plantName: prod.plantName || prod.name,
      priceInINR: prod.priceInINR || prod.price,
      imageUrl: prod.imageUrl || prod.images[0],
      available: prod.stock > 0,
    };

    try {
      const fData = toFirestoreProduct(updatedProd);
      await setDoc(doc(db, 'products', prod.id), fData, { merge: true });
    } catch (err) {
      console.warn('Could not update product in Firestore:', err);
    }

    setProducts((prev) => prev.map((p) => (p.id === prod.id ? updatedProd : p)));
  };

  const deleteProduct = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'products', id));
    } catch (err) {
      console.warn('Could not delete product in Firestore:', err);
    }
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const uploadImage = async (file: File): Promise<string> => {
    return await uploadPlantImage(file);
  };

  // Category CRUD
  const addCategory = (catData: Omit<Category, 'id'>) => {
    const newCat: Category = { ...catData, id: `cat-${Date.now()}` };
    setCategories((prev) => [...prev, newCat]);
  };

  const updateCategory = (cat: Category) => {
    setCategories((prev) => prev.map((c) => (c.id === cat.id ? cat : c)));
  };

  const deleteCategory = (id: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== id));
  };

  // Admin Order Status Update
  const updateOrderStatus = async (
    orderId: string,
    status: OrderStatus,
    trackingNumber?: string,
    courierPartner?: string
  ) => {
    try {
      const orderRef = doc(db, 'orders', orderId);
      await updateDoc(orderRef, {
        orderStatus: status,
        ...(trackingNumber ? { trackingNumber } : {}),
        ...(courierPartner ? { courierPartner } : {}),
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      console.warn('Could not update order status in Firestore:', err);
    }

    const updater = (prev: Order[]) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              orderStatus: status,
              ...(trackingNumber ? { trackingNumber } : {}),
              ...(courierPartner ? { courierPartner } : {}),
            }
          : o
      );

    setOrders(updater);
    setAllOrders(updater);
  };

  // Coupons CRUD
  const addCoupon = (cData: Omit<Coupon, 'id'>) => {
    const newCp: Coupon = { ...cData, id: `cp-${Date.now()}` };
    setCoupons((prev) => [...prev, newCp]);
  };

  const updateCoupon = (cp: Coupon) => {
    setCoupons((prev) => prev.map((c) => (c.id === cp.id ? cp : c)));
  };

  const deleteCoupon = (id: string) => {
    setCoupons((prev) => prev.filter((c) => c.id !== id));
  };

  // Reviews CRUD
  const addReview = (review: Omit<Review, 'id' | 'date' | 'status'>) => {
    const newRev: Review = {
      ...review,
      id: `rev-${Date.now()}`,
      date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
      status: 'approved',
    };
    setReviews((prev) => [newRev, ...prev]);
  };

  const updateReviewStatus = (reviewId: string, status: 'approved' | 'pending' | 'hidden') => {
    setReviews((prev) => prev.map((r) => (r.id === reviewId ? { ...r, status } : r)));
  };

  // Settings
  const updateSettings = (newSettings: NurserySettings) => {
    setSettings(newSettings);
    try {
      setDoc(doc(db, 'settings', 'general'), newSettings);
    } catch (err) {
      console.warn('Could not save settings to Firestore:', err);
    }
  };

  const refreshData = async () => {
    await fetchProductsFromFirestore();
    if (user) {
      await fetchOrdersFromFirestore(user.id, user.role);
      if (user.role === 'admin') {
        await fetchUsersFromFirestore();
      }
    }
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        currency: '₹',
        products,
        categories,
        cart,
        wishlist,
        orders,
        allOrders,
        addresses,
        coupons,
        reviews,
        settings,
        user,
        currentUser: user,
        allUsers,
        activeCoupon,
        currentView,
        selectedProductSlug,
        selectedCategorySlug,
        trackingOrderId,
        confirmedOrder,
        searchQuery,
        authModalOpen,
        authModalMode,
        accountActiveTab,
        setAccountActiveTab,
        isFirebaseConnected,
        authLoading,
        navigateTo,
        setSearchQuery,
        openAuthModal,
        closeAuthModal,
        addToCart,
        removeFromCart,
        updateCartQty,
        updateCartQuantity,
        clearCart,
        cartCount,
        cartSubtotal,
        cartTotal,
        selectedOrderId: trackingOrderId || confirmedOrder?.id || (orders[0]?.id ?? null),
        toggleWishlist,
        removeFromWishlist,
        clearWishlist,
        moveAllWishlistToCart,
        isInWishlist,
        applyCoupon,
        removeCoupon,
        placeOrder,
        addOrder,
        addAddress,
        updateAddress,
        deleteAddress,
        setDefaultAddress,
        loginWithEmail,
        registerWithEmail,
        resetPasswordEmail,
        loginUser,
        registerUser,
        logoutUser,
        updateProfile,
        addProduct,
        updateProduct,
        deleteProduct,
        uploadImage,
        addCategory,
        updateCategory,
        deleteCategory,
        updateOrderStatus,
        addCoupon,
        updateCoupon,
        deleteCoupon,
        updateReviewStatus,
        addReview,
        updateSettings,
        refreshData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
