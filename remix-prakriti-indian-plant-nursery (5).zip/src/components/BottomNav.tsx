import React from 'react';
import { Home, Grid, Heart, ShoppingBag, User } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const BottomNav: React.FC = () => {
  const { currentView, navigateTo, cartCount, wishlist, t } = useApp();

  const navItems = [
    { id: 'home', label: t('home'), icon: Home },
    { id: 'catalog', label: t('categories'), icon: Grid },
    { id: 'wishlist', label: t('wishlist'), icon: Heart, badge: wishlist.length },
    { id: 'cart', label: t('cart'), icon: ShoppingBag, badge: cartCount },
    { id: 'account', label: t('account'), icon: User },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-stone-200 lg:hidden shadow-lg safe-area-pb">
      <div className="grid grid-cols-5 h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive =
            item.id === 'account'
              ? currentView === 'account' || currentView === 'admin' || currentView === 'login' || currentView === 'signin' || currentView === 'register' || currentView === 'signup'
              : item.id === 'catalog'
              ? currentView === 'catalog'
              : currentView === item.id;

          return (
            <button
              key={item.id}
              onClick={() => navigateTo(item.id)}
              className={`flex flex-col items-center justify-center relative transition-colors ${
                isActive ? 'text-[#154D34]' : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-2'}`} />
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-emerald-700 text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center shadow-xs">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className={`text-[10px] mt-1 tracking-tight ${isActive ? 'font-bold' : 'font-medium'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
