import React from 'react';
import { Sprout, Phone, Mail, MapPin, ShieldCheck, Heart, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Language } from '../types';

export const Footer: React.FC = () => {
  const { t, language, setLanguage, settings, navigateTo } = useApp();

  const languages: { code: Language; label: string; native: string }[] = [
    { code: 'en', label: 'English', native: 'English' },
    { code: 'hi', label: 'Hindi', native: 'हिंदी' },
    { code: 'mr', label: 'Marathi', native: 'मराठी' },
  ];

  return (
    <footer className="bg-stone-900 text-stone-300 pt-16 pb-24 lg:pb-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-stone-800">
          {/* Col 1: Brand & Story */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white shadow-md">
                <Sprout className="w-6 h-6 text-emerald-100" />
              </div>
              <div>
                <span className="font-serif text-2xl font-bold text-white tracking-tight">
                  प्रकृति
                </span>
                <span className="ml-2 text-xs uppercase tracking-wider font-semibold px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                  Prakriti Nursery
                </span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-stone-400 leading-relaxed max-w-sm">
              India’s trusted online plant nursery. We hand-nurture our plants in acclimatized greenhouses in Pune and Bengaluru, delivering green happiness across 19,000+ Indian pincodes.
            </p>

            <div className="pt-2 flex flex-wrap gap-2 text-xs">
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-stone-800 text-stone-300 border border-stone-700">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>5-Layer Plant-Safe Packing</span>
              </span>
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-stone-800 text-stone-300 border border-stone-700">
                <Sprout className="w-3.5 h-3.5 text-emerald-400" />
                <span>100% Organic Fertilizers</span>
              </span>
            </div>

            <div className="pt-3">
              <p className="text-xs font-semibold text-white mb-2">Change Language / भाषा बदला:</p>
              <div className="inline-flex bg-stone-800 rounded-full p-1 border border-stone-700">
                {languages.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => setLanguage(l.code)}
                    className={`px-3 py-1 text-xs font-semibold rounded-full transition-colors ${
                      language === l.code
                        ? 'bg-emerald-600 text-white'
                        : 'text-stone-400 hover:text-white'
                    }`}
                  >
                    {l.native}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">
              Green Categories
            </h3>
            <ul className="space-y-2 text-xs text-stone-400">
              <li>
                <button
                  onClick={() => navigateTo('catalog')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Indoor Plants (हवा शुद्ध पौधे)
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('catalog')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Medicinal & Tulsi Plants
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('catalog')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Flowering & Mogra Plants
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('catalog', { categorySlug: 'seeds' })}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Kitchen Garden Seeds
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('catalog', { categorySlug: 'pots-planters' })}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Artisan Terracotta Pots
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('catalog', { categorySlug: 'fertilizers-plant-care' })}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Pure Vermicompost & Neem Oil
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Customer Care */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">
              Customer Support
            </h3>
            <ul className="space-y-2 text-xs text-stone-400">
              <li>
                <button
                  onClick={() => navigateTo('care-guide')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Plant Care Doctor Guide
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('offers')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Festival Offers & Coupons
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('account')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Track Order & Invoices
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('login')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Sign In to Account
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('register')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Create Account (Sign Up)
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('about')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  About Our Nurseries
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('contact')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Contact & Nursery Location
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('admin')}
                  className="text-amber-400 hover:text-amber-300 font-semibold"
                >
                  Admin Management Portal
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Contact & Nursery Address */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">
              Nursery Greenhouse
            </h3>
            <div className="space-y-2 text-xs text-stone-400">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{settings.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href={`tel:${settings.phone}`} className="hover:text-white">
                  {settings.phone} (9 AM - 8 PM IST)
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href={`mailto:${settings.email}`} className="hover:text-white">
                  {settings.email}
                </a>
              </div>
              <div className="pt-2 text-[11px] text-stone-500">
                GSTIN: <span className="text-stone-300 font-mono">{settings.gstin}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar: Payments & Copyright */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <p>© {new Date().getFullYear()} {settings.name}. {t('rightsReserved')}</p>

          {/* Indian Payment Badges */}
          <div className="flex items-center flex-wrap gap-2 text-[11px]">
            <span className="text-stone-400 mr-1">Supported Payments:</span>
            <span className="px-2 py-1 bg-stone-800 text-stone-300 rounded font-semibold border border-stone-700">UPI (GPay / PhonePe / Paytm)</span>
            <span className="px-2 py-1 bg-stone-800 text-emerald-400 rounded font-bold border border-stone-700">RuPay</span>
            <span className="px-2 py-1 bg-stone-800 text-stone-300 rounded font-semibold border border-stone-700">Visa / Mastercard</span>
            <span className="px-2 py-1 bg-stone-800 text-stone-300 rounded font-semibold border border-stone-700">Net Banking</span>
            <span className="px-2 py-1 bg-stone-800 text-amber-400 rounded font-semibold border border-stone-700">COD Available</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
