import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Search,
  Heart,
  ShoppingBag,
  User as UserIcon,
  Menu,
  X,
  Sprout,
  ShieldCheck,
  ChevronDown,
  Sparkles,
  Phone,
  Settings as SettingsIcon,
  LogOut,
  PackageCheck,
  MapPin,
  Flame,
  LogIn,
  UserPlus,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Language } from '../types';
import { SafeImage } from './SafeImage';
import { detectSearchIntent, POPULAR_SEARCH_CHIPS } from '../lib/plantSearch';

export const Header: React.FC = () => {
  const {
    language,
    setLanguage,
    t,
    cartCount,
    wishlist,
    user,
    products,
    categories,
    settings,
    navigateTo,
    openAuthModal,
    logoutUser,
    setSearchQuery: setGlobalSearch,
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const [localSearch, setLocalSearch] = useState('');
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [categoryDropdownOpen, setCategoryDropdownOpen] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const categoryMenuRef = useRef<HTMLDivElement>(null);

  // Detect active search intent for the user's typed input
  const detectedIntent = localSearch.trim().length >= 2 ? detectSearchIntent(localSearch) : null;

  // Filter products and suggestions based on search & intent
  const filteredSuggestions = useMemo(() => {
    if (localSearch.trim().length < 2) return [];
    const q = localSearch.trim().toLowerCase();

    // If a specific intent is detected (e.g. 'flower', 'decorative', 'medicinal', 'fruit')
    if (detectedIntent) {
      return products
        .filter((p) => {
          if (detectedIntent.specialFilter && detectedIntent.specialFilter(p)) return true;
          if (detectedIntent.categoryMatch && p.category.toLowerCase() === detectedIntent.categoryMatch.toLowerCase()) return true;
          return (
            p.name.toLowerCase().includes(q) ||
            (p.commonIndianName && p.commonIndianName.toLowerCase().includes(q)) ||
            (p.searchKeywords && p.searchKeywords.some((k) => k.toLowerCase().includes(q)))
          );
        })
        .slice(0, 6);
    }

    // Standard multi-field matching
    return products
      .filter((p) => {
        return (
          p.name.toLowerCase().includes(q) ||
          (p.nameHi && p.nameHi.toLowerCase().includes(q)) ||
          (p.nameMr && p.nameMr.toLowerCase().includes(q)) ||
          (p.commonIndianName && p.commonIndianName.toLowerCase().includes(q)) ||
          (p.scientificName && p.scientificName.toLowerCase().includes(q)) ||
          p.category.toLowerCase().includes(q) ||
          (p.searchKeywords && p.searchKeywords.some((k) => k.toLowerCase().includes(q)))
        );
      })
      .slice(0, 6);
  }, [localSearch, detectedIntent, products]);

  // Close search suggestions and user dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setSearchFocused(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setUserMenuOpen(false);
      }
      if (categoryMenuRef.current && !categoryMenuRef.current.contains(event.target as Node)) {
        setCategoryDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (localSearch.trim()) {
      setGlobalSearch(localSearch.trim());
      navigateTo('catalog');
      setSearchFocused(false);
    }
  };

  const handleSuggestionClick = (slug: string) => {
    navigateTo('product-detail', { productSlug: slug });
    setSearchFocused(false);
    setLocalSearch('');
  };

  const handleQuickChipSearch = (query: string) => {
    setLocalSearch(query);
    setGlobalSearch(query);
    navigateTo('catalog');
    setSearchFocused(false);
  };

  const languages: { code: Language; label: string; native: string }[] = [
    { code: 'en', label: 'English', native: 'English' },
    { code: 'hi', label: 'Hindi', native: 'हिंदी' },
    { code: 'mr', label: 'Marathi', native: 'मराठी' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white shadow-sm border-b border-stone-200">
      {/* Top Announcement Bar */}
      <div className="bg-[#154D34] text-[#EBF4EE] text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-1 text-center sm:text-left">
          <div className="flex items-center justify-center gap-2 font-medium">
            <span className="inline-block animate-pulse text-amber-300">★</span>
            <span>{settings.announcementText || t('announcement')}</span>
          </div>
          <div className="hidden md:flex items-center gap-4 text-emerald-100">
            <a href={`tel:${settings.phone}`} className="flex items-center gap-1 hover:text-white transition-colors">
              <Phone className="w-3.5 h-3.5" />
              <span>{settings.phone}</span>
            </a>
            <span className="text-emerald-300">|</span>
            <button
              onClick={() => navigateTo('admin')}
              className="flex items-center gap-1 text-amber-300 hover:text-amber-200 font-semibold transition-colors"
            >
              <SettingsIcon className="w-3.5 h-3.5" />
              <span>{t('adminPanel')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex items-center justify-between gap-2 sm:gap-6">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="p-2 -ml-2 text-stone-700 hover:text-[#154D34] lg:hidden focus:outline-none"
              aria-label="Open mobile navigation menu"
            >
              <Menu className="w-6 h-6" />
            </button>

            <button
              onClick={() => navigateTo('home')}
              className="flex items-center gap-2.5 text-left group"
            >
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-br from-[#154D34] to-[#276F4C] flex items-center justify-center text-white shadow-md group-hover:scale-105 transition-transform">
                <Sprout className="w-6 h-6 text-emerald-200" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-[#0D3222]">
                    प्रकृति
                  </span>
                  <span className="text-xs uppercase tracking-widest font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-900">
                    Prakriti
                  </span>
                </div>
                <p className="text-[10px] sm:text-xs text-stone-700 tracking-wide">
                  Indian Modern Plant Nursery
                </p>
              </div>
            </button>
          </div>

          {/* Central Search Bar with Live Suggestions */}
          <div ref={searchContainerRef} className="hidden md:flex flex-1 max-w-xl relative">
            <form onSubmit={handleSearchSubmit} className="w-full relative">
              <input
                type="text"
                value={localSearch}
                onChange={(e) => setLocalSearch(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                placeholder={t('searchPlaceholder')}
                className="w-full pl-10 pr-24 py-2.5 bg-stone-50 hover:bg-stone-100/80 focus:bg-white text-stone-800 text-sm rounded-full border border-stone-300 focus:border-[#154D34] focus:ring-2 focus:ring-[#154D34]/20 transition-all outline-none"
              />
              <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <button
                type="submit"
                className="absolute right-1.5 top-1/2 -translate-y-1/2 px-4 py-1.5 bg-[#154D34] hover:bg-[#0D3222] text-white text-xs font-medium rounded-full transition-colors"
              >
                {t('search')}
              </button>
            </form>

            {/* Suggestions dropdown */}
            {searchFocused && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl border border-stone-200 overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                {/* Detected Intent Banner */}
                {detectedIntent && (
                  <div className="bg-emerald-50/90 border-b border-emerald-100 p-3 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-[#154D34] shrink-0" />
                      <div>
                        <div className="text-xs font-bold text-[#154D34]">
                          {language === 'hi' ? detectedIntent.labelHi : language === 'mr' ? detectedIntent.labelMr : detectedIntent.label}
                        </div>
                        <div className="text-[11px] text-stone-600 line-clamp-1">
                          {detectedIntent.description}
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setGlobalSearch(localSearch.trim());
                        navigateTo('catalog');
                        setSearchFocused(false);
                      }}
                      className="text-[11px] font-bold text-white bg-[#154D34] hover:bg-[#0D3222] px-2.5 py-1 rounded-full shrink-0 ml-2"
                    >
                      View All
                    </button>
                  </div>
                )}

                {filteredSuggestions.length > 0 ? (
                  <div className="p-2">
                    <div className="text-[11px] font-semibold text-stone-400 px-3 py-1 uppercase tracking-wider flex items-center justify-between">
                      <span>Matching Indian Plants ({filteredSuggestions.length})</span>
                      <span className="text-[10px] text-emerald-700 font-medium">Nursery Live Stock</span>
                    </div>
                    {filteredSuggestions.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => handleSuggestionClick(item.slug)}
                        className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-stone-50 transition-colors text-left group"
                      >
                        <div className="flex items-center gap-3">
                          <SafeImage
                            src={item.images[0]}
                            alt={item.name}
                            className="w-11 h-11 rounded-lg object-cover border border-stone-100 shrink-0"
                          />
                          <div>
                            <div className="text-sm font-semibold text-stone-800 group-hover:text-[#154D34] flex items-center gap-1.5 flex-wrap">
                              <span>{item.name}</span>
                              {item.commonIndianName && (
                                <span className="text-xs font-medium text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                                  {item.commonIndianName}
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-stone-400 flex items-center gap-2">
                              <span>{item.category}</span>
                              {item.scientificName && (
                                <>
                                  <span>•</span>
                                  <span className="italic text-stone-400 text-[11px]">{item.scientificName}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="text-right shrink-0 pl-2">
                          <div className="text-sm font-bold text-[#154D34]">
                            ₹{item.price}
                          </div>
                          {item.mrp && item.mrp > item.price && (
                            <div className="text-[10px] text-stone-400 line-through">
                              ₹{item.mrp}
                            </div>
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                ) : localSearch.trim().length > 1 ? (
                  <div className="p-4 text-center">
                    <p className="text-sm font-medium text-stone-700">No exact plant found for "{localSearch}".</p>
                    <p className="text-xs text-stone-500 mt-1">Try searching "Flower Plant", "Indoor Plant", "Tulsi", "Medicinal Plant", or "Rose".</p>
                    <button
                      type="button"
                      onClick={() => handleQuickChipSearch(localSearch.trim())}
                      className="mt-3 px-3 py-1.5 bg-[#154D34] text-white text-xs font-semibold rounded-full hover:bg-[#0D3222]"
                    >
                      Browse full nursery catalog
                    </button>
                  </div>
                ) : (
                  <div className="p-3">
                    <div className="text-[11px] font-semibold text-stone-400 px-2 py-1 uppercase tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      <span>Popular Nursery Searches</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5 p-2">
                      {POPULAR_SEARCH_CHIPS.map((chip) => (
                        <button
                          key={chip.query}
                          type="button"
                          onClick={() => handleQuickChipSearch(chip.query)}
                          className="px-3 py-1.5 rounded-full text-xs font-medium bg-stone-100 hover:bg-emerald-100/70 hover:text-[#154D34] text-stone-700 border border-stone-200/60 transition-all"
                        >
                          {chip.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right Controls: Language Selector + Wishlist + Cart + Account */}
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Prominent Language Selector */}
            <div className="flex items-center bg-stone-100 rounded-full p-0.5 border border-stone-200">
              {languages.map((l) => {
                const isActive = language === l.code;
                return (
                  <button
                    key={l.code}
                    onClick={() => setLanguage(l.code)}
                    className={`px-2.5 py-1 text-xs rounded-full font-medium transition-all ${
                      isActive
                        ? 'bg-[#154D34] text-white shadow-xs'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                    title={l.label}
                  >
                    {l.native}
                  </button>
                );
              })}
            </div>

            {/* Wishlist Button */}
            <button
              onClick={() => navigateTo('wishlist')}
              className="relative p-2 text-stone-700 hover:text-rose-600 hover:bg-rose-50 rounded-full transition-colors hidden sm:flex"
              title={t('wishlist')}
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart Button */}
            <button
              onClick={() => navigateTo('cart')}
              className="relative p-2 text-stone-700 hover:text-[#154D34] hover:bg-emerald-50 rounded-full transition-colors flex items-center"
              title={t('cart')}
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#154D34] text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Account / User Menu */}
            <div ref={userMenuRef} className="relative">
              {user ? (
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 p-1 pl-2 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-full transition-colors"
                >
                  <SafeImage
                    src={user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                    alt={user.name}
                    className="w-7 h-7 rounded-full object-cover border border-[#154D34]/30"
                  />
                  <span className="text-xs font-semibold text-stone-700 max-w-[80px] truncate hidden md:inline">
                    {user.name.split(' ')[0]}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-stone-400 mr-1" />
                </button>
              ) : (
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <button
                    onClick={() => navigateTo('login')}
                    className="flex items-center gap-1 px-3 py-1.5 text-stone-700 hover:text-[#154D34] hover:bg-emerald-50 rounded-full text-xs font-semibold transition-colors border border-stone-200 shadow-2xs"
                    title="Sign In to your account"
                  >
                    <LogIn className="w-3.5 h-3.5 text-[#154D34]" />
                    <span>Sign In</span>
                  </button>
                  <button
                    onClick={() => navigateTo('register')}
                    className="flex items-center gap-1 px-3 py-1.5 bg-[#154D34] hover:bg-[#0D3222] text-white text-xs font-bold rounded-full shadow-xs transition-colors"
                    title="Create a new account"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>Sign Up</span>
                  </button>
                </div>
              )}

              {/* User Dropdown */}
              {user && userMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-stone-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="px-4 py-2.5 border-b border-stone-100">
                    <p className="text-xs text-stone-400">Signed in as</p>
                    <p className="text-sm font-bold text-stone-800 truncate">{user.name}</p>
                    <span className="inline-block mt-1 text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                      {user.role === 'admin' ? 'Nursery Admin' : 'Verified Plant Parent'}
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      navigateTo('account');
                      setUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-medium text-stone-700 hover:bg-emerald-50 hover:text-[#154D34] transition-colors text-left"
                  >
                    <UserIcon className="w-4 h-4" />
                    <span>{t('profileDetails')}</span>
                  </button>

                  <button
                    onClick={() => {
                      navigateTo('account');
                      setUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-medium text-stone-700 hover:bg-emerald-50 hover:text-[#154D34] transition-colors text-left"
                  >
                    <PackageCheck className="w-4 h-4" />
                    <span>{t('myOrders')}</span>
                  </button>

                  <button
                    onClick={() => {
                      navigateTo('wishlist');
                      setUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-medium text-stone-700 hover:bg-emerald-50 hover:text-[#154D34] transition-colors text-left"
                  >
                    <Heart className="w-4 h-4 text-rose-500" />
                    <span>{t('wishlist')} ({wishlist.length})</span>
                  </button>

                  <button
                    onClick={() => {
                      navigateTo('account');
                      setUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-medium text-stone-700 hover:bg-emerald-50 hover:text-[#154D34] transition-colors text-left"
                  >
                    <MapPin className="w-4 h-4" />
                    <span>{t('savedAddresses')}</span>
                  </button>

                  <div className="border-t border-stone-100 my-1"></div>

                  <button
                    onClick={() => {
                      navigateTo('admin');
                      setUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-semibold text-amber-700 hover:bg-amber-50 transition-colors text-left"
                  >
                    <SettingsIcon className="w-4 h-4" />
                    <span>{t('adminPanel')}</span>
                  </button>

                  <button
                    onClick={() => {
                      logoutUser();
                      setUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-medium text-rose-600 hover:bg-rose-50 transition-colors text-left"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>{t('logout')}</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Search Input */}
        <div className="mt-3 md:hidden">
          <form onSubmit={handleSearchSubmit} className="relative">
            <input
              type="text"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              placeholder={t('searchPlaceholder')}
              className="w-full pl-9 pr-20 py-2 bg-stone-100 text-stone-800 text-xs rounded-full border border-stone-200 outline-none focus:bg-white focus:border-[#154D34]"
            />
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <button
              type="submit"
              className="absolute right-1 top-1/2 -translate-y-1/2 px-3 py-1 bg-[#154D34] text-white text-[11px] font-medium rounded-full"
            >
              {t('search')}
            </button>
          </form>

          {/* Quick Search Chips on Mobile */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-2 mt-1">
            {POPULAR_SEARCH_CHIPS.slice(0, 6).map((chip) => (
              <button
                key={chip.query}
                type="button"
                onClick={() => handleQuickChipSearch(chip.query)}
                className="whitespace-nowrap px-2.5 py-1 rounded-full text-[11px] font-medium bg-stone-100 hover:bg-emerald-100 text-stone-700 shrink-0 border border-stone-200/60"
              >
                {chip.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Desktop Navigation Links */}
      <nav className="hidden lg:block border-t border-stone-100 bg-[#FAF8F5]/80 backdrop-blur-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ul className="flex items-center justify-between py-2 text-xs font-semibold text-stone-700">
            <li>
              <button
                onClick={() => navigateTo('home')}
                className="py-1 px-2.5 rounded-lg hover:text-[#154D34] hover:bg-emerald-100/50 transition-colors"
              >
                {t('home')}
              </button>
            </li>
            <li ref={categoryMenuRef} className="relative">
              <button
                onClick={() => setCategoryDropdownOpen(!categoryDropdownOpen)}
                className={`flex items-center gap-1 py-1 px-2.5 rounded-lg transition-colors ${
                  categoryDropdownOpen
                    ? 'bg-[#154D34] text-white'
                    : 'hover:text-[#154D34] hover:bg-emerald-100/50 text-stone-800'
                }`}
              >
                <Sprout className="w-3.5 h-3.5 text-emerald-600" />
                <span>Categories ({categories.length})</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${categoryDropdownOpen ? 'rotate-180 text-white' : 'text-stone-400'}`} />
              </button>

              {/* Categories Mega Dropdown */}
              {categoryDropdownOpen && (
                <div className="absolute left-0 top-full mt-2 w-[720px] max-w-[90vw] bg-white rounded-3xl shadow-2xl border border-stone-200 p-5 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="flex items-center justify-between pb-3 mb-3 border-b border-stone-100">
                    <div>
                      <h4 className="font-serif text-sm font-bold text-stone-900">
                        Indian Plant Categories (भारतीय वनस्पति श्रेणियाँ)
                      </h4>
                      <p className="text-[11px] text-stone-500">
                        Select a category to browse healthy plants for Indian homes, gardens & balconies
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        navigateTo('catalog');
                        setCategoryDropdownOpen(false);
                      }}
                      className="text-xs font-bold text-[#154D34] hover:underline"
                    >
                      View All Plants →
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-2.5 max-h-[380px] overflow-y-auto pr-1">
                    {categories.map((cat) => {
                      const catName =
                        language === 'hi' ? cat.nameHi : language === 'mr' ? cat.nameMr : cat.name;
                      return (
                        <button
                          key={cat.id}
                          onClick={() => {
                            navigateTo('catalog', { categorySlug: cat.slug });
                            setCategoryDropdownOpen(false);
                          }}
                          className="flex items-center gap-3 p-2 rounded-2xl hover:bg-emerald-50/80 border border-transparent hover:border-emerald-200 transition-all text-left group"
                        >
                          <div className="w-11 h-11 rounded-xl overflow-hidden bg-stone-100 shrink-0 border border-stone-200 group-hover:scale-105 transition-transform">
                            <SafeImage src={cat.image} alt={cat.name} className="w-full h-full object-cover" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-stone-800 group-hover:text-[#154D34] truncate">
                              {catName}
                            </p>
                            <p className="text-[10px] text-stone-500 truncate">
                              {cat.count || 10}+ species
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </li>
            <li>
              <button
                onClick={() => navigateTo('catalog')}
                className="py-1 px-2.5 rounded-lg hover:text-[#154D34] hover:bg-emerald-100/50 transition-colors"
              >
                {t('plants')}
              </button>
            </li>
            <li>
              <button
                onClick={() => navigateTo('catalog', { categorySlug: 'seeds' })}
                className="py-1 px-2.5 rounded-lg hover:text-[#154D34] hover:bg-emerald-100/50 transition-colors"
              >
                {t('seeds')}
              </button>
            </li>
            <li>
              <button
                onClick={() => navigateTo('catalog', { categorySlug: 'pots-planters' })}
                className="py-1 px-2.5 rounded-lg hover:text-[#154D34] hover:bg-emerald-100/50 transition-colors"
              >
                {t('pots')}
              </button>
            </li>
            <li>
              <button
                onClick={() => navigateTo('catalog', { categorySlug: 'fertilizers-plant-care' })}
                className="py-1 px-2.5 rounded-lg hover:text-[#154D34] hover:bg-emerald-100/50 transition-colors"
              >
                {t('gardening')}
              </button>
            </li>
            <li>
              <button
                onClick={() => navigateTo('care-guide')}
                className="py-1 px-2.5 rounded-lg hover:text-[#154D34] hover:bg-emerald-100/50 transition-colors"
              >
                {t('plantCare')}
              </button>
            </li>
            <li>
              <button
                onClick={() => navigateTo('offers')}
                className="flex items-center gap-1 py-1 px-2.5 rounded-lg text-rose-700 bg-rose-50 hover:bg-rose-100 transition-colors"
              >
                <Flame className="w-3.5 h-3.5 text-rose-600 fill-rose-600" />
                <span>{t('offers')}</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => navigateTo('about')}
                className="py-1 px-2.5 rounded-lg hover:text-[#154D34] hover:bg-emerald-100/50 transition-colors"
              >
                {t('aboutUs')}
              </button>
            </li>
            <li>
              <button
                onClick={() => navigateTo('contact')}
                className="py-1 px-2.5 rounded-lg hover:text-[#154D34] hover:bg-emerald-100/50 transition-colors"
              >
                {t('contactUs')}
              </button>
            </li>
            <li className="border-l border-stone-200 pl-3">
              <button
                onClick={() => navigateTo('admin')}
                className="flex items-center gap-1.5 py-1 px-3 rounded-full bg-stone-800 hover:bg-stone-900 text-amber-300 transition-colors font-bold text-[11px]"
              >
                <SettingsIcon className="w-3 h-3" />
                <span>Admin Suite</span>
              </button>
            </li>
          </ul>
        </div>
      </nav>

      {/* Mobile Drawer Navigation Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative w-4/5 max-w-sm bg-white h-full shadow-2xl flex flex-col z-10 overflow-y-auto">
            <div className="p-4 border-b border-stone-100 flex items-center justify-between bg-emerald-50/50">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-[#154D34] flex items-center justify-center text-white">
                  <Sprout className="w-5 h-5 text-emerald-200" />
                </div>
                <div>
                  <span className="font-serif font-bold text-lg text-[#0D3222]">प्रकृति नर्सरी</span>
                  <p className="text-[10px] text-stone-500">Prakriti Plant Nursery</p>
                </div>
              </div>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-1 rounded-full text-stone-400 hover:text-stone-700"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* User Profile or Sign In/Up Banner in Mobile Drawer */}
            {!user ? (
              <div className="p-4 border-b border-stone-100 bg-emerald-50/60">
                <p className="text-xs font-bold text-stone-900 mb-0.5">Welcome Plant Parent!</p>
                <p className="text-[11px] text-stone-500 mb-3">Sign in or register to track orders, wishlist & save delivery addresses.</p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      navigateTo('login');
                    }}
                    className="py-2 px-3 text-center bg-white hover:bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-800 transition-colors flex items-center justify-center gap-1.5 shadow-2xs"
                  >
                    <LogIn className="w-3.5 h-3.5 text-[#154D34]" />
                    <span>Sign In</span>
                  </button>
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      navigateTo('register');
                    }}
                    className="py-2 px-3 text-center bg-[#154D34] hover:bg-[#0D3222] text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>Sign Up</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-4 border-b border-stone-100 bg-emerald-50/40 flex items-center justify-between">
                <div
                  className="flex items-center gap-2.5 cursor-pointer"
                  onClick={() => {
                    navigateTo('account');
                    setMobileMenuOpen(false);
                  }}
                >
                  <SafeImage
                    src={user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                    alt={user.name}
                    className="w-9 h-9 rounded-full object-cover border border-[#154D34]/30"
                  />
                  <div className="overflow-hidden">
                    <p className="text-xs font-bold text-stone-800 truncate">{user.name}</p>
                    <p className="text-[10px] text-stone-500 truncate max-w-[150px]">{user.email}</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    logoutUser();
                    setMobileMenuOpen(false);
                  }}
                  className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-white transition-colors"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Language Selector in Mobile Drawer */}
            <div className="p-4 border-b border-stone-100 bg-stone-50">
              <p className="text-xs font-medium text-stone-500 mb-2">Select Language / भाषा चुनें</p>
              <div className="grid grid-cols-3 gap-1 bg-white p-1 rounded-xl border border-stone-200">
                {languages.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => setLanguage(l.code)}
                    className={`py-1.5 text-xs font-semibold rounded-lg text-center ${
                      language === l.code ? 'bg-[#154D34] text-white' : 'text-stone-600'
                    }`}
                  >
                    {l.native}
                  </button>
                ))}
              </div>
            </div>

            {/* Nav links */}
            <div className="p-4 space-y-1 flex-1">
              {[
                { label: t('home'), view: 'home' },
                { label: t('plants'), view: 'catalog' },
                { label: `${t('wishlist')} (${wishlist.length})`, view: 'wishlist' },
                { label: t('seeds'), view: 'catalog', cat: 'seeds' },
                { label: t('pots'), view: 'catalog', cat: 'pots-planters' },
                { label: t('gardening'), view: 'catalog', cat: 'fertilizers-plant-care' },
                { label: t('plantCare'), view: 'care-guide' },
                { label: t('offers'), view: 'offers' },
                { label: t('aboutUs'), view: 'about' },
                { label: t('contactUs'), view: 'contact' },
              ].map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    navigateTo(item.view, item.cat ? { categorySlug: item.cat } : undefined);
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2.5 rounded-xl text-sm font-semibold text-stone-700 hover:bg-emerald-50 hover:text-[#154D34] transition-colors"
                >
                  {item.label}
                </button>
              ))}

              {/* Mobile Categories Quick Picker */}
              <div className="pt-3 pb-1">
                <p className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 px-3 mb-2">
                  All Plant Categories ({categories.length})
                </p>
                <div className="grid grid-cols-2 gap-1.5 px-1">
                  {categories.map((c) => {
                    const cName = language === 'hi' ? c.nameHi : language === 'mr' ? c.nameMr : c.name;
                    return (
                      <button
                        key={c.id}
                        onClick={() => {
                          navigateTo('catalog', { categorySlug: c.slug });
                          setMobileMenuOpen(false);
                        }}
                        className="flex items-center gap-2 p-2 rounded-xl bg-stone-50 hover:bg-emerald-50 border border-stone-200/70 text-left text-xs text-stone-700 hover:text-[#154D34] font-medium"
                      >
                        <SafeImage src={c.image} alt={c.name} className="w-6 h-6 rounded-md object-cover shrink-0" />
                        <span className="truncate">{cName}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="pt-4 border-t border-stone-100">
                <button
                  onClick={() => {
                    navigateTo('admin');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-stone-900 text-amber-300 text-sm font-bold"
                >
                  <span>Admin Panel</span>
                  <SettingsIcon className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Footer in Drawer */}
            <div className="p-4 border-t border-stone-100 bg-stone-50 text-xs text-stone-500">
              <p className="font-semibold text-stone-700">Need nursery assistance?</p>
              <p className="mt-1">Call: {settings.phone}</p>
              <p>Email: {settings.email}</p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
