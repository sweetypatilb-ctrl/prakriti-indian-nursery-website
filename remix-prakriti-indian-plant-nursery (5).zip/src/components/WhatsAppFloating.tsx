import React, { useState } from 'react';
import { MessageCircle, X, Send, Sparkles, Sprout, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const WhatsAppFloating: React.FC = () => {
  const { settings, language, t } = useApp();
  const [open, setOpen] = useState(false);
  const [customQuery, setCustomQuery] = useState('');

  const cleanPhone = settings.whatsappNumber.replace(/[^0-9]/g, '');

  const quickOptions = [
    {
      en: '🌿 Which plant is best for low light balconies?',
      hi: '🌿 कम धूप वाली बालकनी के लिए कौन सा पौधा सबसे अच्छा है?',
      mr: '🌿 कमी सूर्यप्रकाश असलेल्या बाल्कनीसाठी कोणते रोप उत्तम आहे?',
    },
    {
      en: '🚚 Can I check delivery timeline for my pincode?',
      hi: '🚚 क्या मेरे पिनकोड के लिए डिलीवरी का समय पता चल सकता है?',
      mr: '🚚 माझ्या पिनकोडवर डिलिव्हरी किती दिवसांत होईल?',
    },
    {
      en: '🌱 How to safely repot my newly arrived plant?',
      hi: '🌱 नए आए पौधे को सुरक्षित रूप से गमले में कैसे लगाएं?',
      mr: '🌱 नवीन आणलेले रोप कुंडीमध्ये सुरक्षित कसे लावावे?',
    },
    {
      en: '🎁 Do you provide corporate / festival gift plants?',
      hi: '🎁 क्या आप त्योहार और कॉर्पोरेट उपहार के पौधे उपलब्ध कराते हैं?',
      mr: '🎁 तुम्ही सणांसाठी व कॉर्पोरेट भेटवस्तूंसाठी रोपे देता का?',
    },
  ];

  const handleSendWhatsApp = (text: string) => {
    const encoded = encodeURIComponent(text);
    const url = `https://wa.me/${cleanPhone}?text=${encoded}`;
    window.open(url, '_blank', 'noopener,noreferrer');
    setOpen(false);
  };

  return (
    <div className="fixed bottom-20 lg:bottom-6 right-4 lg:right-6 z-40">
      {/* Dialog Popup */}
      {open && (
        <div className="mb-3 w-80 sm:w-88 bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200">
          {/* Header */}
          <div className="bg-[#154D34] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-emerald-800 flex items-center justify-center border-2 border-emerald-400">
                  <Sprout className="w-5 h-5 text-emerald-200" />
                </div>
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 border-2 border-white rounded-full"></span>
              </div>
              <div>
                <div className="text-sm font-bold flex items-center gap-1">
                  <span>Prakriti Nursery Expert</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                </div>
                <p className="text-[11px] text-emerald-200">Online | Typically replies in 5 mins</p>
              </div>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="p-4 bg-stone-50 max-h-80 overflow-y-auto space-y-2.5">
            <div className="bg-white p-3 rounded-2xl rounded-tl-none border border-stone-200 text-xs text-stone-700 shadow-xs">
              <p className="font-semibold text-[#154D34] mb-1">
                Namaste! Welcome to Prakriti Indian Nursery.
              </p>
              <p>{t('whatsappHelp')}</p>
            </div>

            <p className="text-[10px] font-semibold text-stone-400 uppercase tracking-wider px-1">
              Quick Questions / त्वरित प्रश्न
            </p>

            <div className="space-y-1.5">
              {quickOptions.map((opt, i) => {
                const message = opt[language] || opt.en;
                return (
                  <button
                    key={i}
                    onClick={() => handleSendWhatsApp(message)}
                    className="w-full text-left p-2.5 text-xs bg-white hover:bg-emerald-50 text-stone-700 hover:text-[#154D34] rounded-xl border border-stone-200 hover:border-emerald-300 transition-colors flex items-center justify-between group"
                  >
                    <span className="line-clamp-2">{message}</span>
                    <Send className="w-3.5 h-3.5 text-stone-300 group-hover:text-[#154D34] shrink-0 ml-2" />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Footer input */}
          <div className="p-3 bg-white border-t border-stone-100 flex items-center gap-2">
            <input
              type="text"
              value={customQuery}
              onChange={(e) => setCustomQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && customQuery.trim()) {
                  handleSendWhatsApp(customQuery.trim());
                }
              }}
              placeholder="Type your question..."
              className="flex-1 px-3 py-2 text-xs bg-stone-100 border border-stone-200 rounded-xl focus:outline-none focus:border-[#154D34]"
            />
            <button
              onClick={() => {
                if (customQuery.trim()) handleSendWhatsApp(customQuery.trim());
              }}
              className="p-2 bg-[#25D366] hover:bg-[#1EBE5D] text-white rounded-xl shadow-xs transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Floating Action Button */}
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-4 py-3 bg-[#25D366] hover:bg-[#20bd5a] text-white rounded-full shadow-xl hover:shadow-2xl transition-all transform hover:scale-105 group font-medium text-xs sm:text-sm"
        aria-label="Chat with Nursery on WhatsApp"
      >
        <MessageCircle className="w-5 h-5 fill-white text-emerald-600" />
        <span className="font-semibold hidden sm:inline">WhatsApp Help</span>
      </button>
    </div>
  );
};
