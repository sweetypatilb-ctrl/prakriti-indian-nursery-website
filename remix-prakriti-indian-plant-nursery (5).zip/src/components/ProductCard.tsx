import React from 'react';
import { Heart, Star, ShoppingBag, Zap, Check, AlertCircle } from 'lucide-react';
import { Product } from '../types';
import { useApp } from '../context/AppContext';
import { SafeImage } from './SafeImage';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { language, t, addToCart, toggleWishlist, isInWishlist, navigateTo } = useApp();

  const isLiked = isInWishlist(product.id);
  const safePrice = Number(product.price ?? (product as any)?.priceInINR) || 0;
  const safeMrp = Number(product.mrp) || Math.round(safePrice * 1.3);
  const discountPercent = safeMrp > safePrice ? Math.round(((safeMrp - safePrice) / safeMrp) * 100) : 0;
  const savings = Math.max(0, safeMrp - safePrice);

  const subName = language === 'hi' ? product.nameHi : language === 'mr' ? product.nameMr : null;

  const handleCardClick = () => {
    navigateTo('product-detail', { productSlug: product.slug });
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
    navigateTo('checkout');
  };

  const handleToggleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  return (
    <div
      onClick={handleCardClick}
      className="group bg-white rounded-2xl border border-stone-200/80 hover:border-emerald-300 shadow-xs hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col cursor-pointer"
    >
      {/* Product Image & Badges */}
      <div className="relative aspect-square w-full bg-stone-100 overflow-hidden">
        <SafeImage
          src={product.images && product.images.length > 0 ? product.images[0] : undefined}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />

        {/* Discount Tag */}
        {discountPercent > 0 && (
          <div className="absolute top-2.5 left-2.5 bg-rose-600 text-white text-[11px] font-bold px-2 py-0.5 rounded-md shadow-xs">
            {discountPercent}% OFF
          </div>
        )}

        {/* Stock status tag if low */}
        {product.stock <= 15 && product.stock > 0 && (
          <div className="absolute bottom-2.5 left-2.5 bg-amber-500/90 text-white text-[10px] font-semibold px-2 py-0.5 rounded backdrop-blur-xs flex items-center gap-1">
            <AlertCircle className="w-3 h-3" />
            <span>Only {product.stock} left</span>
          </div>
        )}

        {/* Wishlist Button */}
        <button
          onClick={handleToggleLike}
          className={`absolute top-2.5 right-2.5 p-2 rounded-full backdrop-blur-xs transition-colors ${
            isLiked
              ? 'bg-rose-50 text-rose-600'
              : 'bg-white/85 text-stone-600 hover:text-rose-600 hover:bg-white'
          }`}
          aria-label="Wishlist"
        >
          <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-600 stroke-rose-600' : ''}`} />
        </button>
      </div>

      {/* Product Details */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-1">
        {/* Category & Rating */}
        <div className="flex items-center justify-between text-xs text-stone-600 mb-1">
          <span className="font-semibold text-emerald-800 text-[11px] uppercase tracking-wider truncate max-w-[120px]">
            {product.category}
          </span>
          <div className="flex items-center gap-1 bg-amber-50 text-amber-900 px-1.5 py-0.5 rounded font-bold text-[11px]">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span>{product.rating}</span>
            <span className="text-stone-500 font-normal">({product.reviewCount})</span>
          </div>
        </div>

        {/* Plant Name & Indian Common Name */}
        <div className="flex items-start justify-between gap-1 mb-1">
          <h3 className="text-sm sm:text-base font-bold text-stone-900 group-hover:text-[#154D34] transition-colors line-clamp-1">
            {product.name}
          </h3>
        </div>

        {/* Indian Common Name Badge */}
        {product.commonIndianName && (
          <div className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md inline-block w-fit mb-1.5">
            {product.commonIndianName}
          </div>
        )}

        {/* Plant quick traits (Sunlight / Environment / Care / Flower Color & Season) */}
        <div className="flex items-center gap-1.5 flex-wrap text-[10px] text-stone-500 mb-2">
          {product.flowerColor && (
            <span className="bg-rose-50 text-rose-700 px-1.5 py-0.5 rounded font-medium flex items-center gap-1 border border-rose-100">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0 inline-block"></span>
              <span>{product.flowerColor}</span>
            </span>
          )}
          {product.floweringSeason && (
            <span className="bg-amber-50 text-amber-800 px-1.5 py-0.5 rounded font-medium border border-amber-100">
              {product.floweringSeason}
            </span>
          )}
          {product.environment && (
            <span className="bg-stone-100 px-1.5 py-0.5 rounded text-stone-600 font-medium">
              {product.environment}
            </span>
          )}
          {product.sunlightRequirement && (
            <span className="bg-stone-100 text-stone-700 px-1.5 py-0.5 rounded font-medium">
              {product.sunlightRequirement}
            </span>
          )}
          {product.maintenanceLevel && (
            <span className="bg-emerald-50 text-emerald-800 px-1.5 py-0.5 rounded font-medium">
              {product.maintenanceLevel} care
            </span>
          )}
        </div>

        {/* Short description snippet */}
        <p className="text-xs text-stone-600 line-clamp-2 mt-0.5 mb-3 flex-1 leading-relaxed">
          {language === 'hi' && product.descriptionHi
            ? product.descriptionHi
            : language === 'mr' && product.descriptionMr
            ? product.descriptionMr
            : product.description}
        </p>

        {/* Price Section */}
        <div className="flex items-baseline gap-2 mb-3">
          <span className="text-base sm:text-lg font-bold text-stone-900">
            ₹{safePrice.toLocaleString('en-IN')}
          </span>
          <span className="text-xs text-stone-400 line-through">
            ₹{safeMrp.toLocaleString('en-IN')}
          </span>
          {savings > 0 && (
            <span className="text-[11px] font-semibold text-emerald-700">
              Save ₹{savings.toLocaleString('en-IN')}
            </span>
          )}
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2 mt-auto">
          <button
            onClick={handleAddToCart}
            className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-xl text-xs font-semibold bg-stone-100 hover:bg-emerald-50 text-stone-800 hover:text-[#154D34] border border-stone-200 hover:border-emerald-300 transition-colors"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span className="truncate">{t('addToCart')}</span>
          </button>
          <button
            onClick={handleBuyNow}
            className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-xl text-xs font-semibold bg-[#154D34] hover:bg-[#0D3222] text-white shadow-xs transition-colors"
          >
            <Zap className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
            <span className="truncate">{t('buyNow')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
