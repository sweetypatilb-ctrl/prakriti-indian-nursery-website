import React, { useState } from 'react';
import { MapPin, CheckCircle2, Truck, AlertCircle, Calendar } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const PincodeChecker: React.FC = () => {
  const { t } = useApp();
  const [pincode, setPincode] = useState('');
  const [result, setResult] = useState<{
    checked: boolean;
    valid: boolean;
    city?: string;
    state?: string;
    deliveryDays?: number;
    cod: boolean;
    estDate?: string;
  } | null>(null);

  // Common Indian cities & estimated delivery rules
  const handleCheck = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPin = pincode.trim();
    if (cleanPin.length !== 6 || !/^\d{6}$/.test(cleanPin)) {
      setResult({ checked: true, valid: false, cod: false });
      return;
    }

    // Determine realistic location from first digits of pincode
    const prefix = cleanPin.substring(0, 2);
    let city = 'Maharashtra Region';
    let state = 'Maharashtra';
    let days = 3;

    if (prefix === '40' || prefix === '41' || prefix === '42' || prefix === '43' || prefix === '44') {
      city = prefix === '40' ? 'Mumbai' : prefix === '41' ? 'Pune' : 'Maharashtra';
      state = 'Maharashtra';
      days = 2; // Near nursery greenhouse
    } else if (prefix === '11') {
      city = 'New Delhi';
      state = 'Delhi NCR';
      days = 3;
    } else if (prefix === '56' || prefix === '57') {
      city = 'Bengaluru';
      state = 'Karnataka';
      days = 2; // Near South greenhouse
    } else if (prefix === '50') {
      city = 'Hyderabad';
      state = 'Telangana';
      days = 3;
    } else if (prefix === '60') {
      city = 'Chennai';
      state = 'Tamil Nadu';
      days = 3;
    } else if (prefix === '70') {
      city = 'Kolkata';
      state = 'West Bengal';
      days = 4;
    } else if (prefix === '38' || prefix === '39') {
      city = 'Ahmedabad';
      state = 'Gujarat';
      days = 3;
    } else if (prefix === '30' || prefix === '31') {
      city = 'Jaipur';
      state = 'Rajasthan';
      days = 3;
    } else {
      city = 'Pan-India Delivery Hub';
      state = 'India';
      days = 4;
    }

    const today = new Date();
    const est = new Date(today);
    est.setDate(today.getDate() + days);

    const estFormatted = est.toLocaleDateString('en-GB', {
      weekday: 'short',
      day: 'numeric',
      month: 'short',
    });

    setResult({
      checked: true,
      valid: true,
      city,
      state,
      deliveryDays: days,
      cod: true,
      estDate: estFormatted,
    });
  };

  return (
    <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200">
      <div className="flex items-center gap-2 mb-2 text-stone-800 text-sm font-semibold">
        <Truck className="w-4 h-4 text-[#154D34]" />
        <span>{t('checkPincode')}</span>
      </div>

      <form onSubmit={handleCheck} className="flex gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            maxLength={6}
            value={pincode}
            onChange={(e) => setPincode(e.target.value.replace(/\D/g, ''))}
            placeholder={t('enterPincode')}
            className="w-full pl-9 pr-3 py-2 bg-white text-stone-800 text-xs sm:text-sm rounded-xl border border-stone-300 focus:outline-none focus:border-[#154D34] focus:ring-1 focus:ring-[#154D34]"
          />
          <MapPin className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>
        <button
          type="submit"
          className="px-4 py-2 bg-[#154D34] hover:bg-[#0D3222] text-white text-xs sm:text-sm font-medium rounded-xl transition-colors shrink-0"
        >
          {t('checkBtn')}
        </button>
      </form>

      {/* Result feedback */}
      {result?.checked && (
        <div className="mt-3 text-xs pt-3 border-t border-stone-200">
          {result.valid ? (
            <div className="space-y-1.5 text-stone-700">
              <div className="flex items-center gap-1.5 text-emerald-700 font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Deliverable to {result.city}, {result.state} ({pincode})</span>
              </div>
              <div className="flex items-center gap-1.5 text-stone-600 pl-5">
                <Calendar className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                <span>
                  {t('deliveryBy')}: <strong className="text-stone-900">{result.estDate}</strong> (Within {result.deliveryDays} days)
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-700 font-medium pl-5">
                <span>✓ {t('codAvailable')}</span>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-rose-600 font-medium">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>Please enter a valid 6-digit Indian pincode.</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
