import React from 'react';
import { X, Printer, Download, Sprout, CheckCircle } from 'lucide-react';
import { Order } from '../types';
import { useApp } from '../context/AppContext';

interface InvoiceModalProps {
  order: Order;
  onClose: () => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({ order, onClose }) => {
  const { settings } = useApp();

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 bg-stone-900 text-white print:hidden">
          <div className="flex items-center gap-2">
            <Sprout className="w-5 h-5 text-emerald-400" />
            <span className="font-semibold text-sm">Tax Invoice / GST Bill — {order.id}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Print / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-stone-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Container */}
        <div id="printable-invoice" className="p-8 text-stone-800 text-xs sm:text-sm">
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-6 border-b border-stone-200">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-[#154D34] flex items-center justify-center text-white font-serif font-bold text-lg">
                  प्र
                </div>
                <div>
                  <h1 className="text-xl font-serif font-bold text-[#154D34]">
                    {settings.name}
                  </h1>
                  <p className="text-[11px] text-stone-700">Prakriti Green Technologies Pvt. Ltd.</p>
                </div>
              </div>
              <p className="mt-2 text-xs text-stone-700 max-w-xs leading-relaxed">
                {settings.address}
              </p>
              <p className="text-xs text-stone-800 font-medium mt-1">
                <strong>GSTIN:</strong> {settings.gstin} | <strong>State Code:</strong> 27 (Maharashtra)
              </p>
              <p className="text-xs text-stone-700">
                Email: {settings.email} | Phone: {settings.phone}
              </p>
            </div>

            <div className="text-left sm:text-right">
              <span className="inline-block px-3 py-1 rounded bg-emerald-100 text-emerald-900 font-bold text-xs uppercase tracking-wider mb-2">
                Tax Invoice (Original for Recipient)
              </span>
              <p className="text-xs text-stone-700">
                Invoice No: <strong className="text-stone-900">{order.id}</strong>
              </p>
              <p className="text-xs text-stone-700">
                Invoice Date: <strong className="text-stone-900">{order.date}</strong>
              </p>
              <p className="text-xs text-stone-700">
                Payment Mode: <strong className="text-stone-900">{order.paymentMethod}</strong> ({order.paymentStatus})
              </p>
              {order.trackingNumber && (
                <p className="text-xs text-stone-700">
                  AWB Tracking: <strong className="text-stone-900">{order.trackingNumber}</strong>
                </p>
              )}
            </div>
          </div>

          {/* Bill To & Ship To */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 py-6 border-b border-stone-200">
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-stone-700 mb-2">
                Billed To & Shipped To:
              </h2>
              <p className="font-bold text-stone-900 text-sm">{order.shippingAddress.name}</p>
              <p className="text-stone-700 mt-0.5">{order.shippingAddress.addressLine}</p>
              {order.shippingAddress.landmark && (
                <p className="text-stone-700">Landmark: {order.shippingAddress.landmark}</p>
              )}
              <p className="text-stone-700">
                {order.shippingAddress.city}, {order.shippingAddress.state} - <strong>{order.shippingAddress.pincode}</strong>
              </p>
              <p className="text-stone-700 mt-1">Mobile: +91 {order.shippingAddress.mobile}</p>
              <p className="text-stone-700">Email: {order.customerEmail}</p>
            </div>

            <div className="bg-stone-50 p-4 rounded-xl border border-stone-200">
              <h2 className="text-xs font-bold uppercase tracking-wider text-stone-700 mb-1.5">
                Delivery Details:
              </h2>
              <div className="space-y-1 text-xs">
                <p>Status: <strong className="text-emerald-700">{order.orderStatus}</strong></p>
                <p>Courier: <strong>{order.courierPartner || 'Nursery Express Logistics'}</strong></p>
                <p>Est. Delivery: <strong>{order.estimatedDeliveryDate}</strong></p>
                <p>Nature of Goods: <strong>Live Horticultural Plants & Organic Inputs</strong></p>
              </div>
            </div>
          </div>

          {/* Items Table */}
          <div className="py-6 overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b-2 border-stone-300 text-xs font-bold text-stone-600 uppercase">
                  <th className="py-2.5 px-2">#</th>
                  <th className="py-2.5 px-2">Product Description</th>
                  <th className="py-2.5 px-2">HSN/SAC</th>
                  <th className="py-2.5 px-2 text-center">Qty</th>
                  <th className="py-2.5 px-2 text-right">Unit Price</th>
                  <th className="py-2.5 px-2 text-right">Taxable Val</th>
                  <th className="py-2.5 px-2 text-right">Total (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {order.items.map((item, idx) => {
                  const itemTotal = item.price * item.quantity;
                  const taxable = Math.round(itemTotal / 1.18);
                  return (
                    <tr key={idx} className="text-xs">
                      <td className="py-3 px-2 text-stone-400">{idx + 1}</td>
                      <td className="py-3 px-2">
                        <span className="font-semibold text-stone-800">{item.name}</span>
                        <span className="block text-[11px] text-stone-400">Potted Plant with Nursery Pot</span>
                      </td>
                      <td className="py-3 px-2 text-stone-500">06029090</td>
                      <td className="py-3 px-2 text-center font-medium">{item.quantity}</td>
                      <td className="py-3 px-2 text-right">₹{item.price}</td>
                      <td className="py-3 px-2 text-right text-stone-500">₹{taxable}</td>
                      <td className="py-3 px-2 text-right font-bold text-stone-900">₹{itemTotal}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Calculation Breakdown */}
          <div className="flex flex-col sm:flex-row justify-between items-start pt-4 border-t border-stone-200 gap-6">
            <div className="max-w-xs text-xs text-stone-500 space-y-1">
              <p className="font-semibold text-stone-700">Tax Summary Note:</p>
              <p>Live plants are classified under GST HSN 0602 (Exempt/0% or applicable 5% concession). Gardening pots and fertilizers attract 18% GST.</p>
              <p>Tax invoice generated electronically. Does not require physical signature.</p>
            </div>

            <div className="w-full sm:w-72 space-y-2 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Subtotal</span>
                <span>₹{order.subtotal}</span>
              </div>
              {order.couponDiscount > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Coupon Discount ({order.couponCode})</span>
                  <span>-₹{order.couponDiscount}</span>
                </div>
              )}
              <div className="flex justify-between text-stone-600">
                <span>Shipping Charges</span>
                <span>{order.shippingCharges === 0 ? 'FREE' : `₹${order.shippingCharges}`}</span>
              </div>
              <div className="flex justify-between text-stone-500 text-[11px]">
                <span>CGST (9%) + SGST (9%) Included</span>
                <span>₹{order.gstAmount}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-stone-900 pt-2 border-t border-stone-300">
                <span>Total Amount (INR)</span>
                <span className="text-base text-[#154D34]">₹{order.totalAmount}</span>
              </div>
            </div>
          </div>

          {/* Footer badge */}
          <div className="mt-8 pt-4 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-400">
            <span>Thank you for shopping with Prakriti Nursery. Happy Gardening! 🌱</span>
            <span>www.prakritinursery.in</span>
          </div>
        </div>
      </div>
    </div>
  );
};
