import { Product } from '../types';
import { FLOWER_PLANTS_BATCH_1 } from './flowerPlantsBatch1';
import { FLOWER_PLANTS_BATCH_2 } from './flowerPlantsBatch2';

export const FLOWER_PLANTS_ALL: Product[] = [
  ...FLOWER_PLANTS_BATCH_1,
  ...FLOWER_PLANTS_BATCH_2,
];
