import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { WhatsAppFloating } from './components/WhatsAppFloating';
import { Footer } from './components/Footer';
import { AuthModal } from './views/AuthModal';

import { HomeView } from './views/HomeView';
import { CatalogView } from './views/CatalogView';
import { ProductDetailView } from './views/ProductDetailView';
import { CartView } from './views/CartView';
import { CheckoutView } from './views/CheckoutView';
import { OrderConfirmationView } from './views/OrderConfirmationView';
import { AccountView } from './views/AccountView';
import { AdminDashboardView } from './views/AdminDashboardView';
import { CareGuideView } from './views/CareGuideView';
import { OffersView } from './views/OffersView';
import { AboutView } from './views/AboutView';
import { ContactView } from './views/ContactView';
import { WishlistView } from './views/WishlistView';
import { AuthView } from './views/AuthView';

const MainContent: React.FC = () => {
  const { currentView } = useApp();

  // Scroll to top when view changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentView]);

  return (
    <main className="min-h-screen">
      {currentView === 'home' && <HomeView />}
      {currentView === 'catalog' && <CatalogView />}
      {currentView === 'product-detail' && <ProductDetailView />}
      {currentView === 'wishlist' && <WishlistView />}
      {currentView === 'cart' && <CartView />}
      {currentView === 'checkout' && <CheckoutView />}
      {currentView === 'order-confirmation' && <OrderConfirmationView />}
      {(currentView === 'login' || currentView === 'signin') && <AuthView initialMode="login" />}
      {(currentView === 'register' || currentView === 'signup') && <AuthView initialMode="register" />}
      {currentView === 'account' && <AccountView />}
      {currentView === 'admin' && <AdminDashboardView />}
      {currentView === 'care-guide' && <CareGuideView />}
      {currentView === 'offers' && <OffersView />}
      {currentView === 'about' && <AboutView />}
      {currentView === 'contact' && <ContactView />}
    </main>
  );
};

export default function App() {
  return (
    <AppProvider>
      <div className="min-h-screen bg-[#FAF8F5] text-stone-900 flex flex-col font-sans selection:bg-emerald-200 selection:text-emerald-950">
        <Header />
        <div className="flex-1 pb-16 lg:pb-0">
          <MainContent />
        </div>
        <Footer />
        <BottomNav />
        <WhatsAppFloating />
        <AuthModal />
      </div>
    </AppProvider>
  );
}
