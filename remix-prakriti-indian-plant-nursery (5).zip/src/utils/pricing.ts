import { CartItem, Coupon, NurserySettings, Product } from '../types';

/**
 * Safely parses any value into a finite number.
 * Returns fallback (default 0) if value is undefined, null, empty string, or NaN.
 */
export const parseSafeNumber = (value: any, fallback = 0): number => {
  if (value === null || value === undefined || value === '') {
    return fallback;
  }
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : fallback;
  }
  if (typeof value === 'string') {
    // Strip common currency symbols, commas, and whitespace
    const cleaned = value.replace(/[^\d.-]/g, '');
    if (!cleaned) return fallback;
    const parsed = parseFloat(cleaned);
    return Number.isFinite(parsed) ? parsed : fallback;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

/**
 * Ensures product price is a valid, non-negative finite number.
 * Logs a console warning if an invalid price is detected.
 */
export const parseSafePrice = (price: any, itemName?: string): number => {
  if (price === null || price === undefined || price === '') {
    console.warn(`[Prakriti Pricing] Missing price for product "${itemName || 'Unknown'}". Defaulting to 0.`);
    return 0;
  }

  let num: number;
  if (typeof price === 'number') {
    num = price;
  } else if (typeof price === 'string') {
    const cleaned = price.replace(/[^\d.-]/g, '');
    num = parseFloat(cleaned);
  } else {
    num = Number(price);
  }

  if (!Number.isFinite(num) || isNaN(num) || num < 0) {
    console.warn(`[Prakriti Pricing] Invalid price detected for "${itemName || 'Unknown'}":`, price, '-> Defaulting to 0.');
    return 0;
  }

  return Math.round(num * 100) / 100;
};

/**
 * Ensures quantity is a valid integer >= 1, defaulting to 1 if missing or invalid.
 * Logs a console warning if an invalid quantity is detected.
 */
export const parseSafeQuantity = (quantity: any, itemName?: string): number => {
  if (quantity === null || quantity === undefined || quantity === '') {
    console.warn(`[Prakriti Pricing] Missing quantity for "${itemName || 'Unknown'}". Defaulting to 1.`);
    return 1;
  }

  let num: number;
  if (typeof quantity === 'number') {
    num = quantity;
  } else if (typeof quantity === 'string') {
    const cleaned = quantity.replace(/[^\d.-]/g, '');
    num = parseInt(cleaned, 10);
  } else {
    num = Number(quantity);
  }

  if (!Number.isFinite(num) || isNaN(num) || num <= 0) {
    console.warn(`[Prakriti Pricing] Invalid quantity detected for "${itemName || 'Unknown'}":`, quantity, '-> Defaulting to 1.');
    return 1;
  }

  return Math.max(1, Math.floor(num));
};

export interface CartCalculationResult {
  subtotal: number;
  couponDiscount: number;
  shipping: number;
  gst: number;
  total: number;
  isFreeDelivery: boolean;
  freeDeliveryThreshold: number;
  diffForFreeDelivery: number;
  isCalculationReady: boolean;
  itemCount: number;
}

/**
 * Core cart and checkout financial calculation.
 * Guarantee: Every returned number is guaranteed to be a valid, finite, non-negative number.
 * Never returns NaN, undefined, or null.
 */
export const calculateCartTotals = (
  cart: CartItem[] = [],
  options?: {
    coupon?: Coupon | null;
    deliverySpeed?: 'standard' | 'express';
    settings?: Partial<NurserySettings>;
    customGstRate?: number;
  }
): CartCalculationResult => {
  const safeCart = Array.isArray(cart) ? cart : [];

  // 1. Calculate subtotal = sum(product.price * product.quantity)
  let subtotal = 0;
  let itemCount = 0;

  for (const item of safeCart) {
    if (!item) continue;
    const prod = item.product || ({} as Product);
    const rawPrice = prod.price ?? (prod as any).priceInINR;
    const price = parseSafePrice(rawPrice, prod.name || prod.id);
    const quantity = parseSafeQuantity(item.quantity, prod.name || prod.id);

    const lineTotal = price * quantity;
    if (Number.isFinite(lineTotal)) {
      subtotal += lineTotal;
      itemCount += quantity;
    } else {
      console.warn(`[Prakriti Pricing] Non-finite line total for product "${prod.name}": price=${price}, qty=${quantity}`);
    }
  }

  subtotal = Number.isFinite(subtotal) ? Math.max(0, Math.round(subtotal)) : 0;

  // Settings thresholds
  const freeThreshold = parseSafeNumber(
    options?.settings?.freeShippingThreshold ?? (options?.settings as any)?.freeDeliveryThreshold,
    999
  );
  const standardShippingFee = parseSafeNumber(
    options?.settings?.standardShippingFee ?? (options?.settings as any)?.standardDeliveryCharge,
    99
  );

  const isFreeDelivery = subtotal >= freeThreshold;
  const diffForFreeDelivery = isFreeDelivery ? 0 : Math.max(0, freeThreshold - subtotal);

  // 2. Calculate shipping charge (or 0)
  let shipping = 0;
  if (subtotal > 0) {
    const baseShipping = isFreeDelivery ? 0 : standardShippingFee;
    const expressSurcharge = options?.deliverySpeed === 'express' ? 99 : 0;
    shipping = baseShipping + expressSurcharge;
  }
  shipping = Number.isFinite(shipping) ? Math.max(0, Math.round(shipping)) : 0;

  // 3. Coupon Discount calculation
  let couponDiscount = 0;
  const coupon = options?.coupon;
  if (coupon && subtotal > 0) {
    const discountVal = parseSafeNumber(coupon.discountValue, 0);
    const minOrderVal = parseSafeNumber(coupon.minOrderValue, 0);

    if (subtotal >= minOrderVal) {
      if (coupon.discountType === 'percentage') {
        const calculated = Math.round((subtotal * discountVal) / 100);
        const maxDiscount = coupon.maxDiscount ? parseSafeNumber(coupon.maxDiscount, calculated) : calculated;
        couponDiscount = Math.min(calculated, maxDiscount);
      } else {
        couponDiscount = Math.min(subtotal, discountVal);
      }
    }
  }
  couponDiscount = Number.isFinite(couponDiscount) ? Math.max(0, Math.min(subtotal, Math.round(couponDiscount))) : 0;

  const discountedSubtotal = Math.max(0, subtotal - couponDiscount);

  // 4. Calculate GST = valid GST amount (or 0)
  // In India, live plants have 0% GST (HSN 0602 exemption), or store setting rate (e.g. 5%)
  const gstRate = parseSafeNumber(options?.customGstRate ?? (options?.settings as any)?.gstRate, 0);
  let gst = 0;
  if (gstRate > 0 && discountedSubtotal > 0) {
    gst = Math.round((discountedSubtotal * gstRate) / 100);
  }
  gst = Number.isFinite(gst) ? Math.max(0, Math.round(gst)) : 0;

  // 5. Total = (subtotal - couponDiscount) + shipping + GST
  // In standard no-coupon case: total = subtotal + shipping + GST
  let total = discountedSubtotal + shipping + gst;
  total = Number.isFinite(total) ? Math.max(0, Math.round(total)) : 0;

  // Validation flag
  const isCalculationReady =
    Number.isFinite(subtotal) &&
    Number.isFinite(shipping) &&
    Number.isFinite(gst) &&
    Number.isFinite(total) &&
    !isNaN(total);

  return {
    subtotal,
    couponDiscount,
    shipping,
    gst,
    total,
    isFreeDelivery,
    freeDeliveryThreshold: freeThreshold,
    diffForFreeDelivery,
    isCalculationReady,
    itemCount,
  };
};

/**
 * Safe currency formatter in Indian Rupees (₹).
 */
export const formatINR = (amount: any): string => {
  const safe = parseSafeNumber(amount, 0);
  return `₹${safe.toLocaleString('en-IN')}`;
};
