import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updateProfile as updateAuthProfile,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  initializeFirestore,
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  setDoc,
  collection,
  getDocs,
  query,
  where,
  orderBy,
  updateDoc,
  deleteDoc,
  serverTimestamp,
} from 'firebase/firestore';
import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL,
} from 'firebase/storage';
import { initializeAppCheck, ReCaptchaV3Provider } from 'firebase/app-check';

// Import project credentials provisioned by AI Studio
import firebaseConfigRaw from '../../firebase-applet-config.json';

export const firebaseConfig = {
  apiKey: firebaseConfigRaw.apiKey,
  authDomain: firebaseConfigRaw.authDomain,
  projectId: firebaseConfigRaw.projectId,
  storageBucket: firebaseConfigRaw.storageBucket,
  messagingSenderId: firebaseConfigRaw.messagingSenderId,
  appId: firebaseConfigRaw.appId,
  firestoreDatabaseId: firebaseConfigRaw.firestoreDatabaseId || undefined,
};

// Initialize Firebase App singleton
export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Initialize Firebase Auth
export const auth = getAuth(app);

// Initialize Cloud Firestore (support dedicated database ID if configured)
// Use experimentalForceLongPolling: true to prevent WebChannel streaming timeouts in browser sandboxes/proxies
let firestoreInstance;
try {
  const dbId =
    firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== '(default)'
      ? firebaseConfig.firestoreDatabaseId
      : undefined;

  firestoreInstance = initializeFirestore(
    app,
    {
      experimentalForceLongPolling: true,
    },
    dbId
  );
} catch {
  // If already initialized or fails, fallback to existing instance
  try {
    if (firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== '(default)') {
      firestoreInstance = getFirestore(app, firebaseConfig.firestoreDatabaseId);
    } else {
      firestoreInstance = getFirestore(app);
    }
  } catch {
    firestoreInstance = getFirestore(app);
  }
}
export const db = firestoreInstance;

// Error contextualization conforming to Firebase security testing standards
export enum OperationType {
  CREATE = 'create',
  READ = 'read',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
}

export interface FirestoreSecurityErrorContext {
  operation: OperationType;
  path: string;
}

export function handleFirestoreError(error: unknown, context: FirestoreSecurityErrorContext): never {
  const err = error as { code?: string; message?: string };
  if (err?.code === 'permission-denied' || (typeof err?.message === 'string' && err.message.includes('Missing or insufficient permissions'))) {
    throw new Error(JSON.stringify({
      error: "PERMISSION_DENIED",
      message: `Firestore permission denied during ${context.operation} on ${context.path}`,
      operation: context.operation,
      path: context.path
    }));
  }
  throw error;
}

// Validate Connection to Firestore on application boot
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'settings', 'store_config'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Please check your Firebase configuration or internet connection.");
    }
  }
}
if (typeof window !== 'undefined') {
  testConnection();
}

// Initialize Firebase Storage
export const storage = getStorage(app);

// Initialize App Check conditionally if recaptcha site key is provided
if (typeof window !== 'undefined' && firebaseConfigRaw.recaptchaSiteKey) {
  try {
    initializeAppCheck(app, {
      provider: new ReCaptchaV3Provider(firebaseConfigRaw.recaptchaSiteKey),
      isTokenAutoRefreshEnabled: true,
    });
  } catch (err) {
    console.warn('Firebase App Check initialization deferred:', err);
  }
}

// Storage helper: Upload product image to Firebase Storage
export async function uploadPlantImage(file: File): Promise<string> {
  try {
    const filename = `products/${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '_')}`;
    const storageRef = ref(storage, filename);
    const snapshot = await uploadBytes(storageRef, file, {
      contentType: file.type || 'image/jpeg',
    });
    const downloadUrl = await getDownloadURL(snapshot.ref);
    return downloadUrl;
  } catch (err) {
    console.warn('Firebase Storage upload failed, falling back to FileReader Data URL:', err);
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (e) => reject(e);
      reader.readAsDataURL(file);
    });
  }
}
