import { Product } from '../types';

export interface PlantFilterOptions {
  category?: string;
  priceRange?: [number, number];
  environment?: 'all' | 'Indoor' | 'Outdoor' | 'Both';
  sunlight?: string;
  water?: string;
  maintenance?: string;
  flowering?: 'all' | 'Flowering' | 'Non-flowering';
  color?: string;
  season?: string;
  inStockOnly?: boolean;
  suitableFor?: string;
}

export interface SearchIntent {
  key: string;
  label: string;
  labelHi: string;
  labelMr: string;
  description: string;
  categoryMatch?: string;
  plantTypeMatch?: string;
  environmentMatch?: 'Indoor' | 'Outdoor' | 'Both';
  floweringMatch?: 'Flowering' | 'Non-flowering';
  specialFilter?: (p: Product) => boolean;
}

// Canonical search intent rules for Indian nursery queries
export const SEARCH_INTENTS: Record<string, SearchIntent> = {
  flower: {
    key: 'flower',
    label: 'Flowering Plants',
    labelHi: 'फूलों वाले पौधे',
    labelMr: 'फुलांची रोपे',
    description: 'Fragrant and colorful Indian blooms like Desi Gulab, Mogra, Gudhal, and Bougainvillea.',
    categoryMatch: 'Flower Plants',
    floweringMatch: 'Flowering',
    specialFilter: (p) => p.floweringType === 'Flowering' || p.category.toLowerCase().includes('flower') || p.plantType === 'flowering',
  },
  decorative: {
    key: 'decorative',
    label: 'Decorative & Ornamental Plants',
    labelHi: 'सजावटी व शोभिवंत पौधे',
    labelMr: 'शोभिवंत इनडोअर रोपे',
    description: 'Stunning foliage plants like Golden Money Plant, Areca Palm, Snake Plant, and Croton.',
    categoryMatch: 'Decorative Plants',
    specialFilter: (p) =>
      p.category.toLowerCase().includes('decor') ||
      p.plantType === 'decorative' ||
      p.suitableFor?.includes('Decoration') ||
      ['Money Plant', 'Areca Palm', 'Snake Plant', 'Peace Lily', 'Croton', 'ZZ Plant', 'Aglaonema', 'Song of India', 'Rubber Plant'].some((name) =>
        p.name.toLowerCase().includes(name.toLowerCase())
      ),
  },
  indoor: {
    key: 'indoor',
    label: 'Indoor Houseplants',
    labelHi: 'इंडोर पौधे (घर के अंदर)',
    labelMr: 'घरातील इनडोअर रोपे',
    description: 'Thriving in medium/bright indirect light inside Indian homes, living rooms and bedrooms.',
    categoryMatch: 'Indoor Plants',
    environmentMatch: 'Indoor',
    specialFilter: (p) => p.environment === 'Indoor' || p.environment === 'Both' || p.category.toLowerCase().includes('indoor'),
  },
  outdoor: {
    key: 'outdoor',
    label: 'Outdoor & Garden Plants',
    labelHi: 'आउटडोर व बगीचे के पौधे',
    labelMr: 'बागेतील व गच्चीवरील रोपे',
    description: 'Sun-loving resilient plants for Indian gardens, open terraces, lawns, and courtyards.',
    categoryMatch: 'Outdoor Plants',
    environmentMatch: 'Outdoor',
    specialFilter: (p) => p.environment === 'Outdoor' || p.environment === 'Both' || p.category.toLowerCase().includes('outdoor'),
  },
  medicinal: {
    key: 'medicinal',
    label: 'Medicinal & Ayurvedic Plants',
    labelHi: 'औषधीय व आयुर्वेदिक पौधे',
    labelMr: 'औषधी व आयुर्वेदिक वनस्पती',
    description: 'Traditional healing herbs like Tulsi, Aloe Vera, Mint, Lemongrass, Neem, and Giloy.',
    categoryMatch: 'Medicinal Plants',
    plantTypeMatch: 'medicinal',
    specialFilter: (p) =>
      p.category.toLowerCase().includes('medicin') ||
      p.plantType === 'medicinal' ||
      p.tags?.includes('medicinal') ||
      ['Tulsi', 'Aloe Vera', 'Mint', 'Pudina', 'Lemongrass', 'Neem', 'Giloy', 'Ashwagandha', 'Brahmi'].some((name) =>
        p.name.toLowerCase().includes(name.toLowerCase())
      ),
  },
  fruit: {
    key: 'fruit',
    label: 'Fruit Plants for Pots & Gardens',
    labelHi: 'फलों के पौधे (गमले व बागीचा)',
    labelMr: 'फळझाडे',
    description: 'High-yielding fruit varieties like Kagzi Nimbu, Pomegranate, Guava, Mango, and Chikoo.',
    categoryMatch: 'Fruit Plants',
    plantTypeMatch: 'fruit',
    specialFilter: (p) => p.category.toLowerCase().includes('fruit') || p.plantType === 'fruit',
  },
  herbal: {
    key: 'herbal',
    label: 'Kitchen Herbs & Culinary Plants',
    labelHi: 'किचन हर्ब्स व मसालेदार पौधे',
    labelMr: 'हर्बल व स्वयंपाकघरातील रोपे',
    description: 'Fresh Indian culinary essentials like Pudina, Kadi Patta, Lemongrass, Ajwain, and Tulsi.',
    categoryMatch: 'Herbal Plants',
    plantTypeMatch: 'herbal',
    specialFilter: (p) =>
      p.category.toLowerCase().includes('herb') ||
      p.plantType === 'herbal' ||
      ['Mint', 'Pudina', 'Lemongrass', 'Ajwain', 'Curry Leaf', 'Kadi Patta', 'Tulsi', 'Coriander'].some((name) =>
        p.name.toLowerCase().includes(name.toLowerCase())
      ),
  },
  cactus: {
    key: 'cactus',
    label: 'Cactus & Resilient Succulents',
    labelHi: 'कैक्टस और सक्युलेंट्स',
    labelMr: 'कॅक्टस आणि सक्युलंट्स',
    description: 'Fleshy water-storing plants like Jade, Golden Barrel Cactus, Haworthia, and Sansevieria.',
    categoryMatch: 'Cactus & Succulents',
    plantTypeMatch: 'succulent',
    specialFilter: (p) =>
      p.category.toLowerCase().includes('succulent') ||
      p.category.toLowerCase().includes('cactus') ||
      p.plantType === 'succulent' ||
      ['Cactus', 'Jade', 'Succulent', 'Haworthia', 'Echeveria', 'Sansevieria'].some((name) =>
        p.name.toLowerCase().includes(name.toLowerCase())
      ),
  },
  airpurifying: {
    key: 'airpurifying',
    label: 'Air Purifying Plants',
    labelHi: 'वायु शुद्धिकरण पौधे (नासा प्रमाणित)',
    labelMr: 'हवा शुद्ध करणारी रोपे',
    description: 'NASA-approved oxygen boosters like Snake Plant, Money Plant, Areca Palm, and Peace Lily.',
    categoryMatch: 'Air Purifying Plants',
    specialFilter: (p) =>
      p.category.toLowerCase().includes('air') ||
      p.tags?.includes('air-purifying') ||
      ['Snake Plant', 'Money Plant', 'Areca Palm', 'Spider Plant', 'ZZ Plant', 'Peace Lily', 'Rubber Plant'].some((name) =>
        p.name.toLowerCase().includes(name.toLowerCase())
      ),
  },
  lowmaintenance: {
    key: 'lowmaintenance',
    label: 'Low Maintenance & Hardy Plants',
    labelHi: 'कम देखभाल वाले मजबूत पौधे',
    labelMr: 'कमी निगा लागणारी रोपे',
    description: 'Drought-tolerant, forgiving plants ideal for busy plant parents and beginners.',
    categoryMatch: 'Low Maintenance Plants',
    specialFilter: (p) =>
      p.maintenanceLevel === 'Low' ||
      p.category.toLowerCase().includes('low maintenance') ||
      p.specs?.difficulty === 'Easy' ||
      ['Snake Plant', 'ZZ Plant', 'Money Plant', 'Jade Plant', 'Aloe Vera', 'Syngonium'].some((name) =>
        p.name.toLowerCase().includes(name.toLowerCase())
      ),
  },
  balcony: {
    key: 'balcony',
    label: 'Balcony Gardening Plants',
    labelHi: 'बालकनी गार्डनिंग पौधे',
    labelMr: 'गॅलरी / बाल्कनीतील रोपे',
    description: 'Compact, fragrant, and flowering plants tailored for Indian apartment balconies.',
    categoryMatch: 'Balcony Plants',
    specialFilter: (p) =>
      p.suitableFor?.includes('Balcony') ||
      p.category.toLowerCase().includes('balcony') ||
      p.specs?.location?.toLowerCase().includes('balcony') ||
      ['Mogra', 'Gulab', 'Rose', 'Tulsi', 'Money Plant', 'Bougainvillea', 'Pudina', 'Kadi Patta', 'Marigold'].some((name) =>
        p.name.toLowerCase().includes(name.toLowerCase())
      ),
  },
  garden: {
    key: 'garden',
    label: 'Garden & Landscaping Plants',
    labelHi: 'बगीचे व लैंडस्केपिंग पौधे',
    labelMr: 'बागकाम व लँडस्केपिंग रोपे',
    description: 'Spreading shrubs, ornamental trees, and lawn accents for Indian homes and bungalows.',
    categoryMatch: 'Garden Plants',
    specialFilter: (p) =>
      p.suitableFor?.includes('Garden') ||
      p.suitableFor?.includes('Landscaping') ||
      p.category.toLowerCase().includes('garden') ||
      ['Bougainvillea', 'Champa', 'Hibiscus', 'Parijat', 'Mango', 'Lemon', 'Neem', 'Shami', 'Areca Palm'].some((name) =>
        p.name.toLowerCase().includes(name.toLowerCase())
      ),
  },
  pooja: {
    key: 'pooja',
    label: 'Pooja & Sacred Plants',
    labelHi: 'पूजा व पवित्र पौधे',
    labelMr: 'पूजेची व पवित्र वनस्पती',
    description: 'Sacred plants revered in Indian worship like Krishna Tulsi, Parijat, Marigold, Hibiscus, and Shami.',
    specialFilter: (p) =>
      p.suitableFor?.includes('Pooja') ||
      p.tags?.includes('pooja') ||
      ['Tulsi', 'Parijat', 'Harsingar', 'Marigold', 'Genda', 'Hibiscus', 'Gudhal', 'Jaswand', 'Shami', 'Bilva', 'Bael', 'Champa'].some((name) =>
        p.name.toLowerCase().includes(name.toLowerCase()) || p.commonIndianName?.toLowerCase().includes(name.toLowerCase())
      ),
  },
  rose: {
    key: 'rose',
    label: 'Rose Varieties (गुलाब)',
    labelHi: 'गुलाब के पौधे',
    labelMr: 'गुलाबाची रोपे',
    description: 'Fragrant Desi Gulab, Kashmiri Rose, and Button Rose varieties.',
    specialFilter: (p) =>
      p.name.toLowerCase().includes('rose') ||
      p.name.toLowerCase().includes('gulab') ||
      p.commonIndianName?.toLowerCase().includes('गुलाब') ||
      p.commonIndianName?.toLowerCase().includes('gulab'),
  },
  vegetable: {
    key: 'vegetable',
    label: 'Vegetable Plants (सब्जियों के पौधे)',
    labelHi: 'सब्जियों के पौधे',
    labelMr: 'भाजीपाल्याची रोपे',
    description: 'Fresh organic Indian vegetables like Tamatar, Hari Mirch, Baingan, and leafy greens.',
    categoryMatch: 'Vegetable Plants',
    specialFilter: (p) =>
      p.category.toLowerCase().includes('veg') ||
      p.tags?.includes('vegetables') ||
      ['Tomato', 'Tamatar', 'Chilli', 'Mirch', 'Brinjal', 'Baingan', 'Okra', 'Bhindi'].some((name) =>
        p.name.toLowerCase().includes(name.toLowerCase())
      ),
  },
  palms: {
    key: 'palms',
    label: 'Palms & Tropical Foliage',
    labelHi: 'पाम के पौधे',
    labelMr: 'पाम झाडे',
    description: 'Majestic tropical palms like Areca Palm, Coconut Palm, and Bamboo Palm.',
    categoryMatch: 'Palms',
    specialFilter: (p) =>
      p.category.toLowerCase().includes('palm') ||
      p.tags?.includes('palms') ||
      p.name.toLowerCase().includes('palm'),
  },
  bonsai: {
    key: 'bonsai',
    label: 'Bonsai Plants (लघु वृक्ष)',
    labelHi: 'बोनसाई पौधे',
    labelMr: 'बोनसाय रोपे',
    description: 'Artfully sculpted miniature bonsai trees including Ficus, Jade, and Bougainvillea bonsai.',
    categoryMatch: 'Bonsai Plants',
    plantTypeMatch: 'bonsai',
    specialFilter: (p) =>
      p.category.toLowerCase().includes('bonsai') ||
      p.tags?.includes('bonsai') ||
      p.plantType === 'bonsai' ||
      p.name.toLowerCase().includes('bonsai'),
  },
  climbers: {
    key: 'climbers',
    label: 'Climbers & Creepers (बेल व लताएं)',
    labelHi: 'बेल व लताएं',
    labelMr: 'वेली आणि लता',
    description: 'Rapidly spreading vines like Madhumalti, Aparajita, Krishna Kamal, Bougainvillea, and Morning Glory.',
    categoryMatch: 'Climbers & Creepers',
    specialFilter: (p) =>
      p.category.toLowerCase().includes('climber') ||
      p.category.toLowerCase().includes('creeper') ||
      p.tags?.includes('climber') ||
      ['Aparajita', 'Madhumalti', 'Giloy', 'Morning Glory', 'Krishna Kamal', 'Bougainvillea', 'Money Plant'].some((name) =>
        p.name.toLowerCase().includes(name.toLowerCase())
      ),
  },
  trees: {
    key: 'trees',
    label: 'Trees & Heritage Vriksha (पेड़ व वृक्ष)',
    labelHi: 'पेड़ व वृक्ष',
    labelMr: 'झाडे व वृक्ष',
    description: 'Majestic shade, sacred, and timber trees like Neem, Banyan, Peepal, Gulmohar, and Amaltas.',
    categoryMatch: 'Trees',
    specialFilter: (p) =>
      p.category.toLowerCase().includes('tree') ||
      p.tags?.includes('trees') ||
      ['Neem', 'Banyan', 'Peepal', 'Gulmohar', 'Amaltas', 'Ashoka', 'Jamun', 'Mango'].some((name) =>
        p.name.toLowerCase().includes(name.toLowerCase())
      ),
  },
};

// Map search tokens to recognized intents
export function detectSearchIntent(query: string): SearchIntent | null {
  const q = query.trim().toLowerCase();

  // 1. Flower plants
  if (
    q === 'flower plant' ||
    q === 'flower plants' ||
    q === 'flowering' ||
    q === 'flowering plant' ||
    q === 'flowering plants' ||
    q === 'flower' ||
    q === 'flowers' ||
    q === 'phool' ||
    q === 'ful' ||
    q === 'फूल' ||
    q === 'फुले'
  ) {
    return SEARCH_INTENTS.flower;
  }

  // 2. Decoration plants
  if (
    q === 'decoration plant' ||
    q === 'decoration plants' ||
    q === 'decorative plant' ||
    q === 'decorative plants' ||
    q === 'decoration' ||
    q === 'decorative' ||
    q === 'decor' ||
    q === 'sajawat' ||
    q === 'show plant' ||
    q === 'show plants' ||
    q === 'ornamental'
  ) {
    return SEARCH_INTENTS.decorative;
  }

  // 3. Indoor plants
  if (
    q === 'indoor plant' ||
    q === 'indoor plants' ||
    q === 'indoor' ||
    q === 'indoors' ||
    q === 'room plant' ||
    q === 'room plants' ||
    q === 'bedroom plant' ||
    q === 'living room plant' ||
    q === 'घर के अंदर'
  ) {
    return SEARCH_INTENTS.indoor;
  }

  // 4. Outdoor plants
  if (
    q === 'outdoor plant' ||
    q === 'outdoor plants' ||
    q === 'outdoor' ||
    q === 'outdoors' ||
    q === 'sun plant' ||
    q === 'dhoop' ||
    q === 'बाहर'
  ) {
    return SEARCH_INTENTS.outdoor;
  }

  // 5. Medicinal plants
  if (
    q === 'medicinal plant' ||
    q === 'medicinal plants' ||
    q === 'medicinal' ||
    q === 'medicine' ||
    q === 'ayurvedic' ||
    q === 'ayurveda' ||
    q === 'aushadhi' ||
    q === 'dawa' ||
    q === 'immunity' ||
    q === 'औषधीय'
  ) {
    return SEARCH_INTENTS.medicinal;
  }

  // 6. Fruit plants
  if (
    q === 'fruit plant' ||
    q === 'fruit plants' ||
    q === 'fruit' ||
    q === 'fruits' ||
    q === 'phal' ||
    q === 'फल' ||
    q === 'फळे'
  ) {
    return SEARCH_INTENTS.fruit;
  }

  // 7. Herbal plants
  if (
    q === 'herbal plant' ||
    q === 'herbal plants' ||
    q === 'herbal' ||
    q === 'herb' ||
    q === 'herbs' ||
    q === 'kitchen herb' ||
    q === 'kitchen plants'
  ) {
    return SEARCH_INTENTS.herbal;
  }

  // 8. Cactus & succulents
  if (
    q === 'cactus' ||
    q === 'cacti' ||
    q === 'succulent' ||
    q === 'succulents' ||
    q === 'cactus and succulents' ||
    q === 'कैक्टस'
  ) {
    return SEARCH_INTENTS.cactus;
  }

  // 9. Air purifying
  if (
    q === 'air purifying plant' ||
    q === 'air purifying plants' ||
    q === 'air purifying' ||
    q === 'air purifier' ||
    q === 'clean air' ||
    q === 'oxygen' ||
    q === 'oxygen plant' ||
    q === 'nasa'
  ) {
    return SEARCH_INTENTS.airpurifying;
  }

  // 10. Low maintenance
  if (
    q === 'low maintenance' ||
    q === 'low maintenance plant' ||
    q === 'low maintenance plants' ||
    q === 'easy care' ||
    q === 'easy plant' ||
    q === 'hard to kill' ||
    q === 'कम देखभाल'
  ) {
    return SEARCH_INTENTS.lowmaintenance;
  }

  // 11. Balcony plants
  if (
    q === 'balcony plant' ||
    q === 'balcony plants' ||
    q === 'balcony' ||
    q === 'balcony garden' ||
    q === 'बालकनी'
  ) {
    return SEARCH_INTENTS.balcony;
  }

  // 12. Garden plants
  if (
    q === 'garden plant' ||
    q === 'garden plants' ||
    q === 'garden' ||
    q === 'landscaping' ||
    q === 'b बगीचा'
  ) {
    return SEARCH_INTENTS.garden;
  }

  // 13. Pooja / Puja plants
  if (
    q === 'pooja' ||
    q === 'puja' ||
    q === 'pooja plant' ||
    q === 'puja plant' ||
    q === 'mandir' ||
    q === 'sacred plant' ||
    q === 'holy plant' ||
    q === 'पूजा'
  ) {
    return SEARCH_INTENTS.pooja;
  }

  // 14. Home plants
  if (
    q === 'home plant' ||
    q === 'home plants' ||
    q === 'houseplant' ||
    q === 'houseplants' ||
    q === 'plants for home' ||
    q === 'ghar'
  ) {
    return SEARCH_INTENTS.indoor;
  }

  // 15. Rose specifically
  if (q === 'rose' || q === 'roses' || q === 'gulab' || q === 'गुलाब') {
    return SEARCH_INTENTS.rose;
  }

  // 16. Vegetable plants
  if (
    q === 'vegetable' ||
    q === 'vegetables' ||
    q === 'vegetable plant' ||
    q === 'vegetable plants' ||
    q === 'sabzi' ||
    q === 'sabji' ||
    q === 'भाजी' ||
    q === 'सब्जी'
  ) {
    return SEARCH_INTENTS.vegetable;
  }

  // 17. Palms
  if (q === 'palm' || q === 'palms' || q === 'palm plant' || q === 'palm tree' || q === 'पाम') {
    return SEARCH_INTENTS.palms;
  }

  // 18. Bonsai
  if (q === 'bonsai' || q === 'bonsai plant' || q === 'bonsai tree' || q === 'बोनसाई' || q === 'बोनसाय') {
    return SEARCH_INTENTS.bonsai;
  }

  // 19. Climbers & Creepers
  if (
    q === 'climber' ||
    q === 'climbers' ||
    q === 'creeper' ||
    q === 'creepers' ||
    q === 'vine' ||
    q === 'vines' ||
    q === 'bail' ||
    q === 'bel' ||
    q === 'वेल' ||
    q === 'बेल'
  ) {
    return SEARCH_INTENTS.climbers;
  }

  // 20. Trees
  if (q === 'tree' || q === 'trees' || q === 'ped' || q === 'vriksha' || q === 'पेड़' || q === 'झाड' || q === 'वृक्ष') {
    return SEARCH_INTENTS.trees;
  }

  return null;
}

// Smart Plant Search & Filter Engine
export interface SearchResult {
  products: Product[];
  isFallback: boolean;
  matchedIntent: SearchIntent | null;
  totalMatches: number;
}

export function searchAndFilterPlants(
  allProducts: Product[],
  searchQuery: string,
  filters?: PlantFilterOptions
): SearchResult {
  const cleanQuery = searchQuery.trim();
  const lowerQuery = cleanQuery.toLowerCase();
  const detectedIntent = cleanQuery ? detectSearchIntent(cleanQuery) : null;

  // 1. Initial Candidate Selection
  let matchedList: { product: Product; score: number }[] = [];

  for (const p of allProducts) {
    let score = 0;

    // Apply explicit UI filter options first
    if (filters) {
      if (filters.category && filters.category !== 'all') {
        const catClean = filters.category.toLowerCase().replace(/[^a-z0-9]/g, '');
        const pCatClean = p.category.toLowerCase().replace(/[^a-z0-9]/g, '');
        if (catClean !== pCatClean && !p.category.toLowerCase().includes(filters.category.toLowerCase())) {
          // Check if it matches intent category
          continue;
        }
      }

      if (filters.priceRange) {
        if (p.price < filters.priceRange[0] || p.price > filters.priceRange[1]) continue;
      }

      if (filters.environment && filters.environment !== 'all') {
        if (p.environment && p.environment !== 'Both' && p.environment !== filters.environment) continue;
      }

      if (filters.flowering && filters.flowering !== 'all') {
        if (p.floweringType && p.floweringType !== filters.flowering) continue;
      }

      if (filters.sunlight && filters.sunlight !== 'all') {
        if (p.sunlightRequirement && p.sunlightRequirement !== filters.sunlight && p.specs?.light !== filters.sunlight) {
          continue;
        }
      }

      if (filters.water && filters.water !== 'all') {
        if (p.waterRequirement && p.waterRequirement !== filters.water && p.specs?.water !== filters.water) {
          continue;
        }
      }

      if (filters.maintenance && filters.maintenance !== 'all') {
        if (p.maintenanceLevel && p.maintenanceLevel !== filters.maintenance) continue;
      }

      if (filters.inStockOnly && p.stock <= 0) continue;

      if (filters.suitableFor && filters.suitableFor !== 'all') {
        if (!p.suitableFor?.includes(filters.suitableFor as any)) continue;
      }

      if (filters.color && filters.color !== 'all') {
        const pColor = (p.flowerColor || '').toLowerCase();
        if (!pColor.includes(filters.color.toLowerCase())) continue;
      }

      if (filters.season && filters.season !== 'all') {
        const pSeason = (p.floweringSeason || '').toLowerCase();
        if (!pSeason.includes(filters.season.toLowerCase()) && !pSeason.includes('all season') && !pSeason.includes('year-round')) {
          continue;
        }
      }
    }

    // Now evaluate search query relevance
    if (!cleanQuery) {
      // No query entered: default score based on popularity
      score = (p.rating || 4.5) * 10 + (p.isBestSeller ? 20 : 0);
      matchedList.push({ product: p, score });
      continue;
    }

    // Intent match
    if (detectedIntent) {
      if (detectedIntent.specialFilter && detectedIntent.specialFilter(p)) {
        score += 100;
      }
      if (detectedIntent.categoryMatch && p.category.toLowerCase().includes(detectedIntent.categoryMatch.toLowerCase())) {
        score += 80;
      }
      if (detectedIntent.environmentMatch && (p.environment === detectedIntent.environmentMatch || p.environment === 'Both')) {
        score += 40;
      }
      if (detectedIntent.floweringMatch && p.floweringType === detectedIntent.floweringMatch) {
        score += 40;
      }
    }

    // Exact and Substring Checks
    const nameMatch = p.name.toLowerCase().includes(lowerQuery);
    const indianMatch = p.commonIndianName?.toLowerCase().includes(lowerQuery) || false;
    const hiMatch = p.nameHi?.toLowerCase().includes(lowerQuery) || false;
    const mrMatch = p.nameMr?.toLowerCase().includes(lowerQuery) || false;
    const sciMatch = p.scientificName?.toLowerCase().includes(lowerQuery) || false;
    const catMatch = p.category.toLowerCase().includes(lowerQuery);
    const descMatch = p.description.toLowerCase().includes(lowerQuery);
    const tagMatch = p.searchKeywords?.some((kw) => kw.toLowerCase().includes(lowerQuery)) || false;
    const suitableMatch = p.suitableFor?.some((sf) => sf.toLowerCase().includes(lowerQuery)) || false;
    const flowerColorMatch = p.flowerColor?.toLowerCase().includes(lowerQuery) || false;
    const seasonMatch = p.floweringSeason?.toLowerCase().includes(lowerQuery) || false;

    if (p.name.toLowerCase() === lowerQuery) score += 200;
    else if (nameMatch) score += 80;

    if (indianMatch || hiMatch || mrMatch) score += 70;
    if (sciMatch) score += 60;
    if (catMatch) score += 50;
    if (tagMatch) score += 45;
    if (suitableMatch) score += 35;
    if (flowerColorMatch) score += 30;
    if (seasonMatch) score += 25;
    if (descMatch) score += 20;

    // Word token matching
    const queryTokens = lowerQuery.split(/\s+/).filter((t) => t.length > 2);
    for (const token of queryTokens) {
      if (p.name.toLowerCase().includes(token)) score += 25;
      if (p.commonIndianName?.toLowerCase().includes(token)) score += 20;
      if (p.flowerColor?.toLowerCase().includes(token)) score += 20;
      if (p.floweringSeason?.toLowerCase().includes(token)) score += 15;
      if (p.searchKeywords?.some((kw) => kw.toLowerCase().includes(token))) score += 15;
      if (p.category.toLowerCase().includes(token)) score += 15;
    }

    if (score > 0) {
      matchedList.push({ product: p, score });
    }
  }

  // If matches found, sort by relevance score
  if (matchedList.length > 0) {
    matchedList.sort((a, b) => b.score - a.score);
    return {
      products: matchedList.map((m) => m.product),
      isFallback: false,
      matchedIntent: detectedIntent,
      totalMatches: matchedList.length,
    };
  }

  // Smart Fallback when 0 exact matches: Show curated Indian favorites instead of dead empty page
  // If the query was flower-related, prioritize flower plants as fallback
  const isFlowerQuery = lowerQuery.includes('flower') || lowerQuery.includes('फूल') || lowerQuery.includes('bloom');
  const fallbackSource = isFlowerQuery
    ? allProducts.filter((p) => p.category === 'Flower Plants' || p.floweringType === 'Flowering')
    : allProducts;

  const fallbackList = [...(fallbackSource.length > 0 ? fallbackSource : allProducts)]
    .sort((a, b) => (b.rating * b.reviewCount) - (a.rating * a.reviewCount))
    .slice(0, 8);

  return {
    products: fallbackList,
    isFallback: true,
    matchedIntent: detectedIntent,
    totalMatches: 0,
  };
}

// Helper: Recommend similar flower plants based on color, season, and growing conditions
export function getSimilarFlowerPlants(currentPlant: Product, allProducts: Product[], limit = 4): Product[] {
  const isFlower = currentPlant.category === 'Flower Plants' || currentPlant.floweringType === 'Flowering' || Boolean(currentPlant.flowerColor);

  return allProducts
    .filter((p) => p.id !== currentPlant.id && (isFlower ? (p.category === 'Flower Plants' || p.floweringType === 'Flowering' || Boolean(p.flowerColor)) : true))
    .map((p) => {
      let similarityScore = 0;

      // Color similarity
      if (currentPlant.flowerColor && p.flowerColor) {
        const c1 = currentPlant.flowerColor.toLowerCase();
        const c2 = p.flowerColor.toLowerCase();
        if (c1 === c2 || c1.includes(c2) || c2.includes(c1)) {
          similarityScore += 45;
        }
      }

      // Season similarity
      if (currentPlant.floweringSeason && p.floweringSeason) {
        const s1 = currentPlant.floweringSeason.toLowerCase();
        const s2 = p.floweringSeason.toLowerCase();
        if (s1 === s2 || s1.includes(s2) || s2.includes(s1)) {
          similarityScore += 35;
        }
      }

      // Environment match (Outdoor / Indoor / Both)
      if (currentPlant.environment && p.environment === currentPlant.environment) {
        similarityScore += 25;
      }

      // Sunlight requirement match
      if (currentPlant.sunlightRequirement && p.sunlightRequirement === currentPlant.sunlightRequirement) {
        similarityScore += 20;
      }

      // Shared suitability (Balcony, Garden, Pooja)
      if (currentPlant.suitableFor && p.suitableFor) {
        const shared = currentPlant.suitableFor.filter((item) => p.suitableFor?.includes(item));
        similarityScore += shared.length * 15;
      }

      // Maintenance match
      if (currentPlant.maintenanceLevel && p.maintenanceLevel === currentPlant.maintenanceLevel) {
        similarityScore += 10;
      }

      return { product: p, similarityScore };
    })
    .sort((a, b) => b.similarityScore - a.similarityScore)
    .slice(0, limit)
    .map((item) => item.product);
}

// Popular search suggestions & autocomplete tags for the search bar
export const POPULAR_SEARCH_CHIPS = [
  { label: '🌹 Flower Plants', query: 'Flower Plant' },
  { label: '🌿 Indoor Plants', query: 'Indoor Plant' },
  { label: '🍃 Air Purifying', query: 'Air Purifying Plant' },
  { label: '🪴 Low Maintenance', query: 'Low Maintenance' },
  { label: '🙏 Pooja & Sacred', query: 'Pooja' },
  { label: '✨ Decoration Plants', query: 'Decoration Plant' },
  { label: '🌺 Desi Gulab & Rose', query: 'Rose' },
  { label: '🌱 Tulsi & Medicinal', query: 'Medicinal Plant' },
  { label: '🍋 Fruit Plants', query: 'Fruit Plant' },
  { label: '🍅 Vegetable Plants', query: 'Vegetable' },
  { label: '🌴 Palms', query: 'Palm' },
  { label: '🌳 Bonsai Plants', query: 'Bonsai' },
  { label: '🌿 Climbers & Creepers', query: 'Climber' },
  { label: '🌲 Heritage Trees', query: 'Tree' },
  { label: '🌵 Cactus & Succulents', query: 'Cactus' },
  { label: '🏡 Balcony Plants', query: 'Balcony Plant' },
];
