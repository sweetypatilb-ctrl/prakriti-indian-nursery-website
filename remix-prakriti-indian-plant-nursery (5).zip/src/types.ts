export type Language = 'en' | 'hi' | 'mr';

export interface PlantSpecs {
  height: string;
  potSize: string;
  light: 'Low' | 'Medium' | 'Bright Indirect' | 'Direct Sun' | string;
  water: 'Low' | 'Moderate' | 'Frequent' | string;
  soil: string;
  temperature: string;
  difficulty: 'Easy' | 'Moderate' | 'Expert' | string;
  location: string;
  petFriendly: boolean;
  beginnerFriendly: boolean;
  benefits: string[];
}

export interface PlantCareGuide {
  watering: string;
  sunlight: string;
  fertilizer: string;
  repotting: string;
  pruning: string;
  commonProblems: string;
}

export interface Review {
  id: string;
  productId: string;
  userName: string;
  rating: number;
  date: string;
  title: string;
  comment: string;
  verifiedPurchase: boolean;
  city?: string;
  status: 'approved' | 'pending' | 'hidden';
}

export interface Product {
  id: string;
  productId?: string;
  slug: string;
  name: string;
  plantName?: string;
  nameHi?: string;
  nameMr?: string;
  commonIndianName?: string;
  scientificName?: string;
  category: string;
  subcategory?: string;
  price: number;
  priceInINR?: number;
  mrp: number;
  rating: number;
  reviewCount: number;
  stock: number;
  available?: boolean;
  images: string[];
  imageUrl?: string;
  description: string;
  descriptionHi?: string;
  descriptionMr?: string;
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  plantType?: 'indoor' | 'outdoor' | 'flowering' | 'succulent' | 'medicinal' | 'fruit' | 'bonsai' | 'seeds' | 'pots' | 'care' | 'decorative' | 'herbal';
  environment?: 'Indoor' | 'Outdoor' | 'Both';
  floweringType?: 'Flowering' | 'Non-flowering';
  sunlightRequirement?: 'Full Sun' | 'Partial Shade' | 'Bright Indirect' | 'Low Light';
  waterRequirement?: 'Low' | 'Moderate' | 'High' | 'Daily';
  soilRequirement?: string;
  soilType?: string;
  suitableIndianClimate?: string;
  maintenanceLevel?: 'Low' | 'Medium' | 'High';
  flowerColor?: string;
  floweringSeason?: string;
  plantHeight?: string;
  suitableFor?: ('Home' | 'Garden' | 'Balcony' | 'Office' | 'Decoration' | 'Pooja' | 'Landscaping')[];
  searchKeywords?: string[];
  tags?: string[];
  specs?: PlantSpecs;
  careGuide?: PlantCareGuide;
  createdAt?: string;
}

export interface Category {
  id: string;
  name: string;
  nameHi: string;
  nameMr: string;
  slug: string;
  image: string;
  count: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Address {
  id: string;
  userId?: string;
  name: string;
  mobile: string;
  addressLine: string;
  landmark?: string;
  city: string;
  state: string;
  pincode: string;
  type: 'home' | 'office' | 'other' | 'Home' | 'Office' | 'Other';
  isDefault: boolean;
}

export type OrderStatus = 'Pending' | 'Placed' | 'Confirmed' | 'Packed' | 'Dispatched' | 'Shipped' | 'Out for Delivery' | 'Delivered' | 'Cancelled';

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

export interface Order {
  id: string;
  orderId?: string;
  date: string;
  userId?: string;
  customerName: string;
  customerEmail: string;
  customerMobile: string;
  items: OrderItem[];
  orderedProducts?: OrderItem[];
  quantities?: number[];
  subtotal: number;
  discount?: number;
  couponDiscount: number;
  couponCode?: string;
  shippingCharges: number;
  gstAmount: number;
  totalAmount: number;
  totalAmountINR?: number;
  paymentMethod: 'UPI' | 'Card' | 'NetBanking' | 'COD';
  paymentStatus: 'Paid' | 'Pending' | 'Failed' | string;
  orderStatus: OrderStatus;
  shippingAddress: Address;
  trackingNumber?: string;
  courierPartner?: string;
  estimatedDeliveryDate: string;
  notes?: string;
  createdAt?: string;
}

export interface Coupon {
  id: string;
  code: string;
  description: string;
  discountType: 'percentage' | 'flat';
  discountValue: number;
  minOrderValue: number;
  maxDiscount?: number;
  validUntil: string;
  active: boolean;
  festivalTag?: string;
}

export interface User {
  id: string;
  uid?: string;
  name: string;
  email: string;
  mobile: string;
  role: 'customer' | 'admin';
  avatar?: string;
  createdAt?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  titleHi: string;
  titleMr: string;
  message: string;
  messageHi: string;
  messageMr: string;
  date: string;
  read: boolean;
  type: 'order' | 'offer' | 'delivery' | 'system';
}

export interface NurserySettings {
  name: string;
  phone: string;
  whatsappNumber: string;
  email: string;
  gstin: string;
  address: string;
  freeShippingThreshold: number;
  standardShippingFee: number;
  freeDeliveryThreshold?: number;
  standardDeliveryCharge?: number;
  gstRate?: number;
  activeFestival: string;
  festivalBannerTitle: string;
  festivalBannerSubtext: string;
  festivalBannerDiscount: string;
  announcementText: string;
}
