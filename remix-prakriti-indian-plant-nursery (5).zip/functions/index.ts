/**
 * Firebase Cloud Functions Backend for Prakriti Indian Plant Nursery
 * Secure order creation, pricing validation, stock verification, and Razorpay signature verification.
 */

import crypto from 'crypto';
import Razorpay from 'razorpay';
import { onRequest } from 'firebase-functions/v2/https';
import * as admin from 'firebase-admin';

// Initialize Admin SDK if not already initialized
if (!admin.apps.length) {
  admin.initializeApp();
}

const firestore = admin.firestore();

function getRazorpay(): Razorpay | null {
  const key_id = process.env.RAZORPAY_KEY_ID;
  const key_secret = process.env.RAZORPAY_KEY_SECRET;
  if (!key_id || !key_secret) return null;
  return new Razorpay({ key_id, key_secret });
}

/**
 * Cloud Function: Create Razorpay Order
 * Validates stock, calculates server-authoritative totals and coupon discounts.
 */
export const createRazorpayOrder = onRequest({ cors: true }, async (req, res) => {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  try {
    const { items, customerInfo, shippingAddress, couponCode, deliverySpeed } = req.body;

    if (!Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'Cart cannot be empty.' });
      return;
    }

    let calculatedSubtotal = 0;
    const validatedItems = [];

    // 1. Validate real products & stocks from Firestore
    for (const item of items) {
      const productId = item.productId || item.product?.id;
      const qty = Math.max(1, parseInt(item.quantity, 10) || 1);

      const prodRef = firestore.collection('products').doc(productId);
      const snap = await prodRef.get();

      if (!snap.exists) {
        res.status(400).json({ error: `Product ${productId} not found.` });
        return;
      }

      const pData = snap.data() || {};
      const currentStock = typeof pData.stock === 'number' ? pData.stock : 25;
      const realPrice = typeof pData.priceInINR === 'number' ? pData.priceInINR : (Number(pData.price) || 299);

      if (currentStock < qty) {
        res.status(400).json({
          error: `Insufficient stock for "${pData.plantName || pData.name}". Available: ${currentStock}.`,
          productId,
        });
        return;
      }

      calculatedSubtotal += realPrice * qty;
      validatedItems.push({
        productId,
        name: pData.plantName || pData.name,
        price: realPrice,
        quantity: qty,
        image: pData.imageUrl || (pData.images && pData.images[0]) || '',
      });
    }

    // 2. Validate Coupon
    let couponDiscount = 0;
    if (couponCode) {
      const couponDoc = await firestore.collection('coupons').doc(couponCode.trim().toUpperCase()).get();
      if (couponDoc.exists) {
        const cData = couponDoc.data() || {};
        if (cData.active && calculatedSubtotal >= (cData.minOrderValue || 0)) {
          if (cData.discountType === 'percentage') {
            couponDiscount = Math.round((calculatedSubtotal * cData.discountValue) / 100);
            if (cData.maxDiscount && couponDiscount > cData.maxDiscount) couponDiscount = cData.maxDiscount;
          } else {
            couponDiscount = Math.min(calculatedSubtotal, cData.discountValue || 0);
          }
        }
      }
    }

    const freeDeliveryThreshold = 999;
    const shippingCharges = (calculatedSubtotal >= freeDeliveryThreshold ? 0 : 99) + (deliverySpeed === 'express' ? 99 : 0);
    const finalTotalINR = Math.max(1, calculatedSubtotal - couponDiscount + shippingCharges);
    const amountInPaise = Math.round(finalTotalINR * 100);

    const generatedOrderId = 'PRAK-' + Math.floor(100000 + Math.random() * 900000);
    const razorpay = getRazorpay();

    let rzpOrder: any = null;
    if (razorpay) {
      rzpOrder = await razorpay.orders.create({
        amount: amountInPaise,
        currency: 'INR',
        receipt: generatedOrderId,
      });
    } else {
      rzpOrder = { id: 'order_test_' + Date.now(), amount: amountInPaise, currency: 'INR' };
    }

    // Write pending order
    await firestore.collection('orders').doc(generatedOrderId).set({
      orderId: generatedOrderId,
      userId: customerInfo?.userId || 'guest',
      items: validatedItems,
      subtotal: calculatedSubtotal,
      couponDiscount,
      shippingCharges,
      totalAmount: finalTotalINR,
      paymentMethod: 'UPI',
      paymentStatus: 'Pending Payment',
      orderStatus: 'Pending',
      razorpayOrderId: rzpOrder.id,
      shippingAddress: shippingAddress || {},
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    res.json({
      success: true,
      razorpayOrderId: rzpOrder.id,
      keyId: process.env.RAZORPAY_KEY_ID || '',
      amount: amountInPaise,
      currency: 'INR',
      orderId: generatedOrderId,
      totalAmount: finalTotalINR,
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Internal server error' });
  }
});

/**
 * Cloud Function: Verify Razorpay Payment Signature
 */
export const verifyRazorpayPayment = onRequest({ cors: true }, async (req, res) => {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderId } = req.body;
    const secret = process.env.RAZORPAY_KEY_SECRET;

    if (secret) {
      const generated_signature = crypto
        .createHmac('sha256', secret)
        .update(`${razorpay_order_id}|${razorpay_payment_id}`)
        .digest('hex');

      if (generated_signature !== razorpay_signature) {
        res.status(400).json({ error: 'Invalid payment signature' });
        return;
      }
    }

    const orderRef = firestore.collection('orders').doc(orderId);
    await firestore.runTransaction(async (transaction) => {
      const orderDoc = await transaction.get(orderRef);
      if (!orderDoc.exists) throw new Error('Order not found');

      const data = orderDoc.data() || {};
      if (data.paymentStatus === 'Paid Online (Razorpay Verified)') {
        return; // Idempotent
      }

      // Decrement stocks atomically
      const items = data.items || [];
      for (const item of items) {
        const prodRef = firestore.collection('products').doc(item.productId);
        transaction.update(prodRef, {
          stock: admin.firestore.FieldValue.increment(-item.quantity),
          updatedAt: new Date().toISOString(),
        });
      }

      transaction.update(orderRef, {
        paymentStatus: 'Paid Online (Razorpay Verified)',
        orderStatus: 'Confirmed',
        razorpayPaymentId: razorpay_payment_id,
        paidAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    });

    res.json({ success: true, orderId });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Verification failed' });
  }
});
