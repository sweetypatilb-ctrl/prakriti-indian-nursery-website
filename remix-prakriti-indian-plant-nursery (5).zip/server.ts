import express, { Request, Response } from 'express';
import path from 'path';
import crypto from 'crypto';
import dotenv from 'dotenv';
import Razorpay from 'razorpay';
import { createServer as createViteServer } from 'vite';
import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  getDocs,
  writeBatch,
  increment,
  serverTimestamp,
} from 'firebase/firestore';

// Gemini AI Botanical Consultation Service
import { askPlantDoctor, diagnosePlantHealth } from './server/geminiService';

// Load environment variables
dotenv.config();

// Read Firebase applet configuration
import firebaseConfigRaw from './firebase-applet-config.json' with { type: 'json' };
import { INITIAL_PRODUCTS, INITIAL_COUPONS } from './src/data/initialData';

const PORT = 3000;

// Initialize Server-side Firebase
const serverFirebaseConfig = {
  apiKey: firebaseConfigRaw.apiKey,
  authDomain: firebaseConfigRaw.authDomain,
  projectId: firebaseConfigRaw.projectId,
  storageBucket: firebaseConfigRaw.storageBucket,
  messagingSenderId: firebaseConfigRaw.messagingSenderId,
  appId: firebaseConfigRaw.appId,
  firestoreDatabaseId: firebaseConfigRaw.firestoreDatabaseId || undefined,
};

const serverApp = getApps().length > 0 ? getApp() : initializeApp(serverFirebaseConfig, 'server_prakriti');
const dbId = serverFirebaseConfig.firestoreDatabaseId && serverFirebaseConfig.firestoreDatabaseId !== '(default)'
  ? serverFirebaseConfig.firestoreDatabaseId
  : undefined;
const serverDb = getFirestore(serverApp, dbId);

// Lazy Razorpay Client initialization
function getRazorpayClient(): Razorpay | null {
  const key_id = process.env.RAZORPAY_KEY_ID?.trim();
  const key_secret = process.env.RAZORPAY_KEY_SECRET?.trim();

  if (!key_id || !key_secret) {
    return null;
  }

  return new Razorpay({
    key_id,
    key_secret,
  });
}

// Server-side Product Fetch & Verification
async function getProductWithCurrentStock(productId: string): Promise<{ id: string; name: string; price: number; stock: number; images: string[] } | null> {
  try {
    const prodDocRef = doc(serverDb, 'products', productId);
    const snap = await getDoc(prodDocRef);
    if (snap.exists()) {
      const d = snap.data();
      const price = typeof d.priceInINR === 'number' ? d.priceInINR : (Number(d.price) || 299);
      const stock = typeof d.stock === 'number' ? d.stock : 25;
      const images = Array.isArray(d.images) && d.images.length > 0 ? d.images : (d.imageUrl ? [d.imageUrl] : []);
      return {
        id: productId,
        name: d.plantName || d.name || 'Prakriti Live Plant',
        price,
        stock,
        images,
      };
    }
  } catch (err) {
    console.warn(`[Server] Firestore product lookup for ${productId} fell back to catalog:`, err);
  }

  // Fallback to initial server catalog
  const catalogItem = INITIAL_PRODUCTS.find((p) => p.id === productId || p.productId === productId);
  if (catalogItem) {
    return {
      id: catalogItem.id,
      name: catalogItem.name,
      price: catalogItem.price,
      stock: catalogItem.stock,
      images: catalogItem.images,
    };
  }

  return null;
}

// Server-side Coupon Validation
async function validateCouponOnServer(code: string | undefined, subtotal: number): Promise<{ valid: boolean; discount: number; code?: string; reason?: string }> {
  if (!code || !code.trim() || subtotal <= 0) {
    return { valid: false, discount: 0 };
  }

  const cleanCode = code.trim().toUpperCase();

  // 1. Check Firestore coupons
  let couponData: any = null;
  try {
    const couponRef = doc(serverDb, 'coupons', cleanCode);
    const snap = await getDoc(couponRef);
    if (snap.exists()) {
      couponData = snap.data();
    }
  } catch (e) {
    // ignore
  }

  // 2. Fallback to Initial Coupons catalog
  if (!couponData) {
    couponData = INITIAL_COUPONS.find((c) => c.code.toUpperCase() === cleanCode && c.active);
  }

  if (!couponData || couponData.active === false) {
    return { valid: false, discount: 0, reason: 'Coupon is inactive or invalid.' };
  }

  const minOrder = Number(couponData.minOrderValue) || 0;
  if (subtotal < minOrder) {
    return {
      valid: false,
      discount: 0,
      reason: `Minimum order value for ${cleanCode} is ₹${minOrder}.`,
    };
  }

  let discount = 0;
  if (couponData.discountType === 'percentage') {
    discount = Math.round((subtotal * Number(couponData.discountValue)) / 100);
    const maxDisc = Number(couponData.maxDiscount);
    if (maxDisc && discount > maxDisc) {
      discount = maxDisc;
    }
  } else {
    discount = Math.min(subtotal, Number(couponData.discountValue) || 0);
  }

  return {
    valid: true,
    discount: Math.max(0, discount),
    code: cleanCode,
  };
}

// Server-side Atomic Stock Decrement
async function atomicReduceStockForOrder(items: Array<{ productId: string; quantity: number }>): Promise<boolean> {
  try {
    const batch = writeBatch(serverDb);
    for (const item of items) {
      const prodRef = doc(serverDb, 'products', item.productId);
      const snap = await getDoc(prodRef);
      if (snap.exists()) {
        const curStock = Number(snap.data()?.stock) || 0;
        const newStock = Math.max(0, curStock - item.quantity);
        batch.update(prodRef, {
          stock: newStock,
          available: newStock > 0,
          updatedAt: new Date().toISOString(),
        });
      }
    }
    await batch.commit();
    return true;
  } catch (err) {
    console.error('[Server] Atomic stock reduction error:', err);
    return false;
  }
}

async function startServer() {
  const app = express();

  // Middlewares - capture rawBody for HMAC webhook verification
  app.use(
    express.json({
      verify: (req: any, _res, buf) => {
        req.rawBody = buf;
      },
    })
  );
  app.use(express.urlencoded({ extended: true }));

  // 1. Health check
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({
      status: 'ok',
      service: 'Prakriti Nursery Production Server',
      database: serverFirebaseConfig.projectId,
      razorpayConfigured: Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET),
      geminiConfigured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim()),
      timestamp: new Date().toISOString(),
    });
  });

  // 2. Public configuration (key_id only, NEVER secret)
  app.get('/api/config', (req: Request, res: Response) => {
    res.json({
      razorpayKeyId: process.env.RAZORPAY_KEY_ID || '',
      isRazorpayLive: Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET),
      geminiAvailable: true,
      storeName: 'Prakriti Indian Plant Nursery',
      freeDeliveryThreshold: 999,
      standardDeliveryCharge: 99,
    });
  });

  // 3. Create Razorpay Order with strict Server-side Calculation and Stock Check
  app.post('/api/create-razorpay-order', async (req: Request, res: Response) => {
    try {
      const { items, customerInfo, shippingAddress, couponCode, deliverySpeed, notes } = req.body;

      if (!Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'Cart cannot be empty for checkout.' });
      }

      // Step A: Server-side validation of every cart item price and stock
      let calculatedSubtotal = 0;
      const validatedItems: Array<{
        productId: string;
        name: string;
        price: number;
        quantity: number;
        image: string;
      }> = [];

      for (const reqItem of items) {
        const productId = reqItem.productId || reqItem.product?.id;
        const requestedQty = Math.max(1, parseInt(reqItem.quantity, 10) || 1);

        const realProduct = await getProductWithCurrentStock(productId);
        if (!realProduct) {
          return res.status(400).json({ error: `Product with ID ${productId} was not found in catalog.` });
        }

        // Real-time stock verification
        if (realProduct.stock < requestedQty) {
          return res.status(400).json({
            error: `Insufficient live stock for "${realProduct.name}". Only ${realProduct.stock} unit(s) remaining.`,
            productId: realProduct.id,
            availableStock: realProduct.stock,
          });
        }

        const lineTotal = realProduct.price * requestedQty;
        calculatedSubtotal += lineTotal;

        validatedItems.push({
          productId: realProduct.id,
          name: realProduct.name,
          price: realProduct.price,
          quantity: requestedQty,
          image: realProduct.images[0] || '',
        });
      }

      // Step B: Server-side Coupon Verification
      const couponResult = await validateCouponOnServer(couponCode, calculatedSubtotal);
      const couponDiscount = couponResult.discount;

      // Step C: Server-side Delivery and Tax Calculations
      const freeDeliveryThreshold = 999;
      const isFreeDelivery = calculatedSubtotal >= freeDeliveryThreshold;
      const baseDelivery = isFreeDelivery ? 0 : 99;
      const expressSurcharge = deliverySpeed === 'express' ? 99 : 0;
      const shippingCharges = baseDelivery + expressSurcharge;

      const gstRate = 5; // Indian Nursery GST
      const taxableAmount = Math.max(0, calculatedSubtotal - couponDiscount);
      const gstAmount = Math.round((taxableAmount * gstRate) / (100 + gstRate));

      const finalTotalINR = Math.max(1, calculatedSubtotal - couponDiscount + shippingCharges);
      const amountInPaise = Math.round(finalTotalINR * 100);

      const generatedOrderId = 'PRAK-' + Math.floor(100000 + Math.random() * 900000);
      const razorpayClient = getRazorpayClient();

      let rzpOrder: any = null;

      if (razorpayClient) {
        // Real Razorpay API Order Creation
        rzpOrder = await razorpayClient.orders.create({
          amount: amountInPaise,
          currency: 'INR',
          receipt: generatedOrderId,
          notes: {
            orderId: generatedOrderId,
            customerEmail: customerInfo?.email || '',
            customerPhone: customerInfo?.mobile || '',
          },
        });
      } else {
        // Safe Development / Sandbox Fallback order structure when Razorpay keys are not yet provided
        rzpOrder = {
          id: 'order_simulated_' + Math.random().toString(36).substring(2, 14),
          amount: amountInPaise,
          currency: 'INR',
          receipt: generatedOrderId,
          status: 'created',
        };
      }

      // Record Pending Order in Firestore (server authoritative)
      try {
        const orderDocRef = doc(serverDb, 'orders', generatedOrderId);
        await setDoc(orderDocRef, {
          orderId: generatedOrderId,
          id: generatedOrderId,
          userId: customerInfo?.userId || customerInfo?.uid || 'guest',
          customerName: customerInfo?.name || shippingAddress?.name || 'Customer',
          customerEmail: customerInfo?.email || '',
          customerMobile: customerInfo?.mobile || shippingAddress?.mobile || '',
          items: validatedItems,
          orderedProducts: validatedItems,
          quantities: validatedItems.map((i) => i.quantity),
          subtotal: calculatedSubtotal,
          couponDiscount,
          couponCode: couponResult.code || null,
          shippingCharges,
          gstAmount,
          totalAmount: finalTotalINR,
          totalAmountINR: finalTotalINR,
          paymentMethod: 'UPI',
          paymentStatus: 'Pending Payment',
          orderStatus: 'Pending',
          razorpayOrderId: rzpOrder.id,
          shippingAddress: shippingAddress || {},
          deliverySpeed: deliverySpeed || 'standard',
          notes: notes || '',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
      } catch (dbErr) {
        console.warn('[Server] Could not write pending order to Firestore:', dbErr);
      }

      return res.json({
        success: true,
        razorpayOrderId: rzpOrder.id,
        keyId: process.env.RAZORPAY_KEY_ID || 'rzp_test_placeholder',
        amount: amountInPaise,
        currency: 'INR',
        orderId: generatedOrderId,
        subtotal: calculatedSubtotal,
        couponDiscount,
        shippingCharges,
        gstAmount,
        totalAmount: finalTotalINR,
        isSimulated: !razorpayClient,
      });
    } catch (err: any) {
      console.error('[Server] /api/create-razorpay-order error:', err);
      return res.status(500).json({ error: err?.message || 'Server error creating order.' });
    }
  });

  // 4. Verify Razorpay Payment Signature & Atomically Confirm Order
  app.post('/api/verify-payment', async (req: Request, res: Response) => {
    try {
      const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderId } = req.body;

      if (!orderId) {
        return res.status(400).json({ error: 'Order ID is required.' });
      }

      const key_secret = process.env.RAZORPAY_KEY_SECRET?.trim();

      // Signature Verification
      if (key_secret) {
        if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
          return res.status(400).json({ error: 'Missing Razorpay signature parameters.' });
        }

        const expectedSignature = crypto
          .createHmac('sha256', key_secret)
          .update(`${razorpay_order_id}|${razorpay_payment_id}`)
          .digest('hex');

        if (expectedSignature !== razorpay_signature) {
          console.error('[Server] Signature verification failed for order:', orderId);
          return res.status(400).json({ error: 'Invalid Razorpay payment signature.' });
        }
      }

      // Idempotency check: Ensure payment is not processed twice
      const orderDocRef = doc(serverDb, 'orders', orderId);
      const orderSnap = await getDoc(orderDocRef);

      if (orderSnap.exists()) {
        const orderData = orderSnap.data();
        if (orderData.paymentStatus === 'Paid Online (Razorpay Verified)' || orderData.orderStatus === 'Confirmed') {
          return res.json({
            success: true,
            alreadyProcessed: true,
            orderId,
            message: 'Order was already verified and confirmed.',
          });
        }

        // Atomically decrement stock
        const items = orderData.items || orderData.orderedProducts || [];
        await atomicReduceStockForOrder(items);

        // Update Order to Confirmed
        await updateDoc(orderDocRef, {
          paymentStatus: 'Paid Online (Razorpay Verified)',
          orderStatus: 'Confirmed',
          razorpayPaymentId: razorpay_payment_id || 'verified_mock',
          razorpayOrderId: razorpay_order_id || orderData.razorpayOrderId || '',
          paidAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
      }

      return res.json({
        success: true,
        orderId,
        message: 'Payment verified successfully and stock updated atomically.',
      });
    } catch (err: any) {
      console.error('[Server] /api/verify-payment error:', err);
      return res.status(500).json({ error: err?.message || 'Payment verification failed.' });
    }
  });

  // 5. Create Cash on Delivery (COD) Order with Server-side Stock & Pricing Check
  app.post('/api/create-cod-order', async (req: Request, res: Response) => {
    try {
      const { items, customerInfo, shippingAddress, couponCode, deliverySpeed, notes } = req.body;

      if (!Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'Cart is empty.' });
      }

      let calculatedSubtotal = 0;
      const validatedItems: Array<{
        productId: string;
        name: string;
        price: number;
        quantity: number;
        image: string;
      }> = [];

      for (const reqItem of items) {
        const productId = reqItem.productId || reqItem.product?.id;
        const requestedQty = Math.max(1, parseInt(reqItem.quantity, 10) || 1);

        const realProduct = await getProductWithCurrentStock(productId);
        if (!realProduct) {
          return res.status(400).json({ error: `Product ${productId} not found.` });
        }

        if (realProduct.stock < requestedQty) {
          return res.status(400).json({
            error: `Insufficient stock for "${realProduct.name}". Only ${realProduct.stock} left.`,
            productId: realProduct.id,
            availableStock: realProduct.stock,
          });
        }

        calculatedSubtotal += realProduct.price * requestedQty;
        validatedItems.push({
          productId: realProduct.id,
          name: realProduct.name,
          price: realProduct.price,
          quantity: requestedQty,
          image: realProduct.images[0] || '',
        });
      }

      const couponResult = await validateCouponOnServer(couponCode, calculatedSubtotal);
      const couponDiscount = couponResult.discount;

      const freeDeliveryThreshold = 999;
      const isFreeDelivery = calculatedSubtotal >= freeDeliveryThreshold;
      const baseDelivery = isFreeDelivery ? 0 : 99;
      const expressSurcharge = deliverySpeed === 'express' ? 99 : 0;
      const shippingCharges = baseDelivery + expressSurcharge;

      const gstRate = 5;
      const taxableAmount = Math.max(0, calculatedSubtotal - couponDiscount);
      const gstAmount = Math.round((taxableAmount * gstRate) / (100 + gstRate));

      const finalTotalINR = Math.max(1, calculatedSubtotal - couponDiscount + shippingCharges);
      const generatedOrderId = 'PRAK-' + Math.floor(100000 + Math.random() * 900000);

      // Atomically reduce stock
      await atomicReduceStockForOrder(validatedItems);

      const today = new Date();
      const estDate = new Date(today);
      estDate.setDate(today.getDate() + (deliverySpeed === 'express' ? 2 : 4));

      const newOrder = {
        orderId: generatedOrderId,
        id: generatedOrderId,
        userId: customerInfo?.userId || customerInfo?.uid || 'guest',
        customerName: customerInfo?.name || shippingAddress?.name || 'Customer',
        customerEmail: customerInfo?.email || '',
        customerMobile: customerInfo?.mobile || shippingAddress?.mobile || '',
        items: validatedItems,
        orderedProducts: validatedItems,
        quantities: validatedItems.map((i) => i.quantity),
        subtotal: calculatedSubtotal,
        couponDiscount,
        couponCode: couponResult.code || null,
        shippingCharges,
        gstAmount,
        totalAmount: finalTotalINR,
        totalAmountINR: finalTotalINR,
        paymentMethod: 'COD',
        paymentStatus: 'Pending (Cash on Delivery)',
        orderStatus: 'Confirmed',
        shippingAddress: shippingAddress || {},
        deliverySpeed: deliverySpeed || 'standard',
        trackingNumber: 'TRK-IND-' + Math.floor(10000000 + Math.random() * 90000000),
        courierPartner: 'BlueDart Live Air Express',
        date: today.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
        estimatedDeliveryDate: estDate.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' }),
        notes: notes || '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      try {
        const orderDocRef = doc(serverDb, 'orders', generatedOrderId);
        await setDoc(orderDocRef, newOrder);
      } catch (dbErr) {
        console.warn('[Server] Could not write COD order to Firestore:', dbErr);
      }

      return res.json({
        success: true,
        orderId: generatedOrderId,
        order: newOrder,
      });
    } catch (err: any) {
      console.error('[Server] /api/create-cod-order error:', err);
      return res.status(500).json({ error: err?.message || 'Failed to place COD order.' });
    }
  });

  // 6. Handle Payment Failure / Cancellation
  app.post('/api/payment-failed', async (req: Request, res: Response) => {
    try {
      const { orderId, reason } = req.body;
      if (orderId) {
        const orderDocRef = doc(serverDb, 'orders', orderId);
        await updateDoc(orderDocRef, {
          paymentStatus: 'Payment Failed',
          orderStatus: 'Cancelled',
          failureReason: reason || 'Customer cancelled or transaction was declined by bank.',
          updatedAt: new Date().toISOString(),
        }).catch(() => null);
      }
      return res.json({ success: true });
    } catch {
      return res.json({ success: false });
    }
  });

  // 7. Razorpay Webhook Handler (Duplicate Prevention & Cryptographic HMAC Verification)
  app.post('/api/razorpay-webhook', async (req: Request, res: Response) => {
    try {
      const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET?.trim();
      const signature = req.headers['x-razorpay-signature'] as string;

      if (webhookSecret && signature) {
        const rawPayload = (req as any).rawBody || Buffer.from(JSON.stringify(req.body));
        const expectedSignature = crypto
          .createHmac('sha256', webhookSecret)
          .update(rawPayload)
          .digest('hex');

        const signatureBuffer = Buffer.from(signature, 'utf8');
        const expectedBuffer = Buffer.from(expectedSignature, 'utf8');

        const isValid =
          signatureBuffer.length === expectedBuffer.length &&
          crypto.timingSafeEqual(signatureBuffer, expectedBuffer);

        if (!isValid) {
          console.warn('[Server] Razorpay webhook signature verification failed.');
          return res.status(400).send('Invalid webhook signature');
        }
      }

      const event = req.body.event;
      const paymentEntity = req.body.payload?.payment?.entity;
      const orderIdNotes = paymentEntity?.notes?.orderId;

      if ((event === 'payment.captured' || event === 'order.paid') && orderIdNotes) {
        const orderDocRef = doc(serverDb, 'orders', orderIdNotes);
        const orderSnap = await getDoc(orderDocRef);

        if (orderSnap.exists()) {
          const orderData = orderSnap.data();
          if (orderData.paymentStatus !== 'Paid Online (Razorpay Verified)') {
            // Atomically reduce stock
            const items = orderData.items || orderData.orderedProducts || [];
            await atomicReduceStockForOrder(items);

            await updateDoc(orderDocRef, {
              paymentStatus: 'Paid Online (Razorpay Verified)',
              orderStatus: 'Confirmed',
              razorpayPaymentId: paymentEntity.id,
              paidAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            });
            console.log(`[Server Webhook] Order ${orderIdNotes} marked as Paid & Confirmed.`);
          }
        }
      }

      return res.json({ status: 'ok' });
    } catch (err) {
      console.error('[Server Webhook Error]:', err);
      return res.status(500).send('Webhook processing error');
    }
  });

  // 8. Gemini AI Plant Doctor Assistant Endpoint
  app.post('/api/plant-ai-assistant', async (req: Request, res: Response) => {
    try {
      const { query, plantName, category, problem, symptoms, language } = req.body;

      if (!query && !problem && !symptoms && !plantName) {
        return res.status(400).json({ error: 'Please provide a plant name, question, or problem description.' });
      }

      const advice = await askPlantDoctor({
        query: query || problem,
        plantName,
        category,
        problem,
        symptoms,
        language: language || 'en',
      });

      return res.json({
        success: true,
        advice,
        source: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim()) ? 'gemini' : 'knowledge_base',
      });
    } catch (err: any) {
      console.error('[Server Plant AI Assistant Error]:', err);
      return res.status(500).json({
        success: false,
        error: err?.message || 'Botanical consultation service encountered a temporary error.',
      });
    }
  });

  // 9. Gemini AI Plant Disease & Diagnostic Specialist Endpoint
  app.post('/api/diagnose-plant', async (req: Request, res: Response) => {
    try {
      const { plantName, symptoms, leafCondition, wateringHabit, sunlightExposure, language } = req.body;

      if (!plantName || !symptoms) {
        return res.status(400).json({ error: 'Plant name and symptoms are required for diagnosis.' });
      }

      const diagnosis = await diagnosePlantHealth({
        plantName,
        symptoms,
        leafCondition,
        wateringHabit,
        sunlightExposure,
        language: language || 'en',
      });

      return res.json({
        success: true,
        data: diagnosis,
        geminiActive: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim()),
      });
    } catch (err: any) {
      console.error('[Server Diagnose Plant Error]:', err);
      return res.status(500).json({
        success: false,
        error: err?.message || 'Failed to complete plant diagnosis.',
      });
    }
  });

  // Mount Vite middleware for development, or static build for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Prakriti Server] Production-ready server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
